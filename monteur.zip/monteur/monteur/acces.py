"""Clés d'accès : Monteur ne s'ouvre que pour les personnes autorisées, et l'accès se retire à distance.

Le dépôt publie un petit fichier `acces.json` :

    {"cles": {"<empreinte>": {"nom": "Marie", "actif": true, "fin": "2026-12-31"}}}

L'empreinte est le sha256 de la clé : le fichier est public, mais il ne révèle aucune clé utilisable.
Chaque personne saisit sa clé au premier lancement ; elle est gardée dans `donnees/acces.json`.
À chaque lancement, Monteur relit le fichier distant en arrière-plan : passer `actif` à false (ou
retirer la ligne, ou laisser la date de fin arriver) ferme le logiciel au lancement suivant.

Tolérance : si le fichier distant est injoignable, le dernier verdict connu reste valable GRACE jours,
pour qu'une panne de réseau ou de GitHub ne bloque personne. Au-delà, Monteur demande une connexion.
"""
from __future__ import annotations

import hashlib
import json
import random
import threading
import time
import urllib.request

from . import stockage
from .config import DOSSIER_DONNEES

URL_DEFAUT = "https://raw.githubusercontent.com/Etiennepik/monteur/HEAD/acces.json"
LOCAL = DOSSIER_DONNEES / "acces.json"            # la clé de cette installation
CACHE = DOSSIER_DONNEES / "acces_distant.json"    # dernière lecture du fichier distant
GRACE = 7 * 86400          # tolérance hors ligne (secondes)
REVERIF = 6 * 3600         # au-delà, on relit le fichier distant même en cours de session
ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"     # sans O/0 ni I/1 : dictée au téléphone possible

_verrou = threading.Lock()
_derniere_tentative = 0.0


# ───────────── clés ─────────────

def normaliser(cle: str) -> str:
    """Majuscules, sans espaces ni tirets : la clé se retape sans se soucier de la mise en forme."""
    return "".join(c for c in str(cle or "").upper() if c.isalnum())


def empreinte(cle: str) -> str:
    n = normaliser(cle)
    return hashlib.sha256(n.encode("utf-8")).hexdigest() if n else ""


def fabriquer_cle() -> str:
    """Nouvelle clé lisible, du type MNT-A7K2-P9XQ-4RTB."""
    tirage = random.SystemRandom()
    groupes = ["".join(tirage.choice(ALPHABET) for _ in range(4)) for _ in range(3)]
    return "MNT-" + "-".join(groupes)


# ───────────── fichier distant ─────────────

def url(cfg: dict) -> str:
    return ((cfg.get("acces") or {}).get("url") or URL_DEFAUT).strip()


def lire_distant(adresse: str, timeout: int = 8) -> dict:
    """Lit le acces.json distant et le met en cache. Renvoie le cache (avec `erreur` si échec)."""
    ancien = stockage.lire(CACHE, {})
    try:
        req = urllib.request.Request(adresse, headers={"User-Agent": "Monteur",
                                                       "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read(1_000_000).decode("utf-8"))
        cles = d.get("cles")
        if not isinstance(cles, dict):
            raise ValueError("fichier d'accès illisible")
        res = {"cles": cles, "le": time.time(), "erreur": ""}
    except Exception as e:  # noqa: BLE001  (réseau, JSON, DNS… : tout se traite pareil)
        res = {"cles": ancien.get("cles") or {}, "le": ancien.get("le") or 0,
               "erreur": str(e)[:200], "essai": time.time()}
    stockage.ecrire(CACHE, res)
    return res


def verifier_en_fond(cfg: dict) -> bool:
    """Relit le fichier distant sans retarder l'ouverture. Une fois par lancement, puis toutes 6 h."""
    global _derniere_tentative
    adresse = url(cfg)
    if not adresse:
        return False
    cache = stockage.lire(CACHE, {})
    frais = (time.time() - float(cache.get("le") or 0)) < REVERIF
    with _verrou:
        if frais and _derniere_tentative:
            return False
        if time.time() - _derniere_tentative < 60:   # pas une requête par clic
            return False
        _derniere_tentative = time.time()
    threading.Thread(target=lire_distant, args=(adresse,), daemon=True).start()
    return True


# ───────────── verdict ─────────────

def ma_cle() -> str:
    return str(stockage.lire(LOCAL, {}).get("cle") or "")


def enregistrer_cle(cle: str) -> None:
    stockage.ecrire(LOCAL, {"cle": normaliser(cle), "le": time.time()})


def oublier_cle() -> None:
    stockage.ecrire(LOCAL, {})


def _fin_passee(fin: str) -> bool:
    fin = (fin or "").strip()
    if not fin:
        return False
    return time.strftime("%Y-%m-%d") > fin[:10]


def etat(cfg: dict) -> dict:
    """Verdict courant.

    Renvoie {autorise, etat, message, nom, proprietaire, fin}. `etat` vaut :
    `sans_cle`, `ok`, `revoque`, `expire`, `inconnue`, `jamais_verifie`, `injoignable`.
    """
    cle = ma_cle()
    if not cle:
        return {"autorise": False, "etat": "sans_cle", "message": "", "nom": "",
                "proprietaire": False, "fin": ""}

    cache = stockage.lire(CACHE, {})
    cles = cache.get("cles") or {}
    fiche = cles.get(empreinte(cle)) if isinstance(cles, dict) else None
    vu_le = float(cache.get("le") or 0)
    age = time.time() - vu_le
    proprio = bool((fiche or {}).get("proprietaire"))
    nom = str((fiche or {}).get("nom") or "")
    fin = str((fiche or {}).get("fin") or "")

    if not vu_le:
        return {"autorise": False, "etat": "jamais_verifie", "nom": "", "proprietaire": False, "fin": "",
                "message": "Monteur n'a pas encore pu vérifier ta clé. Connecte-toi à Internet puis "
                           "relance le logiciel."}

    # le propriétaire garde la main même si GitHub est injoignable des semaines
    if age > GRACE and not proprio:
        jours = int(age // 86400)
        return {"autorise": False, "etat": "injoignable", "nom": nom, "proprietaire": False, "fin": fin,
                "message": f"Monteur n'arrive plus à vérifier ton accès depuis {jours} jours. "
                           "Vérifie ta connexion Internet, puis relance le logiciel."}

    if fiche is None:
        return {"autorise": False, "etat": "inconnue", "nom": "", "proprietaire": False, "fin": "",
                "message": "Cette clé d'accès n'est pas (ou plus) reconnue."}
    if not fiche.get("actif", True):
        return {"autorise": False, "etat": "revoque", "nom": nom, "proprietaire": proprio, "fin": fin,
                "message": "Ton accès à Monteur a été fermé."}
    if _fin_passee(fin):
        return {"autorise": False, "etat": "expire", "nom": nom, "proprietaire": proprio, "fin": fin,
                "message": f"Ton accès à Monteur a pris fin le {fin}."}
    return {"autorise": True, "etat": "ok", "message": "", "nom": nom, "proprietaire": proprio, "fin": fin}


def essayer(cfg: dict, cle: str) -> dict:
    """Saisie d'une clé : lecture du fichier distant tout de suite, puis verdict.

    N'enregistre la clé que si elle est acceptée.
    """
    if not normaliser(cle):
        return {"autorise": False, "etat": "sans_cle", "message": "Entre ta clé d'accès."}
    cache = lire_distant(url(cfg), timeout=12)
    if cache.get("erreur") and not cache.get("cles"):
        return {"autorise": False, "etat": "injoignable",
                "message": "Impossible de joindre le serveur pour vérifier la clé. "
                           "Vérifie ta connexion Internet et réessaie."}
    fiche = (cache.get("cles") or {}).get(empreinte(cle))
    if fiche is None:
        return {"autorise": False, "etat": "inconnue",
                "message": "Clé inconnue. Vérifie que tu l'as recopiée entièrement."}
    if not fiche.get("actif", True):
        return {"autorise": False, "etat": "revoque", "message": "Cette clé a été désactivée."}
    if _fin_passee(str(fiche.get("fin") or "")):
        return {"autorise": False, "etat": "expire",
                "message": f"Cette clé a pris fin le {fiche.get('fin')}."}
    enregistrer_cle(cle)
    return {"autorise": True, "etat": "ok", "message": "", "nom": str(fiche.get("nom") or ""),
            "proprietaire": bool(fiche.get("proprietaire")), "fin": str(fiche.get("fin") or "")}


def liste_distante() -> tuple[list[dict], dict]:
    """Les accès tels que le fichier distant les décrit (pour le panneau du propriétaire)."""
    cache = stockage.lire(CACHE, {})
    out = []
    for emp, f in (cache.get("cles") or {}).items():
        f = f if isinstance(f, dict) else {}
        out.append({"empreinte": emp, "nom": str(f.get("nom") or "—"),
                    "actif": bool(f.get("actif", True)), "fin": str(f.get("fin") or ""),
                    "proprietaire": bool(f.get("proprietaire")),
                    "expire": _fin_passee(str(f.get("fin") or ""))})
    out.sort(key=lambda d: (not d["proprietaire"], d["nom"].lower()))
    return out, cache


def ligne_json(cle: str, nom: str, fin: str = "", proprietaire: bool = False) -> str:
    """Le morceau de JSON correspondant à une clé (sert de repli si la liste n'a pas pu être lue)."""
    return f'  "{empreinte(cle)}": {json.dumps(_fiche(nom, fin, proprietaire), ensure_ascii=False)}'


def _fiche(nom: str, fin: str = "", proprietaire: bool = False) -> dict:
    fiche = {"nom": nom or "", "actif": True}
    if fin:
        fiche["fin"] = fin
    if proprietaire:
        fiche["proprietaire"] = True
    return fiche


def fichier_complet(ajouts: list[dict] | None = None) -> str:
    """Le fichier des accès ENTIER, prêt à remplacer celui du dépôt.

    Donner le fichier complet plutôt qu'une ligne à insérer évite l'erreur classique : une virgule
    en trop (ou manquante) rend le JSON illisible, et plus personne ne peut ouvrir Monteur.
    Renvoie "" si la liste distante n'a jamais été lue — il ne faut surtout pas écraser le fichier
    avec une liste vide.
    """
    cache = stockage.lire(CACHE, {})
    if not cache.get("le"):
        return ""
    cles = {e: f for e, f in (cache.get("cles") or {}).items() if isinstance(f, dict)}
    for a in (ajouts or []):
        if a.get("cle"):
            cles[empreinte(a["cle"])] = _fiche(a.get("nom", ""), a.get("fin", ""), a.get("proprietaire", False))
    lignes = [f'    "{e}": {json.dumps(f, ensure_ascii=False)}' for e, f in cles.items()]
    return '{\n  "cles": {\n' + ",\n".join(lignes) + "\n  }\n}\n"
