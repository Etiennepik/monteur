"""Petit serveur local (127.0.0.1:8765) qui reçoit les posts sélectionnés depuis l'extension Chrome."""
from __future__ import annotations

import hashlib
import json
import re
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

from . import bibliotheque, config, quotes, telechargement

PORT = 8765
_travail = threading.Lock()
_etat = {"en_cours": False, "dernier_log": "", "vu_extension": 0.0, "serveur": False}

# ───────── fichiers servis au navigateur (audio, vidéo) ─────────
# Streamlit sert son dossier `static` en « text/plain » et compressé : le lecteur du navigateur
# refuse alors d'ouvrir les sons (DEMUXER_ERROR_COULD_NOT_OPEN) ou met plusieurs secondes à démarrer.
# On les sert donc nous-mêmes, avec le bon type et la reprise par morceaux (Range).
MEDIAS: dict[str, Path] = {}
TYPES = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".aac": "audio/aac", ".wav": "audio/wav",
         ".aiff": "audio/aiff", ".aif": "audio/aiff", ".flac": "audio/flac", ".ogg": "audio/ogg",
         ".opus": "audio/ogg", ".wma": "audio/x-ms-wma", ".mp4": "video/mp4", ".m4v": "video/mp4",
         ".mov": "video/quicktime", ".webm": "video/webm", ".mkv": "video/x-matroska"}


def actif() -> bool:
    """Ce Monteur est-il bien celui qui tient le port (et peut donc servir les médias) ?"""
    return bool(_etat["serveur"])


def publier(chemin) -> str:
    """Rend un fichier lisible par le navigateur et renvoie son adresse. '' si on ne sert pas."""
    if not actif():
        return ""
    try:
        p = Path(chemin).resolve()
        jeton = hashlib.md5(f"{p}|{p.stat().st_mtime_ns}".encode()).hexdigest()[:16] + p.suffix.lower()
    except OSError:
        return ""
    MEDIAS[jeton] = p
    if len(MEDIAS) > 400:                      # on ne garde pas une liste infinie
        for vieux in list(MEDIAS)[:100]:
            if vieux != jeton:
                MEDIAS.pop(vieux, None)
    return f"http://127.0.0.1:{PORT}/media/{jeton}"


def _lancer_en_fond():
    """Télécharge la file d'attente dans un fil séparé (ne bloque pas l'extension)."""
    if not _travail.acquire(blocking=False):
        return False

    def run():
        _etat["en_cours"] = True
        try:
            def log(m):
                _etat["dernier_log"] = m
                print(m, flush=True)
            telechargement.telecharger_file(config.charger(), log)
        finally:
            _etat["en_cours"] = False
            _travail.release()
    threading.Thread(target=run, daemon=True).start()
    return True


class Gestionnaire(BaseHTTPRequestHandler):
    def log_message(self, *a):  # silencieux
        pass

    def _origine_ok(self) -> bool:
        # n'accepte que l'extension (et les outils locaux sans Origin) — pas les sites web
        o = self.headers.get("Origin", "")
        if o.startswith("chrome-extension://"):
            import time
            _etat["vu_extension"] = time.time()
        return o == "" or o.startswith("chrome-extension://")

    def _json(self, code: int, data: dict):
        corps = json.dumps(data, ensure_ascii=False).encode()
        self.send_response(code)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(corps)))
        o = self.headers.get("Origin", "")
        if o.startswith("chrome-extension://"):
            self.send_header("Access-Control-Allow-Origin", o)
        self.end_headers()
        self.wfile.write(corps)

    def do_OPTIONS(self):
        self.send_response(204)
        o = self.headers.get("Origin", "")
        if o.startswith("chrome-extension://"):
            self.send_header("Access-Control-Allow-Origin", o)
            self.send_header("Access-Control-Allow-Methods", "GET, POST")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def _media(self, jeton: str):
        p = MEDIAS.get(jeton)
        if not p or not p.exists():
            return self._json(404, {"erreur": "média inconnu"})
        taille = p.stat().st_size
        debut, fin, code = 0, taille - 1, 200
        m = re.match(r"bytes=(\d*)-(\d*)", self.headers.get("Range", "") or "")
        if m and (m.group(1) or m.group(2)):
            if m.group(1):
                debut = int(m.group(1))
                if m.group(2):
                    fin = min(int(m.group(2)), taille - 1)
            else:                                           # bytes=-N : les N derniers octets
                debut = max(0, taille - int(m.group(2)))
            if debut > fin or debut >= taille:
                self.send_response(416)
                self.send_header("Content-Range", f"bytes */{taille}")
                self.end_headers()
                return
            code = 206
        longueur = fin - debut + 1
        self.send_response(code)
        self.send_header("Content-Type", TYPES.get(p.suffix.lower(), "application/octet-stream"))
        self.send_header("Accept-Ranges", "bytes")
        self.send_header("Content-Length", str(longueur))
        if code == 206:
            self.send_header("Content-Range", f"bytes {debut}-{fin}/{taille}")
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "public, max-age=86400")
        self.end_headers()
        try:
            with open(p, "rb") as f:
                f.seek(debut)
                reste = longueur
                while reste > 0:
                    bloc = f.read(min(262144, reste))
                    if not bloc:
                        break
                    self.wfile.write(bloc)
                    reste -= len(bloc)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass                                            # le navigateur coupe souvent en cours de route

    def do_GET(self):
        if self.path.startswith("/media/"):                 # lecture seule de fichiers déjà publiés
            return self._media(self.path[7:].split("?")[0])
        if not self._origine_ok():
            return self._json(403, {"erreur": "origine refusée"})
        if self.path.startswith("/etat"):
            cfg = config.charger()
            file = telechargement.lire_file()
            return self._json(200, {
                "ok": True,
                "themes": bibliotheque.themes(cfg),
                "comptes": [c["url"] for c in cfg.get("comptes", [])],
                "posts": telechargement.etat_posts(cfg),
                "en_attente": sum(1 for i in file if i.get("statut") == "en_attente"),
                "en_cours": _etat["en_cours"],
                "dernier_log": _etat["dernier_log"],
                # extraction de quotes
                "quotes": quotes.etat_visuels(),
                "quotes_en_attente": sum(1 for i in quotes.lire_file() if i.get("statut") in ("en_attente", "en_cours")),
                "pages_quotes": [p["url"] for p in cfg.get("pages_quotes", []) if p.get("url")],
            })
        self._json(404, {"erreur": "inconnu"})

    def do_POST(self):
        if not self._origine_ok():
            return self._json(403, {"erreur": "origine refusée"})
        try:
            n = int(self.headers.get("Content-Length") or 0)
            limite = 60_000_000 if self.path.startswith("/quotes") else 2_000_000   # images envoyées en base64
            data = json.loads(self.rfile.read(min(n, limite)) or b"{}")
        except Exception:
            return self._json(400, {"erreur": "JSON invalide"})
        if self.path.startswith("/ajouter"):
            urls = [u for u in data.get("urls", []) if isinstance(u, str)][:1000]
            theme = str(data.get("theme") or "")
            compte = str(data.get("compte") or "")[:300]
            ajoutes = telechargement.ajouter_a_la_file(urls, theme, compte, force=bool(data.get("force")))
            lance = _lancer_en_fond() if data.get("lancer", True) else False
            return self._json(200, {"ok": True, "ajoutes": ajoutes, "doublons": len(urls) - ajoutes, "lance": lance})
        if self.path.startswith("/quotes"):
            elements = [e for e in data.get("elements", []) if isinstance(e, dict)][:500]
            r = quotes.ajouter(elements, str(data.get("theme") or ""), str(data.get("page_url") or ""),
                               force=bool(data.get("force")))
            quotes.lancer_en_fond(config.charger)
            return self._json(200, {"ok": True, **r})
        if self.path.startswith("/lancer"):
            return self._json(200, {"ok": True, "lance": _lancer_en_fond()})
        self._json(404, {"erreur": "inconnu"})


def demarrer(bloquant: bool = False):
    """Démarre le récepteur. Renvoie le serveur, ou None si le port est déjà pris (déjà lancé)."""
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Gestionnaire)
    except OSError:
        return None
    _etat["serveur"] = True
    if bloquant:
        print(f"Récepteur Monteur à l'écoute sur http://127.0.0.1:{PORT}", flush=True)
        srv.serve_forever()
    else:
        threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


def derniere_visite_extension() -> float:
    return _etat["vu_extension"]
