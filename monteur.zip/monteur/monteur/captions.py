"""Captions (quotes) classées par thème, avec état « utilisée »."""
from __future__ import annotations

import datetime as dt
import difflib
import hashlib
import io
import random
import re
import threading
import time
import unicodedata
import urllib.request
import uuid

from . import stockage
from .config import DOSSIER_DONNEES

FICHIER = DOSSIER_DONNEES / "captions.json"
ETAT_SYNC = DOSSIER_DONNEES / "sync_captions.json"


A_CLASSER = "_a_classer"          # quotes capturées que le classement automatique n'a pas su ranger
IGNOREES = DOSSIER_DONNEES / "captions_ignorees.json"   # phrases du Sheet supprimées dans Monteur


def maintenant() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


def normaliser(t: str) -> str:
    """Forme de comparaison : sans accents, ponctuation, espaces ni majuscules."""
    t = unicodedata.normalize("NFKD", str(t or "").lower())
    return "".join(c for c in t if c.isalnum())


def similaires(a: str, b: str) -> bool:
    """Même quote à la ponctuation / une erreur de lecture près."""
    na, nb = normaliser(a), normaliser(b)
    if not na or not nb:
        return False
    if na == nb:
        return True
    if min(len(na), len(nb)) < 20:
        return False
    return difflib.SequenceMatcher(None, na, nb, autojunk=False).ratio() >= 0.9


def est_sheet(it: dict) -> bool:
    """Caption gérée par la synchronisation du Google Sheet (les anciennes captions sans origine le sont)."""
    return it.get("origine") in (None, "sheet")


def tout() -> dict[str, list[dict]]:
    return stockage.lire(FICHIER, {})


def signature() -> str:
    """Empreinte du contenu des captions : change dès qu'une quote est ajoutée, modifiée ou retirée."""
    try:
        return hashlib.md5(FICHIER.read_bytes()).hexdigest()
    except OSError:
        return ""


def liste(theme: str) -> list[dict]:
    return tout().get(theme, [])


def chercher(texte: str) -> tuple[str, dict] | None:
    """(thème, caption) d'une caption déjà présente (tous thèmes confondus), sinon None."""
    for th, items in tout().items():
        for it in items:
            if similaires(it.get("texte", ""), texte) or (it.get("texte_source") and
                                                          similaires(it["texte_source"], texte)):
                return th, it
    return None


def _nouvelle(texte: str, origine: str, **meta) -> dict:
    return {"id": uuid.uuid4().hex[:10], "texte": texte, "utilisee": False, "utilisee_le": None, "video": None,
            "origine": origine, "ajoute_le": maintenant(), **{k: v for k, v in meta.items() if v not in (None, "")}}


def ajouter(theme: str, textes: list[str], origine: str = "manuel") -> int:
    n = 0

    def f(d):
        nonlocal n
        items = d.setdefault(theme, [])
        connus = {normaliser(i["texte"]) for i in items}
        for t in textes:
            t = (t or "").strip()
            if t and not t.startswith("#") and normaliser(t) and normaliser(t) not in connus:
                items.append(_nouvelle(t, origine))
                connus.add(normaliser(t))
                n += 1
        return d
    stockage.modifier(FICHIER, {}, f)
    return n


def ajouter_quote(theme: str, texte: str, **meta) -> dict:
    """Ajoute une quote capturée. Renvoie {"ajoutee": bool, "theme": ..., "id": ...}.

    Pas de doublon : si la même quote existe déjà dans n'importe quel thème (à la ponctuation près),
    rien n'est ajouté.
    """
    texte = (texte or "").strip()
    res = {"ajoutee": False, "theme": theme, "id": None}

    def f(d):
        for th, items in d.items():
            for it in items:
                if similaires(it.get("texte", ""), texte) or (it.get("texte_source") and
                                                              similaires(it["texte_source"], texte)):
                    res.update(theme=th, id=it["id"])
                    return d
        it = _nouvelle(texte, "capture", **meta)
        d.setdefault(theme, []).append(it)
        res.update(ajoutee=True, id=it["id"])
        return d
    if texte:
        stockage.modifier(FICHIER, {}, f)
    return res


def _ignorer(textes: list[str]) -> None:
    if textes:
        stockage.modifier(IGNOREES, [], lambda l: sorted(set(l) | {normaliser(t) for t in textes if t}))


def remplacer(theme: str, items: list[dict]) -> None:
    """Enregistre le tableau édité dans l'interface.

    Chaque ligne : id, texte, utilisee et, en option, auteur, a_verifier et theme (pour déplacer la caption).
    Les ids et l'historique sont conservés ; une caption du Sheet réécrite ici n'est plus écrasée par la
    synchronisation, et une caption du Sheet supprimée ici n'est pas réimportée.
    """
    def f(d):
        anciens = {i["id"]: i for i in d.get(theme, [])}
        gardes, deplaces, vus = [], {}, set()
        for it in items:
            texte = str(it.get("texte") or "").strip()
            if not texte or normaliser(texte) in vus:
                continue
            vus.add(normaliser(texte))
            base = anciens.get(it.get("id")) or _nouvelle(texte, "manuel")
            utilisee = bool(it.get("utilisee"))
            n = {**base, "texte": texte, "utilisee": utilisee,
                 "utilisee_le": base.get("utilisee_le") if utilisee else None,
                 "video": base.get("video") if utilisee else None}
            if texte != base.get("texte"):
                if est_sheet(base) and base.get("id") in anciens:
                    n.setdefault("texte_source", base["texte"])   # garde le lien avec la ligne du Sheet
                n["a_verifier"] = False                            # relue et corrigée
            if "auteur" in it:
                a = str(it.get("auteur") or "").strip()
                if a:
                    n["auteur"] = a
                else:
                    n.pop("auteur", None)
            if "a_verifier" in it and texte == base.get("texte"):
                n["a_verifier"] = bool(it.get("a_verifier"))
            if not n.get("a_verifier"):
                n.pop("a_verifier", None)
            dest = str(it.get("theme") or theme)
            if dest != theme:
                deplaces.setdefault(dest, []).append(n)
            else:
                gardes.append(n)
        gardes_ids = {i["id"] for i in gardes} | {i["id"] for l in deplaces.values() for i in l}
        # toute caption supprimée ici est mise de côté : la synchronisation ne la réimportera jamais,
        # même si elle est encore dans le Google Sheet (ou si elle vient d'une capture).
        supprimees = [i for i in anciens.values() if i["id"] not in gardes_ids]
        _ignorer([t for i in supprimees for t in (i.get("texte_source"), i.get("texte")) if t])
        d[theme] = gardes
        for dest, l in deplaces.items():
            cible = d.setdefault(dest, [])
            connus = {normaliser(i["texte"]) for i in cible}
            cible.extend(i for i in l if normaliser(i["texte"]) not in connus)
        if not d.get(A_CLASSER):
            d.pop(A_CLASSER, None)
        return d
    stockage.modifier(FICHIER, {}, f)


def tirer(theme: str, exclure: set[str] | None = None) -> dict | None:
    """Une caption non utilisée du thème, au hasard (en évitant les ids de `exclure` si possible)."""
    libres = [i for i in liste(theme) if not i.get("utilisee")]
    if exclure:
        libres = [i for i in libres if i["id"] not in exclure] or libres
    return random.choice(libres) if libres else None


def marquer(theme: str, texte: str, video: str | None) -> None:
    """Marque comme utilisée la caption du thème portant ce texte (l'ajoute si elle a été écrite à la main)."""
    texte = texte.strip()

    def f(d):
        items = d.setdefault(theme, [])
        it = next((i for i in items if i["texte"].strip() == texte), None)
        if it is None:
            it = _nouvelle(texte, "manuel")
            items.append(it)
        it.update({"utilisee": True, "utilisee_le": dt.datetime.now().isoformat(timespec="seconds"), "video": video})
        return d
    stockage.modifier(FICHIER, {}, f)


def marquer_ids(theme: str, ids: list[str], utilisee: bool) -> int:
    """Coche / décoche « utilisée » pour les captions désignées. Renvoie le nombre modifié."""
    vises = {str(i) for i in ids if i}
    if not vises:
        return 0
    compte = [0]

    def f(d):
        for it in d.get(theme, []):
            if it.get("id") in vises and bool(it.get("utilisee")) != utilisee:
                it["utilisee"] = utilisee
                it["utilisee_le"] = dt.datetime.now().isoformat(timespec="seconds") if utilisee else None
                if not utilisee:
                    it["video"] = None
                compte[0] += 1
        return d
    stockage.modifier(FICHIER, {}, f)
    return compte[0]


def supprimer_ids(theme: str, ids: list[str]) -> int:
    """Supprime définitivement des captions (elles ne reviendront pas du Google Sheet)."""
    vises = {str(i) for i in ids if i}
    if not vises:
        return 0
    compte = [0]

    def f(d):
        restants, partis = [], []
        for it in d.get(theme, []):
            (partis if it.get("id") in vises else restants).append(it)
        compte[0] = len(partis)
        _ignorer([t for i in partis for t in (i.get("texte_source"), i.get("texte")) if t])
        d[theme] = restants
        if not d.get(A_CLASSER):
            d.pop(A_CLASSER, None)
        return d
    stockage.modifier(FICHIER, {}, f)
    return compte[0]


def deplacer_ids(theme: str, ids: list[str], vers: str) -> int:
    """Range des captions dans un autre thème."""
    vises = {str(i) for i in ids if i}
    if not vises or vers == theme:
        return 0
    compte = [0]

    def f(d):
        restants, bouges = [], []
        for it in d.get(theme, []):
            (bouges if it.get("id") in vises else restants).append(it)
        d[theme] = restants
        cible = d.setdefault(vers, [])
        connus = {normaliser(i.get("texte", "")) for i in cible}
        for it in bouges:
            if normaliser(it.get("texte", "")) not in connus:
                cible.append(it)
                compte[0] += 1
        if not d.get(A_CLASSER):
            d.pop(A_CLASSER, None)
        return d
    stockage.modifier(FICHIER, {}, f)
    return compte[0]


def renommer_theme(ancien: str, nouveau: str) -> None:
    def f(d):
        if ancien in d:
            d[nouveau] = d.pop(ancien) + d.get(nouveau, [])
        for items in d.values():
            for it in items:
                if it.get("onglet") == ancien:
                    it["onglet"] = nouveau
        return d
    stockage.modifier(FICHIER, {}, f)


def supprimer_theme(theme: str) -> None:
    stockage.modifier(FICHIER, {}, lambda d: {k: v for k, v in d.items() if k != theme})


# ───────────── Google Sheet : un onglet par thème ─────────────

def id_sheet(url: str) -> str | None:
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url or "")
    return m.group(1) if m else None


def lire_sheet(url: str, timeout: int = 25) -> dict[str, list[str]]:
    """{nom_onglet: [phrases]} — lit tous les onglets d'un Sheet partagé par lien.

    Chaque ligne donne une phrase : on prend la première cellule non vide de la ligne,
    ce qui marche que les phrases soient en colonne A, B ou plus loin.
    """
    import openpyxl

    sid = id_sheet(url)
    if not sid:
        raise ValueError("Lien Google Sheet invalide.")
    adresse = f"https://docs.google.com/spreadsheets/d/{sid}/export?format=xlsx"
    req = urllib.request.Request(adresse, headers={"User-Agent": "Mozilla/5.0"})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        données = r.read()
    if données[:2] != b"PK":
        raise PermissionError("Le Sheet n'est pas accessible : partage-le en « Tous les utilisateurs disposant "
                              "du lien → Lecteur ».")
    classeur = openpyxl.load_workbook(io.BytesIO(données), read_only=True, data_only=True)
    out: dict[str, list[str]] = {}
    for feuille in classeur.worksheets:
        phrases = []
        for ligne in feuille.iter_rows(values_only=True):
            for cellule in ligne:
                texte = str(cellule).strip() if cellule is not None else ""
                if texte and texte.lower() not in ("none", "caption", "captions", "phrase", "phrases", "texte"):
                    phrases.append(texte)
                    break
        out[str(feuille.title).strip()] = phrases
    classeur.close()
    return out


def _erreur_lisible(e: Exception) -> str:
    t = str(e)
    b = t.lower()
    if isinstance(e, PermissionError) or "403" in b or "forbidden" in b:
        return ("Google refuse l'accès : ouvre le Sheet → Partager → « Tous les utilisateurs disposant du lien » "
                "en Lecteur.")
    if "404" in b or "not found" in b:
        return "Sheet introuvable : vérifie le lien."
    if "urlopen" in b or "timed out" in b or "name or service" in b or "connection" in b:
        return "Pas de connexion à Google pour le moment — nouvel essai à la prochaine synchronisation."
    return t[:300]


def etat_sync() -> dict:
    return stockage.lire(ETAT_SYNC, {"le": None, "ajoutees": 0, "message": "", "ok": None, "details": {}})


def refleter(onglets: dict[str, list[str]], miroir: bool = True, garder_utilisees: bool = True,
             proteges: set[str] | None = None) -> dict[str, dict]:
    """Aligne Monteur sur les onglets du Sheet ({thème: phrases}).

    - ajoute les phrases nouvelles (jamais en double, même si la quote existe déjà dans un autre thème) ;
    - en miroir, retire les captions du Sheet qui ont disparu de leur onglet (sauf utilisées si
      `garder_utilisees`, et sauf pour les onglets de `proteges`) ;
    - ne touche jamais aux captions capturées ou ajoutées dans Monteur, ni aux captions du Sheet réécrites
      ou déplacées dans un autre thème depuis Monteur (elles restent liées à leur ligne d'origine).
    Renvoie {thème: {"recues", "ajoutees", "supprimees"}}.
    """
    proteges = proteges or set()
    voulues: dict[str, list[str]] = {}
    for th, phrases in onglets.items():
        vues, l = set(), []
        for t in phrases:
            t = (t or "").strip()
            if t and not t.startswith("#") and normaliser(t) and normaliser(t) not in vues:
                vues.add(normaliser(t))
                l.append(t)
        voulues[th] = l
    normes = {th: {normaliser(t) for t in l} for th, l in voulues.items()}
    details = {th: {"recues": len(l), "ajoutees": 0, "supprimees": 0} for th, l in voulues.items()}
    ignorees = set(stockage.lire(IGNOREES, []))

    def f(d):
        # 1) retraits (miroir)
        for th in list(d):
            garde = []
            for it in d[th]:
                onglet = it.get("onglet") or th
                source = normaliser(it.get("texte_source") or it["texte"])
                if (miroir and est_sheet(it) and onglet in normes and onglet not in proteges
                        and source not in normes[onglet] and not (garder_utilisees and it.get("utilisee"))):
                    details.setdefault(onglet, {"recues": 0, "ajoutees": 0, "supprimees": 0})["supprimees"] += 1
                    continue
                garde.append(it)
            d[th] = garde
        # 2) index de ce qui existe déjà (tous thèmes)
        par_source, toutes = {}, set()
        for th, items in d.items():
            for it in items:
                toutes.add(normaliser(it["texte"]))
                if est_sheet(it):
                    par_source[normaliser(it.get("texte_source") or it["texte"])] = it
        # 3) ajouts / mises à jour
        for th, l in voulues.items():
            for t in l:
                n = normaliser(t)
                it = par_source.get(n)
                if it is not None:
                    if "texte_source" not in it:
                        it["texte"] = t              # même phrase (casse / ponctuation corrigées dans le Sheet)
                    it.setdefault("onglet", th)
                    continue
                if n in ignorees or n in toutes:
                    continue
                d.setdefault(th, []).append(_nouvelle(t, "sheet", onglet=th))
                toutes.add(n)
                details[th]["ajoutees"] += 1
        return d
    stockage.modifier(FICHIER, {}, f)
    return details


def synchroniser_sheet(cfg, creer_themes: bool = True) -> dict:
    """Importe les onglets du Sheet dans les captions. Crée les thèmes manquants.

    cfg peut être le dict de config (il sera rechargé si des thèmes sont créés).
    """
    from . import bibliotheque, config as _config

    url = (cfg.get("phrases_drive", {}) or {}).get("google_sheet_url", "").strip()
    if not url:
        return {"ok": False, "message": "Aucun lien de Google Sheet renseigné.", "ajoutees": 0, "details": {}}
    try:
        onglets = lire_sheet(url)
    except Exception as e:  # noqa: BLE001
        res = {"ok": False, "message": _erreur_lisible(e), "ajoutees": 0, "details": {},
               "le": maintenant()}
        stockage.ecrire(ETAT_SYNC, res)
        return res

    pd_cfg = cfg.get("phrases_drive", {}) or {}
    miroir = bool(pd_cfg.get("miroir", True))
    garder = bool(pd_cfg.get("garder_utilisees", True))
    existants = {t.lower(): t for t in bibliotheque.themes(cfg)}
    for t, d in (cfg.get("themes") or {}).items():          # anciens noms (thèmes renommés dans Monteur)
        for o in (d or {}).get("onglets", []):
            existants.setdefault(str(o).lower(), t)
    par_theme, nouveaux_themes, alertes, proteges = {}, [], [], set()
    actuelles = tout()
    partis = bibliotheque.supprimes()
    for onglet, phrases in onglets.items():
        if not onglet or onglet.startswith("_"):
            continue
        if (existants.get(onglet.lower()) or onglet).lower() in partis:
            continue                     # thème supprimé dans Monteur : l'onglet ne le recrée pas
        theme = existants.get(onglet.lower())
        if theme is None:
            if not creer_themes:
                continue
            theme = bibliotheque.creer_theme(cfg, onglet)
            existants[theme.lower()] = theme
            nouveaux_themes.append(theme)
        if miroir and not phrases and any(est_sheet(i) and (i.get("onglet") or th) == theme
                                          for th, l in actuelles.items() for i in l):
            # onglet vide alors qu'on avait des captions : on ne supprime rien sans confirmation
            alertes.append(f"onglet « {onglet} » vide : captions conservées")
            proteges.add(theme)
        par_theme[theme] = par_theme.get(theme, []) + phrases

    details = refleter(par_theme, miroir, garder, proteges)
    total = sum(v["ajoutees"] for v in details.values())
    retires = sum(v["supprimees"] for v in details.values())
    morceaux = [f"{total} ajoutée(s)"]
    if retires:
        morceaux.append(f"{retires} retirée(s)")
    if nouveaux_themes:
        morceaux.append("thèmes créés : " + ", ".join(nouveaux_themes))
    morceaux += alertes
    res = {"ok": True, "ajoutees": total, "supprimees": retires, "themes_crees": nouveaux_themes,
           "details": details, "le": maintenant(), "message": " · ".join(morceaux)}
    stockage.ecrire(ETAT_SYNC, res)
    if nouveaux_themes:
        _config.sauver(cfg)
    return res


_sync_lance = False
_sync_verrou = threading.Lock()


def demarrer_sync_auto(charger_cfg, intervalle_s: int = 120) -> bool:
    """Lance une synchronisation en arrière-plan, répétée toutes les `intervalle_s` secondes."""
    global _sync_lance
    with _sync_verrou:
        if _sync_lance:
            return False
        _sync_lance = True

    def boucle():
        while True:
            try:
                cfg = charger_cfg()
                pd = cfg.get("phrases_drive", {}) or {}
                if pd.get("mode") == "google_sheet" and pd.get("google_sheet_url") and pd.get("auto", True):
                    synchroniser_sheet(cfg)
                attente = int((cfg.get("phrases_drive", {}) or {}).get("intervalle_s") or intervalle_s)
            except Exception:  # noqa: BLE001
                attente = intervalle_s
            time.sleep(max(30, attente))
    threading.Thread(target=boucle, daemon=True).start()
    return True


def importer_drive(cfg: dict, themes: list[str]) -> dict[str, int]:
    """Ajoute les phrases du Drive (un fichier / un onglet par thème). Renvoie {theme: nb_ajoutees}."""
    from .phrases import listes_disponibles
    listes = listes_disponibles({"phrases": cfg["phrases_drive"]}, themes)
    par_nom = {t.lower(): t for t in themes}
    out: dict[str, int] = {}
    for nom, ph in listes.items():
        t = par_nom.get(nom.lower())
        if t:
            out[t] = out.get(t, 0) + ajouter(t, ph, origine="drive")
    return out


def stats(theme: str) -> tuple[int, int]:
    items = liste(theme)
    return len(items), sum(1 for i in items if i.get("utilisee"))
