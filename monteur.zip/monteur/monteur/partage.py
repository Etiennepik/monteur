"""Contenus communs à plusieurs personnes (dossier Google Drive / iCloud synchronisé).

Quand un dossier partagé est réglé, la bibliothèque vidéo, le centre de contrôle, les captions et
l'état « utilisée » vivent dedans : tout le monde voit les mêmes vidéos et les mêmes quotes, et une
quote ou une vidéo consommée par quelqu'un n'est pas reprise par les autres.

Restent personnels : les cookies du navigateur, les files d'attente de téléchargement et de lecture,
les réglages, les polices et les fichiers temporaires.
"""
from __future__ import annotations

import threading
from pathlib import Path

from . import bibliotheque, captions, config, quotes

# valeurs d'origine (dossier donnees/ local), pour pouvoir revenir en arrière
_LOCAL = {
    "videos": bibliotheque.ETATS,
    "captions": captions.FICHIER,
    "ignorees": captions.IGNOREES,
    "supprimes": bibliotheque.SUPPRIMES,
    "miniatures_quotes": quotes.MINIATURES,
}
_applique: str | None = None
_souci: str = ""          # dernier incident avec le dossier partagé (Drive lent, hors ligne…)


def souci() -> str:
    return _souci


def dossier(cfg: dict) -> Path | None:
    """Dossier partagé réglé (lu dans la config, sans toucher au disque)."""
    p = str((cfg.get("partage") or {}).get("dossier", "") or "").strip()
    if not p or est_lien_web(p):
        return None
    return config.resoudre(p)


def actif(cfg: dict) -> bool:
    """Le dossier partagé est-il réellement utilisé en ce moment ?"""
    return bool(_applique)


def est_lien_web(p: str) -> bool:
    return str(p or "").strip().lower().startswith(("http://", "https://"))


def etat(cfg: dict) -> str:
    """Message court pour les réglages (aucune lecture disque : le Drive peut être très lent)."""
    p = str((cfg.get("partage") or {}).get("dossier", "") or "").strip()
    if not p:
        return "Contenus gardés sur cet ordinateur uniquement."
    if est_lien_web(p):
        return ("Ceci est l'adresse du Drive sur le web. Monteur a besoin du dossier **tel qu'il existe sur ce "
                "Mac** : installe **Google Drive pour ordinateur**, ajoute le dossier partagé à ton Drive, "
                "puis choisis-le dans la liste au-dessus.")
    if _souci:
        return _souci
    if _applique:
        return f"Contenus partagés dans {_applique}"
    return (f"Choisi : {config.resoudre(p)} — clique sur **Enregistrer les réglages** pour l'activer.")


def dossiers_cloud(max_resultats: int = 40) -> list[Path]:
    """Dossiers candidats dans les espaces synchronisés du Mac (Google Drive, iCloud, Dropbox).

    On descend de deux niveaux : « Mon Drive/Monteur », « Drive partagés/Equipe/Monteur »…
    """
    maison = Path.home()
    racines = [maison / "Library" / "CloudStorage", maison / "Library" / "Mobile Documents",
               maison / "Google Drive", maison / "Dropbox"]
    out: list[Path] = []

    def descendre(d: Path, reste: int) -> None:
        if len(out) >= max_resultats or reste < 0:
            return
        try:
            enfants = sorted(x for x in d.iterdir() if x.is_dir() and not x.name.startswith("."))
        except OSError:
            return
        for e in enfants:
            if e not in out:
                out.append(e)
            if len(out) >= max_resultats:
                return
            descendre(e, reste - 1)

    for r in racines:
        if r.is_dir():
            descendre(r, 2)          # racine → Mon Drive / Drive partagés → dossiers → sous-dossiers
    return out


def repond(d: Path, secondes: float = 4.0) -> bool:
    """Le dossier répond-il vite ? Google Drive monte un disque réseau qui peut bloquer longtemps.

    On interroge dans un fil séparé : s'il n'a pas répondu à temps, on considère le dossier
    indisponible et on n'y touche plus de la session (sinon chaque lecture gèlerait Monteur).
    """
    resultat = {}

    def essai():
        try:
            resultat["ok"] = d.is_dir() and any(True for _ in d.iterdir()) or d.is_dir()
        except OSError as e:
            resultat["erreur"] = e.strerror or str(e)

    fil = threading.Thread(target=essai, daemon=True)
    fil.start()
    fil.join(secondes)
    if fil.is_alive():
        resultat["erreur"] = "pas de réponse"
    return bool(resultat.get("ok"))


def _revenir_au_local() -> None:
    bibliotheque.ETATS = _LOCAL["videos"]
    captions.FICHIER = _LOCAL["captions"]
    captions.IGNOREES = _LOCAL["ignorees"]
    bibliotheque.SUPPRIMES = _LOCAL["supprimes"]
    quotes.MINIATURES = _LOCAL["miniatures_quotes"]


def appliquer(cfg: dict) -> Path | None:
    """Redirige les fichiers d'état vers le dossier partagé (ou revient au dossier local).

    Si le dossier partagé ne répond pas (Drive en pleine synchronisation, hors ligne, dossier
    déplacé), on continue sur les contenus locaux et on note le souci : Monteur reste utilisable.
    """
    global _applique, _souci
    d = dossier(cfg)
    cle = str(d) if d else ""
    if cle == _applique and not _souci:
        return d
    _applique = cle
    _souci = ""
    if d is None:
        _revenir_au_local()
        return None
    if not repond(d):
        _souci = ("Le dossier commun ne répond pas (Google Drive est peut-être en pleine synchronisation, "
                  "hors ligne, ou le dossier n'est pas disponible hors connexion). Monteur travaille sur les "
                  "contenus de cet ordinateur en attendant — recharge la page pour réessayer.")
        _applique = None
        _revenir_au_local()
        return None
    try:
        etats = d / "donnees"
        etats.mkdir(parents=True, exist_ok=True)
        (d / "bibliotheque").mkdir(exist_ok=True)
        (d / "centre_de_controle").mkdir(exist_ok=True)
        (etats / "miniatures_quotes").mkdir(parents=True, exist_ok=True)
        (d / "polices").mkdir(exist_ok=True)
        (d / "audios").mkdir(exist_ok=True)
    except OSError as e:
        _souci = (f"Le dossier commun ne répond pas ({e.strerror or e}). Monteur travaille sur les contenus "
                  "de cet ordinateur en attendant. Vérifie que Google Drive a fini de se synchroniser, "
                  "puis recharge la page.")
        _applique = None                 # on réessaiera au prochain affichage
        _revenir_au_local()
        return None
    bibliotheque.ETATS = etats / "videos.json"
    captions.FICHIER = etats / "captions.json"
    captions.IGNOREES = etats / "captions_ignorees.json"
    bibliotheque.SUPPRIMES = etats / "themes_supprimes.json"
    quotes.MINIATURES = etats / "miniatures_quotes"
    try:
        _premier_remplissage(etats)
        _copier_polices(config.chemin(cfg, "polices"), d / "polices")
    except OSError:
        pass                             # la recopie initiale réessaiera plus tard
    return d


def dossiers_locaux(cfg: dict) -> tuple[Path, Path, Path]:
    """Bibliothèque, centre de contrôle et audios de cet ordinateur (sans la redirection du partage)."""
    d = cfg.get("dossiers") or {}
    return (config.resoudre(d.get("bibliotheque") or "bibliotheque"),
            config.resoudre(d.get("centre_controle") or "centre_de_controle"),
            config.resoudre(d.get("audios") or "audios"))


def _a_transferer(source: Path, cible: Path) -> list[tuple[Path, Path]]:
    paires = []
    if not source.is_dir() or source.resolve() == cible.resolve():
        return paires
    for f in source.rglob("*"):
        if f.is_file() and not f.name.startswith("."):
            dest = cible / f.relative_to(source)
            if not dest.exists():
                paires.append((f, dest))
    return paires


def reste_en_local(cfg: dict) -> int:
    """Nombre de fichiers encore sur cet ordinateur et absents du dossier commun."""
    d = dossier(cfg)
    if not d or not _applique:
        return 0
    bib, cc, aud = dossiers_locaux(cfg)
    try:
        return (len(_a_transferer(bib, d / "bibliotheque")) + len(_a_transferer(cc, d / "centre_de_controle"))
                + len(_a_transferer(aud, d / "audios")))
    except OSError:
        return 0


def transferer(cfg: dict, avancement=None) -> int:
    """Copie les vidéos et exports de cet ordinateur vers le dossier commun. Renvoie le nombre copié."""
    d = dossier(cfg)
    if not d or not _applique:
        return 0
    bib, cc, aud = dossiers_locaux(cfg)
    paires = (_a_transferer(bib, d / "bibliotheque") + _a_transferer(cc, d / "centre_de_controle")
              + _a_transferer(aud, d / "audios"))
    fait = 0
    for i, (src, dest) in enumerate(paires):
        try:
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(src.read_bytes())
            fait += 1
        except OSError:
            continue
        if avancement:
            avancement((i + 1) / max(1, len(paires)), src.name)
    return fait


def _copier_polices(source: Path, cible: Path) -> None:
    """Les typos deviennent communes : on verse celles de cet ordinateur dans le dossier partagé."""
    if not source.is_dir():
        return
    for f in source.iterdir():
        if f.suffix.lower() in (".ttf", ".otf", ".ttc") and not (cible / f.name).exists():
            (cible / f.name).write_bytes(f.read_bytes())


def _premier_remplissage(etats: Path) -> None:
    """Dossier partagé tout neuf : on y recopie ce qu'on a déjà, pour ne rien perdre."""
    for nom, source in (("captions.json", _LOCAL["captions"]), ("videos.json", _LOCAL["videos"]),
                        ("captions_ignorees.json", _LOCAL["ignorees"])):
        cible = etats / nom
        if source.exists() and not cible.exists():
            cible.write_bytes(source.read_bytes())
