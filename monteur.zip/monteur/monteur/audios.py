"""Banque d'audios : morceaux complets d'un côté, extraits rangés par artiste de l'autre.

    audios/
      _morceaux/            ← les morceaux entiers déposés (sources)
      <Artiste>/            ← les extraits découpés, un dossier par artiste
        <nom de l'extrait>.m4a

Le nom affiché est le nom du fichier sans son extension : renommer dans l'onglet renomme le fichier.
Quand un dossier commun est réglé, toute la banque y vit : tout le monde a les mêmes extraits.
"""
from __future__ import annotations

import hashlib
import subprocess
import tempfile
from pathlib import Path

from .config import DOSSIER_DONNEES, chemin

EXT = {".mp3", ".m4a", ".aac", ".wav", ".aiff", ".aif", ".flac", ".ogg", ".opus", ".wma"}
MORCEAUX = "_morceaux"            # dossier des morceaux entiers
FORMES = DOSSIER_DONNEES / "formes_onde"

_DUREES: dict[tuple[str, float], float] = {}      # mémoire de la session : le Drive peut être lent


# ───────────── dossiers ─────────────

def dossier(cfg: dict) -> Path:
    d = chemin(cfg, "audios")
    try:
        d.mkdir(parents=True, exist_ok=True)
        (d / MORCEAUX).mkdir(exist_ok=True)
    except OSError:
        pass
    return d


def nom_propre(nom: str) -> str:
    nom = " ".join(str(nom or "").strip().split())
    for c in '/\\:*?"<>|':
        nom = nom.replace(c, "-")
    return nom.strip(". ")


def nom_affiche(artiste: str) -> str:
    return "🎧 Morceaux complets" if artiste == MORCEAUX else artiste


def artistes(cfg: dict) -> list[str]:
    d = dossier(cfg)
    try:
        return sorted((p.name for p in d.iterdir()
                       if p.is_dir() and not p.name.startswith((".", "_"))), key=str.lower)
    except OSError:
        return []


def creer_artiste(cfg: dict, nom: str) -> str:
    nom = nom_propre(nom)
    if not nom or nom.startswith("_"):
        raise ValueError("Nom d'artiste invalide")
    if nom in artistes(cfg):
        raise ValueError("Cet artiste existe déjà")
    (dossier(cfg) / nom).mkdir(parents=True, exist_ok=True)
    return nom


def renommer_artiste(cfg: dict, ancien: str, nouveau: str) -> str:
    nouveau = nom_propre(nouveau)
    if not nouveau or nouveau.startswith("_"):
        raise ValueError("Nom d'artiste invalide")
    if nouveau == ancien:
        return ancien
    if nouveau in artistes(cfg):
        raise ValueError("Un artiste porte déjà ce nom")
    (dossier(cfg) / ancien).rename(dossier(cfg) / nouveau)
    return nouveau


def supprimer_artiste(cfg: dict, nom: str) -> None:
    """Supprime le dossier d'un artiste. Ses extraits doivent avoir été déplacés ou supprimés."""
    d = dossier(cfg) / nom
    if liste(cfg, nom):
        raise ValueError("Ce dossier contient encore des extraits")
    try:
        d.rmdir()
    except OSError as e:
        raise ValueError(f"Suppression impossible ({e.strerror or e})") from e


# ───────────── fichiers ─────────────

def duree(f: Path) -> float:
    """Durée en secondes (0 si illisible)."""
    try:
        cle = (str(f), f.stat().st_mtime)
    except OSError:
        return 0.0
    if cle in _DUREES:
        return _DUREES[cle]
    d = 0.0
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", str(f)], capture_output=True, text=True, timeout=25)
        d = round(float((r.stdout or "0").strip() or 0), 2)
    except (OSError, ValueError, subprocess.SubprocessError):
        d = 0.0
    _DUREES[cle] = d
    return d


def _fiches(d: Path, artiste: str) -> list[dict]:
    try:
        fichiers = sorted((p for p in d.iterdir()
                           if p.suffix.lower() in EXT and not p.name.startswith(".")),
                          key=lambda p: p.stat().st_mtime, reverse=True)
    except OSError:
        return []
    return [{"nom": f.stem, "fichier": f.name, "chemin": f, "artiste": artiste,
             "duree": duree(f)} for f in fichiers]


def liste(cfg: dict, artiste: str | None = None) -> list[dict]:
    """Extraits d'un artiste, ou de tous les artistes."""
    racine = dossier(cfg)
    if artiste:
        return _fiches(racine / artiste, artiste)
    out = []
    for a in artistes(cfg):
        out += _fiches(racine / a, a)
    return out


def morceaux(cfg: dict) -> list[dict]:
    """Les morceaux entiers déposés, dans lesquels on découpe les extraits."""
    return _fiches(dossier(cfg) / MORCEAUX, MORCEAUX)


def trouver(cfg: dict, artiste: str, nom: str) -> dict | None:
    for a in _fiches(dossier(cfg) / artiste, artiste):
        if nom in (a["nom"], a["fichier"]):
            return a
    return None


def _libre(d: Path, base: str, suffixe: str) -> Path:
    base = nom_propre(base) or "audio"
    cible = d / f"{base}{suffixe}"
    k = 2
    while cible.exists():
        cible = d / f"{base} ({k}){suffixe}"
        k += 1
    return cible


# Formats que tous les navigateurs lisent : on garde le fichier tel quel. Les autres sont
# convertis, sinon l'extrait se range bien mais refuse de s'écouter dans l'atelier.
SANS_CONVERSION = {".mp3", ".m4a"}


def _convertir(data: bytes, suffixe: str, cible: Path) -> None:
    """Réencode en m4a. La source passe par un fichier temporaire, jamais par un tuyau : certains
    formats ne se décodent correctement qu'en pouvant se déplacer dans le fichier.

    Le m4a produit est un mp4 ordinaire, avec son index à la fin — surtout pas fragmenté : les
    ateliers Paroles et Zones sautent sans arrêt d'un instant à l'autre de l'extrait, et un mp4
    fragmenté se déplace mal.
    """
    with tempfile.NamedTemporaryFile(suffix=suffixe, delete=False) as t:
        t.write(data)
        source = Path(t.name)
    try:
        r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
                            "-i", str(source), "-vn", "-c:a", "aac", "-b:a", "192k", str(cible)],
                           capture_output=True)
        if r.returncode != 0 or not cible.exists() or cible.stat().st_size == 0:
            cible.unlink(missing_ok=True)
            raise RuntimeError((r.stderr or b"").decode("utf-8", "replace").strip()[-400:]
                               or f"ffmpeg n'a pas pu convertir ce fichier {suffixe}")
    finally:
        source.unlink(missing_ok=True)


def importer(cfg: dict, fichiers: list[tuple[str, bytes]], artiste: str = MORCEAUX) -> list[str]:
    """Range des fichiers audio tels quels dans un dossier. Renvoie les noms des fichiers créés.

    `artiste` : le dossier de destination, un nom d'artiste ou MORCEAUX. C'est ce qui permet de
    déposer un extrait déjà prêt directement chez l'artiste, sans passer par la découpe.
    Un format que le navigateur ne sait pas lire est converti en m4a au passage.
    """
    d = dossier(cfg) / (artiste or MORCEAUX)
    d.mkdir(parents=True, exist_ok=True)
    poses = []
    for nom, data in fichiers:
        p = Path(nom)
        suffixe = p.suffix.lower()
        if suffixe not in EXT:
            continue
        try:
            if suffixe in SANS_CONVERSION:
                cible = _libre(d, p.stem, suffixe)
                cible.write_bytes(data)
            else:
                cible = _libre(d, p.stem, ".m4a")
                _convertir(data, suffixe, cible)
            poses.append(cible.name)
        except (OSError, RuntimeError):
            continue
    return poses


def importer_morceaux(cfg: dict, fichiers: list[tuple[str, bytes]]) -> int:
    """Dépose des morceaux entiers dans « Morceaux complets »."""
    return len(importer(cfg, fichiers, MORCEAUX))


def _suivre(source: Path, cible: Path) -> None:
    """Fait suivre à l'extrait ce qui lui est attaché : paroles transcrites, zones sans coupe.

    Sans ça, déplacer ou renommer un extrait perdait sa transcription — du travail long à refaire,
    et corrigé à la main.
    """
    from . import paroles, zones
    for module in (paroles, zones):
        try:
            ancienne = module._fichier_cache(source)
            if not ancienne.exists():
                continue
            neuve = module._fichier_cache(cible)
            neuve.parent.mkdir(parents=True, exist_ok=True)
            if neuve.resolve() != ancienne.resolve():
                neuve.write_bytes(ancienne.read_bytes())
                ancienne.unlink(missing_ok=True)
        except (OSError, AttributeError):
            continue


def renommer(cfg: dict, artiste: str, fichier: str, nouveau: str) -> str:
    """Renomme un extrait ou un morceau (l'extension est conservée)."""
    nouveau = nom_propre(nouveau)
    if not nouveau:
        raise ValueError("Nom vide")
    d = dossier(cfg) / artiste
    source = d / fichier
    if not source.exists():
        raise ValueError("Audio introuvable")
    cible = d / f"{nouveau}{source.suffix.lower()}"
    if cible == source:
        return nouveau
    if cible.exists():
        raise ValueError("Un audio porte déjà ce nom ici")
    source.rename(cible)
    _suivre(source, cible)
    return nouveau


def deplacer(cfg: dict, artiste: str, fichier: str, vers: str) -> Path:
    """Range un extrait dans le dossier d'un autre artiste."""
    source = dossier(cfg) / artiste / fichier
    dest_d = dossier(cfg) / vers
    dest_d.mkdir(parents=True, exist_ok=True)
    cible = _libre(dest_d, Path(fichier).stem, Path(fichier).suffix.lower())
    source.rename(cible)
    _suivre(source, cible)
    return cible


def supprimer(cfg: dict, artiste: str, fichier: str) -> bool:
    try:
        (dossier(cfg) / artiste / fichier).unlink()
        return True
    except OSError:
        return False


# ───────────── découpe d'un extrait ─────────────

def extraire(cfg: dict, source: Path, debut: float, fin: float, artiste: str, nom: str,
             fondu: float = 0.0) -> Path:
    """Découpe [debut, fin] du morceau et range l'extrait chez l'artiste. Renvoie le fichier créé.

    `fondu` (secondes) ajoute un fondu d'entrée et de sortie, pour éviter les claquements.
    """
    debut, fin = max(0.0, float(debut)), float(fin)
    if fin - debut < 0.05:
        raise ValueError("L'extrait est trop court")
    if not nom_propre(nom):
        raise ValueError("Donne un nom à l'extrait")
    artiste = artiste or MORCEAUX
    dest_d = dossier(cfg) / artiste
    dest_d.mkdir(parents=True, exist_ok=True)
    cible = _libre(dest_d, nom, ".m4a")
    longueur = fin - debut
    filtres = []
    f = max(0.0, min(float(fondu or 0), longueur / 2))
    if f > 0.01:
        filtres = [f"afade=t=in:st=0:d={f:.3f}", f"afade=t=out:st={longueur - f:.3f}:d={f:.3f}"]
    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error",
           "-ss", f"{debut:.3f}", "-i", str(source), "-t", f"{longueur:.3f}"]
    if filtres:
        cmd += ["-af", ",".join(filtres)]
    cmd += ["-vn", "-c:a", "aac", "-b:a", "192k", str(cible)]
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0 or not cible.exists():
        cible.unlink(missing_ok=True)
        raise RuntimeError((r.stderr or "").strip()[-600:] or "ffmpeg n'a pas pu découper l'extrait")
    return cible


def forme_onde(f: Path, largeur: int = 1200, hauteur: int = 180, couleur: str = "ff2d55",
               debut: float = 0.0, longueur: float | None = None) -> Path | None:
    """Image de la forme d'onde (mise en cache). `debut`/`longueur` dessinent un passage zoomé."""
    debut = max(0.0, float(debut or 0))
    longueur = float(longueur) if longueur else None
    try:
        FORMES.mkdir(parents=True, exist_ok=True)
        # empreinte stable d'un lancement à l'autre (hash() est tiré au sort à chaque démarrage)
        graine = (f"{f}|{int(f.stat().st_mtime)}|{largeur}x{hauteur}|"
                  f"{debut:.3f}|{longueur or 0:.3f}").encode("utf-8", "replace")
        marque = hashlib.md5(graine).hexdigest()[:12]
    except OSError:
        return None
    img = FORMES / f"{f.stem}_{marque}.png"
    if img.exists() and img.stat().st_size > 0:
        return img
    filtre = (f"aformat=channel_layouts=mono,compand=gain=4,"
              f"showwavespic=s={largeur}x{hauteur}:colors=#{couleur}")
    decoupe = (["-ss", f"{debut:.3f}"] if debut > 0 else []) + (["-t", f"{longueur:.3f}"] if longueur else [])
    r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *decoupe, "-i", str(f),
                        "-filter_complex", filtre, "-frames:v", "1", str(img)],
                       capture_output=True, text=True)
    if r.returncode != 0 or not img.exists() or img.stat().st_size == 0:
        img.unlink(missing_ok=True)
        return None
    return img


def rogner(chemin: Path, debut: float, fin: float) -> Path:
    """Copie raccourcie d'un audio, gardée en cache : sert à n'utiliser qu'une partie d'un extrait.

    Renvoie le fichier d'origine si rien n'est à couper.
    """
    chemin = Path(chemin)
    d = max(0.0, float(debut or 0))
    f = float(fin or 0)
    totale = duree(chemin)
    if f <= 0 or f > totale - 0.05:
        f = totale
    if d <= 0.05 and f >= totale - 0.05:
        return chemin
    if f - d < 0.2:
        return chemin
    dossier_tmp = DOSSIER_DONNEES / "extraits"
    dossier_tmp.mkdir(parents=True, exist_ok=True)
    try:
        graine = f"{chemin}|{int(chemin.stat().st_mtime)}|{d:.2f}|{f:.2f}".encode("utf-8", "replace")
    except OSError:
        return chemin
    cible = dossier_tmp / f"{nom_propre(chemin.stem)[:40]}_{hashlib.md5(graine).hexdigest()[:10]}.m4a"
    if cible.exists() and cible.stat().st_size > 0:
        return cible
    r = subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{d:.3f}",
                        "-i", str(chemin), "-t", f"{f - d:.3f}", "-vn", "-c:a", "aac", "-b:a", "192k",
                        str(cible)], capture_output=True, text=True)
    if r.returncode != 0 or not cible.exists():
        cible.unlink(missing_ok=True)
        return chemin
    # ménage : on ne garde pas une infinité de rognages
    fichiers = sorted(dossier_tmp.glob("*.m4a"), key=lambda p: p.stat().st_mtime)
    for vieux in fichiers[:-40]:
        vieux.unlink(missing_ok=True)
    return cible
