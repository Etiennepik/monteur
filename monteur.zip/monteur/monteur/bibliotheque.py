"""Bibliothèque vidéo : un dossier par thème, état « utilisée », miniatures, classement automatique."""
from __future__ import annotations

import datetime as dt
import shutil
import subprocess
import unicodedata
from pathlib import Path

from . import stockage
from .config import DOSSIER_DONNEES, chemin, sauver

A_CLASSER = "_a_classer"
EXT_VIDEO = {".mp4", ".mov", ".m4v", ".webm", ".mkv"}
ETATS = DOSSIER_DONNEES / "videos.json"
MINIATURES = DOSSIER_DONNEES / "miniatures"


def nom_affiche(theme: str) -> str:
    return "📥 À classer" if theme == A_CLASSER else theme


def _slug_theme(nom: str) -> str:
    nom = " ".join(str(nom).strip().split())
    for c in '/\\:*?"<>|':
        nom = nom.replace(c, "-")
    return nom.strip(". ")


# ───────────── thèmes ─────────────

def themes(cfg: dict) -> list[str]:
    """Thèmes de la config + dossiers déjà présents dans la bibliothèque / le centre de contrôle."""
    noms = set(cfg["themes"].keys())
    for cle in ("bibliotheque", "centre_controle"):
        d = chemin(cfg, cle)
        try:                                   # un dossier partagé (Drive) peut ne pas répondre
            if d.is_dir():
                noms |= {p.name for p in d.iterdir() if p.is_dir() and not p.name.startswith((".", "_"))}
        except OSError:
            continue
    return sorted(noms, key=str.lower)


def synchroniser(cfg: dict) -> bool:
    """Crée les dossiers manquants et ajoute à la config les dossiers créés à la main. Renvoie True si config modifiée."""
    modif = False
    try:
        for t in themes(cfg):
            if t not in cfg["themes"]:
                cfg["themes"][t] = {"mots_cles": []}
                modif = True
            (chemin(cfg, "bibliotheque") / t).mkdir(parents=True, exist_ok=True)
            (chemin(cfg, "centre_controle") / t).mkdir(parents=True, exist_ok=True)
        (chemin(cfg, "bibliotheque") / A_CLASSER).mkdir(parents=True, exist_ok=True)
    except OSError:
        return modif                           # dossier injoignable : on n'empêche pas Monteur de tourner
    if modif:
        sauver(cfg)
    return modif


def creer_theme(cfg: dict, nom: str) -> str:
    nom = _slug_theme(nom)
    if not nom or nom.startswith("_"):
        raise ValueError("Nom de thème invalide")
    cfg["themes"].setdefault(nom, {"mots_cles": []})
    sauver(cfg)
    synchroniser(cfg)
    return nom


def renommer_theme(cfg: dict, ancien: str, nouveau: str) -> str:
    from . import captions
    nouveau = _slug_theme(nouveau)
    if not nouveau or nouveau in themes(cfg):
        raise ValueError("Nom invalide ou déjà utilisé")
    for cle in ("bibliotheque", "centre_controle"):
        a, n = chemin(cfg, cle) / ancien, chemin(cfg, cle) / nouveau
        if a.is_dir():
            a.rename(n)
    t = cfg["themes"].pop(ancien, {"mots_cles": []})
    # on retient l'ancien nom : un onglet du Google Sheet qui le porte encore ne recrée pas un thème
    onglets = [o for o in t.get("onglets", []) if o.lower() != nouveau.lower()]
    if ancien.lower() not in [o.lower() for o in onglets]:
        onglets.append(ancien)
    t["onglets"] = onglets
    cfg["themes"][nouveau] = t
    sauver(cfg)
    captions.renommer_theme(ancien, nouveau)
    synchroniser(cfg)
    return nouveau


def supprimer_theme(cfg: dict, nom: str) -> int:
    """Supprime un thème : ses vidéos originales passent dans « À classer ». Renvoie le nb de vidéos déplacées."""
    n = 0
    for v in videos(cfg, nom):
        deplacer(cfg, v["nom"], A_CLASSER)
        n += 1
    d = chemin(cfg, "bibliotheque") / nom
    shutil.rmtree(d, ignore_errors=True)
    c = chemin(cfg, "centre_controle") / nom
    if c.is_dir() and not any(c.iterdir()):
        c.rmdir()
    cfg["themes"].pop(nom, None)
    sauver(cfg)
    return n


# ───────────── vidéos ─────────────

def meta(video: Path) -> dict:
    j = video.with_suffix(".info.json")
    d = stockage.lire(j, {}) if j.exists() else {}
    return {
        "titre": d.get("title") or video.stem,
        "description": d.get("description") or "",
        "tags": d.get("tags") or [],
        "url": d.get("webpage_url") or d.get("original_url") or "",
        "compte": d.get("uploader") or d.get("channel") or d.get("uploader_id") or "",
        "duree": d.get("duration"),
    }


def etats() -> dict:
    return stockage.lire(ETATS, {})


def videos(cfg: dict, theme: str | None = None) -> list[dict]:
    """Liste des vidéos (d'un thème ou de toute la bibliothèque), avec leur état."""
    racine = chemin(cfg, "bibliotheque")
    et = etats()
    try:
        dossiers = [racine / theme] if theme else [p for p in racine.iterdir() if p.is_dir()] if racine.is_dir() else []
    except OSError:
        return []
    out = []
    for d in dossiers:
        try:
            if not d.is_dir():
                continue
            fichiers = sorted(d.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True)
        except OSError:
            continue
        for f in fichiers:
            if f.suffix.lower() in EXT_VIDEO and not f.name.startswith("."):
                e = et.get(f.name, {})
                out.append({"nom": f.name, "chemin": f, "theme": d.name, **meta(f),
                            "utilisee": bool(e.get("utilisee")), "utilisee_le": e.get("utilisee_le"),
                            "exports": e.get("exports", []), "ajoutee_le": e.get("ajoutee_le"),
                            # None = jamais analysée ; True / False = caption déjà incrustée ou non
                            "caption_incrustee": e.get("caption_incrustee"),
                            "caption_texte": e.get("caption_texte") or "",
                            "etiquettes": e.get("etiquettes") or [],
                            # [[début, fin], …] ; un seul élément = plan séquence (aucune coupe)
                            "plans": e.get("plans") or []})
    return out


def trouver(cfg: dict, nom: str) -> dict | None:
    return next((v for v in videos(cfg) if v["nom"] == nom), None)


def deplacer(cfg: dict, nom: str, theme: str) -> Path | None:
    v = trouver(cfg, nom)
    if not v:
        return None
    dest_dir = chemin(cfg, "bibliotheque") / theme
    dest_dir.mkdir(parents=True, exist_ok=True)
    dest = dest_dir / v["chemin"].name
    if dest == v["chemin"]:
        return dest
    shutil.move(str(v["chemin"]), dest)
    info = v["chemin"].with_suffix(".info.json")
    if info.exists():
        shutil.move(str(info), dest.with_suffix(".info.json"))
    return dest


def supprimer(cfg: dict, nom: str) -> bool:
    v = trouver(cfg, nom)
    if not v:
        return False
    for p in (v["chemin"], v["chemin"].with_suffix(".info.json"), MINIATURES / f"{v['chemin'].stem}.jpg"):
        try:
            p.unlink()
        except FileNotFoundError:
            pass
    stockage.modifier(ETATS, {}, lambda d: {k: x for k, x in d.items() if k != nom})
    return True


def marquer(nom: str, utilisee: bool, export: str | None = None, caption: str | None = None) -> None:
    def f(d):
        e = d.setdefault(nom, {})
        e["utilisee"] = utilisee
        if utilisee:
            e["utilisee_le"] = dt.datetime.now().isoformat(timespec="seconds")
            if export:
                e.setdefault("exports", []).append({"fichier": export, "caption": caption, "le": e["utilisee_le"]})
        else:
            e["utilisee_le"] = None
        return d
    stockage.modifier(ETATS, {}, f)


def noter_caption(nom: str, presente: bool | None, texte: str = "", etiquettes: list | None = None,
                  plans: list | None = None) -> None:
    """Retient si la vidéo porte déjà une phrase incrustée (None = à analyser de nouveau)."""
    def f(d):
        e = d.setdefault(nom, {})
        if presente is None:
            e.pop("caption_incrustee", None)
            e.pop("caption_texte", None)
            e.pop("caption_le", None)
            e.pop("etiquettes", None)
            e.pop("plans", None)
        else:
            e["caption_incrustee"] = bool(presente)
            e["caption_texte"] = (texte or "")[:300]
            e["caption_le"] = dt.datetime.now().isoformat(timespec="seconds")
            if etiquettes is not None:
                e["etiquettes"] = [[str(n), round(float(c), 3)] for n, c in etiquettes][:14]
            if plans is not None:
                e["plans"] = [[round(float(a), 2), round(float(b), 2)] for a, b in plans][:200]
        return d
    stockage.modifier(ETATS, {}, f)


def analyser(cfg: dict, video: dict, forcer: bool = False) -> dict:
    """Lit la vidéo une fois : texte déjà incrusté, ce qu'elle montre, et son découpage en plans.

    Le résultat est mémorisé. Si une vidéo a été analysée par une version précédente de Monteur, il
    lui manque le découpage en plans : on le calcule sans refaire le reste (sinon elle passerait à
    tort pour un plan séquence).
    """
    from . import quotes
    from .rendu import plans_video
    deja_lue = video.get("caption_incrustee") is not None
    if not forcer and deja_lue and video.get("plans"):
        return {"presente": bool(video["caption_incrustee"]), "texte": video.get("caption_texte") or "",
                "etiquettes": video.get("etiquettes") or [], "plans": video.get("plans") or []}
    if not forcer and deja_lue:
        try:
            decoupe = plans_video(video["chemin"])
        except Exception:  # noqa: BLE001
            decoupe = []
        noter_caption(video["nom"], bool(video["caption_incrustee"]), video.get("caption_texte") or "",
                      video.get("etiquettes") or [], decoupe)
        return {"presente": bool(video["caption_incrustee"]), "texte": video.get("caption_texte") or "",
                "etiquettes": video.get("etiquettes") or [], "plans": decoupe}
    tmp = DOSSIER_DONNEES / "tmp_analyse" / video["nom"]
    try:
        r = quotes.analyser_video(video["chemin"], tmp)
    except Exception:  # noqa: BLE001
        return {"presente": False, "texte": "", "etiquettes": [], "plans": []}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    try:
        r["plans"] = plans_video(video["chemin"])          # découpage en plans (ou plan séquence)
    except Exception:  # noqa: BLE001
        r["plans"] = []
    noter_caption(video["nom"], r["presente"], r["texte"], r.get("etiquettes"), r.get("plans"))
    return r


def analyser_caption(cfg: dict, video: dict, forcer: bool = False) -> bool:
    """Verdict « cette vidéo a déjà une caption », calculé une fois puis mémorisé."""
    return bool(analyser(cfg, video, forcer).get("presente"))


def sac_video(cfg: dict, video: dict, analyser_si_besoin: bool = True) -> dict:
    """Ce que raconte la vidéo, pour y assortir une caption (voir `assortir.py`)."""
    from . import assortir
    r = analyser(cfg, video) if (analyser_si_besoin and video.get("caption_incrustee") is None) else {
        "texte": video.get("caption_texte") or "", "etiquettes": video.get("etiquettes") or []}
    m = meta(video["chemin"])
    meta_texte = " ".join([m.get("titre") or "", m.get("description") or "",
                           " ".join(map(str, m.get("tags") or [])), m.get("compte") or ""])
    return assortir.sac_video(r.get("etiquettes") or [], r.get("texte") or "", meta_texte)


def noter_ajout(nom: str) -> None:
    stockage.modifier(ETATS, {}, lambda d: {**d, nom: {**d.get(nom, {}),
                                                       "ajoutee_le": dt.datetime.now().isoformat(timespec="seconds")}})


def miniature(video: Path) -> Path | None:
    MINIATURES.mkdir(parents=True, exist_ok=True)
    m = MINIATURES / f"{video.stem}.jpg"
    if not m.exists() or m.stat().st_mtime < video.stat().st_mtime:
        for t in ("1", "0"):
            subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-ss", t, "-i", str(video), "-frames:v", "1",
                            "-vf", "scale=360:-2", "-q:v", "4", str(m)], capture_output=True)
            if m.exists() and m.stat().st_size > 0:
                break
    return m if m.exists() else None


def miniature_45(video: Path) -> Path | None:
    """Vignette recadrée en 4:5 : toutes les vidéos s'affichent au même format dans la bibliothèque."""
    MINIATURES.mkdir(parents=True, exist_ok=True)
    m = MINIATURES / f"{video.stem}_45.jpg"
    if m.exists() and m.stat().st_mtime >= video.stat().st_mtime:
        return m
    source = miniature(video)
    if not source:
        return None
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(source), "-vf",
                    "scale=440:550:force_original_aspect_ratio=increase,crop=440:550", "-q:v", "4", str(m)],
                   capture_output=True)
    return m if m.exists() and m.stat().st_size > 0 else source


# ───────────── classement automatique ─────────────

def _norm(s: str) -> str:
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn")


def deviner_theme(cfg: dict, video: Path) -> str | None:
    m = meta(video)
    texte = _norm(" ".join([m["titre"], m["description"], " ".join(map(str, m["tags"])), m["compte"]]))
    meilleur, score_max = None, 0
    for nom, th in cfg["themes"].items():
        mots = [*th.get("mots_cles", []), nom]
        score = sum(texte.count(_norm(x)) for x in mots if x and len(x) > 2)
        if score > score_max:
            meilleur, score_max = nom, score
    return meilleur


def classer_a_classer(cfg: dict) -> tuple[int, int]:
    """Essaie de classer les vidéos « À classer ». Renvoie (classées, restantes)."""
    ok = reste = 0
    for v in videos(cfg, A_CLASSER):
        t = deviner_theme(cfg, v["chemin"])
        if t:
            deplacer(cfg, v["nom"], t)
            ok += 1
        else:
            reste += 1
    return ok, reste


def comptes_par_theme(cfg: dict) -> dict[str, dict]:
    out = {}
    for v in videos(cfg):
        c = out.setdefault(v["theme"], {"total": 0, "utilisees": 0})
        c["total"] += 1
        c["utilisees"] += v["utilisee"]
    return out


def importer_fichiers(cfg: dict, fichiers: list[tuple[str, bytes]], theme: str) -> int:
    d = chemin(cfg, "bibliotheque") / theme
    d.mkdir(parents=True, exist_ok=True)
    for nom, data in fichiers:
        (d / Path(nom).name).write_bytes(data)
        noter_ajout(Path(nom).name)
    return len(fichiers)


FICHES = "_fiches"          # les fiches .json et les index vivent à part : le dossier des exports
                            # ne contient que les vidéos, rangées par thème


def dossier_fiches(cfg: dict) -> Path:
    d = chemin(cfg, "centre_controle") / FICHES
    d.mkdir(parents=True, exist_ok=True)
    return d


def fiche(cfg: dict, theme: str, video: Path) -> Path:
    """Emplacement de la fiche .json d'une vidéo montée (hors du dossier des exports)."""
    d = dossier_fiches(cfg) / theme
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{video.stem}.json"


def _ranger_anciennes_fiches(racine: Path) -> int:
    """Déplace dans _fiches/ les .json des versions précédentes, posés à côté des vidéos."""
    bouges = 0
    try:
        for j in list(racine.rglob("*.json")):
            if FICHES in j.parts or j.name.startswith("index"):
                continue
            cible = racine / FICHES / j.parent.relative_to(racine) / j.name
            cible.parent.mkdir(parents=True, exist_ok=True)
            try:
                j.replace(cible)
                bouges += 1
            except OSError:
                continue
        for vieux in (racine / "index.json", racine / "index.csv"):
            if vieux.exists():
                try:
                    vieux.replace(racine / FICHES / vieux.name)
                except OSError:
                    vieux.unlink(missing_ok=True)
    except OSError:
        pass
    return bouges


def exporter_index(cfg: dict) -> Path:
    """Index du centre de contrôle (_fiches/index.json + index.csv) à partir des fiches .json."""
    import csv
    racine = chemin(cfg, "centre_controle")
    racine.mkdir(parents=True, exist_ok=True)
    fiches = dossier_fiches(cfg)
    _ranger_anciennes_fiches(racine)
    lignes = []
    for j in sorted(fiches.rglob("*.json")):
        if j.name.startswith("index"):
            continue
        d = stockage.lire(j, None)
        video = racine / j.parent.relative_to(fiches) / f"{j.stem}.mp4"
        if d and video.exists():
            d["chemin"] = str(video.relative_to(racine))
            lignes.append(d)
    stockage.ecrire(fiches / "index.json", lignes)
    with open(fiches / "index.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["chemin", "theme", "caption", "statut", "duree_s", "video_originale",
                                          "url_originale", "cree_le"], extrasaction="ignore")
        w.writeheader()
        w.writerows(lignes)
    return fiches / "index.json"
