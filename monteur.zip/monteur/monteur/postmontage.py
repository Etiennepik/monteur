"""Post-montage : fusion vidéo + caption, export vers le centre de contrôle, montage en série."""
from __future__ import annotations

import datetime as dt
import random
import re
import shutil
from pathlib import Path

from . import assortir, bibliotheque, captions, stockage
from .config import DOSSIER_DONNEES, chemin
from .logo import detecter
from . import paroles as paroles_mod
from .rendu import dimensions_export, mesurer_bloc, monter, monter_plans, sonder


def audios_duree(f: Path) -> float:
    from . import audios
    return audios.duree(f)

TMP = DOSSIER_DONNEES / "tmp"

# sous-dossiers d'un thème dans le centre de contrôle, selon ce qui est écrit sur la vidéo
SOUS_DOSSIERS = ("captions", "paroles", "paroles + captions")


def sous_dossier(caption: str, lignes: list | None) -> str:
    """« captions », « paroles » ou « paroles + captions » ; "" quand la vidéo n'a aucun texte."""
    c, p = bool((caption or "").strip()), bool(lignes)
    return "paroles + captions" if (c and p) else "paroles" if p else "captions" if c else ""


MEME_THEME = "="          # « les captions du thème de la vidéo » dans une série multi-thèmes


def dossier_export(theme_video: str, theme_caption: str | None, caption: str, lignes: list | None) -> str:
    """Où ranger un export dans le centre de contrôle.

    <thème vidéo>/captions/<thème caption>            caption seule
    <thème vidéo>/paroles + captions/<thème caption>  caption + paroles
    <thème vidéo>/paroles                             paroles seules (aucune caption, donc aucun thème)
    <thème vidéo>                                     sans texte
    """
    sous = sous_dossier(caption, lignes)
    if not sous:
        return theme_video
    if sous == "paroles":
        return f"{theme_video}/paroles"
    th_c = theme_caption if theme_caption and theme_caption != MEME_THEME else theme_video
    return f"{theme_video}/{sous}/{th_c}"


def nom_audio(audio: dict | None) -> str:
    """Nom de l'extrait audio, propre à mettre dans un nom de fichier."""
    if not audio:
        return ""
    n = audio.get("nom") or ""
    if not n:
        src = str(audio.get("source") or audio.get("chemin") or "")
        n = Path(src).stem if src else ""
    n = re.sub(r'[\\/:*?"<>|\s]+', " ", str(n)).strip()
    return n[:40].strip()


def nom_export(horodatage: str, audio: dict | None, reste: str) -> str:
    a = nom_audio(audio)
    return f"{horodatage}_{a}_{reste}.mp4" if a else f"{horodatage}_{reste}.mp4"


def exporter(cfg: dict, video: dict, theme: str, caption: str, style: dict, plein_ecran: bool,
             logo: dict | None, coupe: tuple[float, float] | None = None,
             cadrage_paysage: str = "bandes", decalage: float = 50.0,
             audio: dict | None = None, theme_caption: str | None = None,
             paroles: dict | None = None) -> Path:
    """Monte la vidéo et la range dans <centre de contrôle>/<thème>/. Marque vidéo + caption comme utilisées.

    `theme` décide du sous-dossier d'export (c'est le thème des vidéos) ; `theme_caption` dit où la
    quote est rangée, quand elle vient d'un autre thème.
    """
    src: Path = video["chemin"]
    info = sonder(src)
    W, H, cadrage = dimensions_export(info, plein_ecran, cfg, cadrage_paysage)
    horodatage = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    theme_dest = theme                   # le thème des vidéos décide du sous-dossier d'export
    duree_sortie = (coupe[1] - coupe[0]) if coupe else info["duree"]
    lignes_p = paroles_mod.borner((paroles or {}).get("lignes") or [], duree_sortie)
    st_cap, st_par = placer_textes(cfg, caption, style, lignes_p, W, H,
                                   (paroles or {}).get("position") or "bas",
                                   (paroles or {}).get("habillage"))
    if st_cap is None:                   # caption trop proche des paroles : on l'abandonne
        caption = ""
    sous = sous_dossier(caption, lignes_p)
    dossier_f = dossier_export(theme_dest, theme_caption, caption, lignes_p)
    dest = chemin(cfg, "centre_controle") / dossier_f / nom_export(horodatage, audio, src.stem)
    calques = [(caption, st_cap)] if caption.strip() else []
    bande = {"lignes": lignes_p, "style": st_par} if lignes_p else None
    monter(cfg, src, dest, logo, W, H, cadrage, calques, TMP, info, coupe, decalage, audio, bande)
    shutil.rmtree(TMP, ignore_errors=True)

    stockage.ecrire(bibliotheque.fiche(cfg, dossier_f, dest), {
        "fichier": dest.name,
        "theme": theme_dest,
        "contenu": sous or "sans texte",
        "caption": caption,
        "statut": "pret",                    # le centre de contrôle passe à "publie"
        "format": f"{W}x{H}",
        "duree_s": round((coupe[1] - coupe[0]) if coupe else info["duree"], 2),
        "video_originale": src.name,
        "url_originale": video.get("url", ""),
        "compte_original": video.get("compte", ""),
        "logo_retire": bool(logo and logo.get("mode") in ("flou", "masque") and logo.get("zones")),
        "audio": nom_audio(audio) if audio and audio.get("chemin") else "",
        "son": "muet" if (audio or {}).get("muet") else "avec",
        "cree_le": dt.datetime.now().isoformat(timespec="seconds"),
    })
    rel = str(dest.relative_to(chemin(cfg, "centre_controle")))
    bibliotheque.marquer(src.name, True, export=rel, caption=caption)
    if caption.strip():
        captions.marquer(theme_caption or theme, caption, src.name)
    bibliotheque.exporter_index(cfg)
    return dest


POSITIONS = {"haut": 18, "milieu": 50, "bas": 80}
BANDE_HAUTE, BANDE_BASSE, BANDE_CENTRE = 20.0, 78.0, 50.0
BANDES_PAROLES = {"haut": BANDE_HAUTE, "centre": BANDE_CENTRE, "bas": BANDE_BASSE}
MARGE_TEXTES = 3.0        # écart minimal entre les deux blocs, en % de la hauteur


def placer_textes(cfg: dict, caption: str, style_cap: dict, lignes: list[dict], W: int, H: int,
                  position: str = "bas", style_par: dict | None = None) -> tuple[dict | None, dict]:
    """Place la caption et les paroles. Renvoie (style de la caption **ou None**, style des paroles).

    Les paroles vont là où on les demande : en haut, au centre ou en bas. La caption se range dans
    une bande restée libre — l'opposée, et au-dessus quand les paroles sont au centre (en dessous si
    la caption était plutôt basse). Si malgré tout les deux blocs se touchent ou se frôlent (paroles
    écrites en gros, caption longue), **la caption est abandonnée** : l'export se fait sans elle, et
    elle n'est pas consommée.
    """
    y_par = BANDES_PAROLES.get(str(position or "bas"), BANDE_BASSE)
    # les paroles ont leur propre habillage ; à défaut, celui de la caption
    st_par = {**(style_par or style_cap), "position_y": y_par, "debut_s": 0, "fin_s": 0}
    st_cap = dict(style_cap)
    if not (caption or "").strip() or not lignes:
        return st_cap, st_par

    y_cap_voulu = float(style_cap.get("position_y") or 50)
    if position == "haut":
        st_cap["position_y"] = BANDE_BASSE
    elif position == "bas":
        st_cap["position_y"] = BANDE_HAUTE
    else:                                   # paroles au centre : la caption prend un bord
        st_cap["position_y"] = BANDE_HAUTE if y_cap_voulu <= 50 else BANDE_BASSE

    try:
        _, h_cap = mesurer_bloc(cfg, caption, st_cap, W, H)
        h_par = max(mesurer_bloc(cfg, str(l["texte"]), st_par, W, H)[1] for l in lignes)
    except Exception:  # noqa: BLE001
        return st_cap, st_par
    y_cap = float(st_cap["position_y"])
    bords_cap = (y_cap - h_cap / 2, y_cap + h_cap / 2)
    bords_par = (y_par - h_par / 2, y_par + h_par / 2)
    ecart = max(bords_par[0] - bords_cap[1], bords_cap[0] - bords_par[1])
    if ecart < MARGE_TEXTES:
        return None, st_par                 # trop serré : on garde les paroles, on lâche la caption
    return st_cap, st_par


def variantes(styles: list[dict], positions: list[str] | None) -> list[dict]:
    """Toutes les façons d'écrire la caption : chaque style croisé avec chaque position demandée."""
    out = []
    for s in styles or []:
        if not positions:
            out.append(dict(s))
            continue
        for p in positions:
            if p in POSITIONS:
                out.append({**s, "position_y": POSITIONS[p]})
    return out or [dict(s) for s in (styles or [])]


def serie(cfg: dict, theme: str | list[str], n: int, style: dict, plein_ecran: bool, mode_logo: str, log=print,
          styles: list[dict] | None = None, positions: list[str] | None = None,
          repartition: str = "hasard", sans_caption: bool = False, audio: dict | None = None,
          theme_caption: str | list[str] | None = None, eviter_doublon: bool = True,
          assortir_sens: bool = False, sans_si_rien: bool = True, seuil: float = 0.6,
          rythme_audio: dict | None = None, rythme_opts: dict | None = None,
          structure: str = "par_video", paroles: dict | None = None,
          textes: str = "captions", audios: list[dict] | None = None,
          styles_paroles: list[dict] | None = None, muet: bool = False) -> int:
    """Monte jusqu'à n vidéos non utilisées du thème (ou des thèmes).

    theme : un thème de vidéos, ou plusieurs — ils se relaient d'un export à l'autre ; chaque export
    est rangé dans le dossier du thème de SA vidéo.
    theme_caption : un thème de captions ou plusieurs (répartis comme les habillages) ; MEME_THEME
    veut dire « le thème de la vidéo ». Un thème épuisé laisse la place aux autres.

    sans_caption : aucune quote n'est ajoutée (les captions du thème ne sont pas consommées).
    theme_caption : prendre les quotes dans un autre thème que celui des vidéos.
    eviter_doublon : une vidéo qui porte déjà une phrase incrustée est montée telle quelle (aucune
    quote ajoutée par-dessus, et aucune caption consommée).
    assortir_sens : choisir la caption qui parle de ce que montre la vidéo plutôt qu'au hasard.
    sans_si_rien : quand aucune caption ne colle, monter sans texte (sinon, en prendre une au hasard).
    rythme_audio : au lieu de garder la vidéo entière, la **remonter sur cet audio** en mélangeant ses
    propres rushs (voir `montage_rythme`). Les plans séquences sont écartés : ils n'ont rien à remonter.
    structure : "par_video" (un export par vidéo) ou "melange" (chaque export mélange les rushs de
    plusieurs vidéos du thème).
    styles / positions : variété d'habillage. `repartition` = "hasard" ou "tour" (à tour de rôle).
    audio : même extrait audio pour toute la série (voir rendu.monter).
    textes : ce qui s'écrit sur les vidéos — "captions" (comme avant), "paroles" (seulement les
    paroles du morceau) ou "deux" (les deux, placées de façon à ne jamais se chevaucher).
    paroles : {"lignes": [{"texte", "debut", "fin"}, …]} pour les modes "paroles" et "deux".
    mode_logo : "aucun" | "flou" | "masque" (avec détection automatique de la zone par vidéo).
    audios : plusieurs extraits répartis sur la série (au hasard ou à tour de rôle) ; chacun peut
    porter ses propres paroles dans a["paroles"]. Remplace `audio` / `paroles` quand il est fourni.
    styles_paroles : un ou plusieurs habillages pour les paroles (sinon celui de la caption).
    muet : aucune piste son dans les exports (l'audio sert seulement au rythme et aux paroles).
    """
    # ── les extraits audio de la série, chacun avec ses paroles ──
    liste_a = [dict(a) for a in (audios or []) if a]
    if not liste_a and audio:
        liste_a = [{**audio, "paroles": paroles}]
    elif liste_a and paroles and not any(a.get("paroles") for a in liste_a):
        liste_a[0]["paroles"] = paroles

    def tirer(liste: list, i: int):
        if not liste:
            return None
        if len(liste) == 1:
            return liste[0]
        return random.choice(liste) if repartition == "hasard" else liste[i % len(liste)]

    def audio_de(i: int) -> dict | None:
        a = tirer(liste_a, i)
        if muet:
            return {**a, "muet": True} if a else {"muet": True}
        return a

    def paroles_de(aud: dict | None, i: int) -> dict | None:
        p = (aud or {}).get("paroles") if liste_a else paroles
        if not (p or {}).get("lignes"):
            return None
        return {**p, "habillage": tirer(list(styles_paroles or []), i)}

    # `textes` peut lister plusieurs combinaisons : la série les alterne d'un export à l'autre
    demandes = textes if isinstance(textes, (list, tuple, set)) else [textes]
    MODES_T = ("captions", "paroles", "deux", "rien")
    modes_t = [m for m in demandes if m in MODES_T] or ["captions"]
    a_des_paroles = (any(((a.get("paroles") or {}).get("lignes")) for a in liste_a) if liste_a
                     else bool((paroles or {}).get("lignes")))
    if not a_des_paroles:
        modes_t = [("captions" if m == "deux" else "rien" if m == "paroles" else m) for m in modes_t]
        modes_t = list(dict.fromkeys(modes_t))
    if sans_caption:                   # l'ancien interrupteur « sans caption » reste prioritaire
        modes_t = [("paroles" if m in ("paroles", "deux") else "rien") for m in modes_t]
        modes_t = list(dict.fromkeys(modes_t))

    def mode_texte(i: int) -> str:
        if len(modes_t) == 1:
            return modes_t[0]
        return random.choice(modes_t) if repartition == "hasard" else modes_t[i % len(modes_t)]

    def bande_de(mode: str, p: dict | None):
        return p if (mode in ("paroles", "deux") and p) else None

    def mode_pour(mode: str, p: dict | None) -> str:
        """Un extrait sans paroles : « deux » devient « captions », « paroles » devient « rien »."""
        if p or mode not in ("paroles", "deux"):
            return mode
        return "captions" if (mode == "deux" and not sans_caption) else "rien"

    choix = variantes(styles or [style], positions)
    if repartition == "hasard":
        random.shuffle(choix)
    opts = dict(rythme_opts or {})

    # ── plusieurs thèmes : vidéos d'un ou plusieurs thèmes, captions d'un ou plusieurs thèmes ──
    themes_v = [theme] if isinstance(theme, str) else [t for t in (theme or []) if t]
    themes_v = list(dict.fromkeys(themes_v))
    if isinstance(theme_caption, (list, tuple, set)):
        themes_c = [t for t in theme_caption if t] or [MEME_THEME]
    else:
        themes_c = [theme_caption or MEME_THEME]
    themes_c = list(dict.fromkeys(themes_c))
    if not themes_v:
        log("⚠ Aucun thème de vidéos choisi.")
        return 0

    def themes_caption_de(th_v: str) -> list[str]:
        """Les thèmes où la vidéo de ce thème peut prendre sa caption."""
        return list(dict.fromkeys(th_v if t == MEME_THEME else t for t in themes_c))

    def tirer_caption(th_v: str, i: int) -> tuple[str | None, dict | None]:
        """Une caption libre pour une vidéo de `th_v` ; un thème épuisé laisse la place aux autres."""
        cands = themes_caption_de(th_v)
        if len(cands) > 1:
            premier = random.choice(cands) if repartition == "hasard" else cands[i % len(cands)]
            cands = [premier] + [c for c in cands if c != premier]
        for t in cands:
            c = captions.tirer(t)
            if c is not None:
                return t, c
        return None, None

    def noms(l):
        return ", ".join(f"« {x} »" for x in l)

    if structure == "melange":
        # chaque export mélange les rushs de plusieurs vidéos d'UN thème (les thèmes se relaient
        # d'un montage à l'autre) : une quote par montage.
        # Par défaut on ne marque PAS les vidéos « utilisées » : un mélange les reprend toutes, et
        # le deuxième montage de la série n'aurait alors plus rien à se mettre sous la dent.
        marquer_v = bool(opts.pop("marquer", False))
        from .rushs import Reserve
        pools = {}
        for t in themes_v:
            pool = [v for v in bibliotheque.videos(cfg, t) if not v["utilisee"]]
            if eviter_doublon:
                pool = [v for v in pool if not v.get("caption_incrustee")]
            if pool:
                pools[t] = pool
            else:
                log(f"⚠ Aucune vidéo disponible dans « {t} ».")
        if not pools:
            return 0
        themes_ok = list(pools)
        reserves = {}
        faites = 0
        for i in range(max(1, int(n))):
            th_v = tirer(themes_ok, i)
            if th_v not in reserves:
                log(f"🎞 Préparation des rushs de « {th_v} » (la première fois, quelques secondes par vidéo)…")
                reserves[th_v] = Reserve(pools[th_v], log)
            stl = random.choice(choix) if (repartition == "hasard" and len(choix) > 1) else \
                choix[i % len(choix)]
            aud = audio_de(i)
            par = paroles_de(aud, i)
            mode_t = mode_pour(mode_texte(i), par)
            bande = bande_de(mode_t, par)
            texte, th_c = "", None
            if mode_t in ("captions", "deux"):
                th_c, cap = tirer_caption(th_v, i)
                if cap is None:
                    log(f"⚠ Plus de caption libre dans {noms(themes_caption_de(th_v))} — montage "
                        f"{i + 1} passé.")
                    continue
                texte = cap["texte"]
            try:
                dest = montage_rythme(cfg, th_v, aud, stl, caption=texte,
                                      plein_ecran=plein_ecran, theme_caption=th_c,
                                      exclure_captionnees=eviter_doublon, marquer=marquer_v,
                                      nom_sortie=f"melange{i + 1}", paroles=bande, reserve=reserves[th_v],
                                      log=log, **opts)
                quoi = ([f"« {texte[:40]} »"] if texte else []) + (["paroles"] if bande else [])
                log(f"✅ {dest.parent.relative_to(chemin(cfg, 'centre_controle')).as_posix()}/{dest.name}  "
                    + (" + ".join(quoi) if quoi else "(sans texte)"))
                faites += 1
            except Exception as e:  # noqa: BLE001
                log(f"✖ montage {i + 1} : {e}")
        for t, r in reserves.items():
            log(f"🎞 Bilan « {t} » : {r.bilan()}.")
        return faites

    remonte = bool(rythme_audio or opts.get("cale") is False)   # il faut plusieurs plans par vidéo
    par_theme = []
    for t in themes_v:
        videos = [x for x in bibliotheque.videos(cfg, t) if not x["utilisee"]]
        if remonte:
            a_lire = [v for v in videos if not v.get("plans")]
            if a_lire:
                log(f"✂️ Repérage des coupes dans {len(a_lire)} vidéo(s) de « {t} » (quelques secondes chacune)…")
            gardees, ecartees = [], []
            for v in videos:
                if len(bibliotheque.analyser(cfg, v).get("plans") or []) >= 2:
                    gardees.append(v)
                else:
                    ecartees.append(v["nom"])
            if ecartees:
                log(f"   ⏭ {len(ecartees)} plan(s) séquence écarté(s) (aucune coupe trouvée) : "
                    f"{', '.join(ecartees[:4])}" + ("…" if len(ecartees) > 4 else ""))
            videos = gardees
        par_theme.append([{**v, "theme": v.get("theme") or t} for v in videos])
    if remonte and not any(par_theme):
        log("⚠ Aucune vidéo n'a de coupe interne : rien à remonter. Essaie « Mélanger les "
            "rushs du thème », qui assemble des extraits de plusieurs vidéos.")
    # les thèmes se relaient : une vidéo de chaque thème, puis on recommence
    videos = []
    for k in range(max((len(l) for l in par_theme), default=0)):
        videos += [l[k] for l in par_theme if k < len(l)]
    videos = videos[:n]

    # 1) quelles vidéos portent déjà une phrase à l'image (elles ne prendront pas de quote)
    porte_deja = {v["nom"]: bool(eviter_doublon and not sans_caption and bibliotheque.analyser_caption(cfg, v))
                  for v in videos}
    # 2) répartition des quotes sur toute la série d'un coup, par affinité décroissante
    assortiment, meilleures = {}, {}
    if assortir_sens and not sans_caption:
        ths_c = list(dict.fromkeys(t for v in videos for t in themes_caption_de(v["theme"])))
        libres = [{**c, "_theme": t} for t in ths_c for c in captions.liste(t) if not c.get("utilisee")]
        sacs = {v["nom"]: bibliotheque.sac_video(cfg, v) for v in videos if not porte_deja[v["nom"]]}
        theme_de = {v["nom"]: v["theme"] for v in videos}
        assortiment, meilleures = assortir.repartir(
            sacs, libres, seuil,
            admis=lambda nom, c: c.get("_theme") in themes_caption_de(theme_de[nom]))

    faites = 0
    for i, v in enumerate(videos):
        th_v = v["theme"]
        texte, th_c, stl = "", None, choix[i % len(choix)] if choix else style
        if repartition == "hasard" and len(choix) > 1:
            stl = random.choice(choix)
        deja = porte_deja.get(v["nom"], False)
        if deja:
            log(f"   ✎ « {v['nom']} » a déjà une caption à l'image — montée sans texte.")
        assorti = None
        aud = audio_de(i)
        par = paroles_de(aud, i)
        mode_t = mode_pour(mode_texte(i), par)
        bande = bande_de(mode_t, par)
        if mode_t in ("captions", "deux") and not deja:
            cap = None
            if assortir_sens:
                cap, assorti = assortiment.get(v["nom"], (None, None))
                if cap is not None:
                    th_c = cap.get("_theme")
                elif sans_si_rien:
                    log(f"   ○ aucune caption ne colle à « {v['nom']} » "
                        f"(meilleure note {meilleures.get(v['nom'], 0)}) — montée sans texte.")
            if cap is None and not (assortir_sens and sans_si_rien):
                th_c, cap = tirer_caption(th_v, i)
                if cap is None:
                    log(f"⚠ Plus de caption libre dans {noms(themes_caption_de(th_v))} — "
                        f"« {v['nom']} » passée.")
                    continue
            texte = cap["texte"] if cap else ""
        logo = None
        if mode_logo in ("flou", "masque"):
            d = detecter(v["chemin"], sonder(v["chemin"])["duree"])
            logo = {"mode": mode_logo, "zones": d.get("zones", [])}
            log(f"   logo : {d['message']}")
        try:
            if remonte:
                dest = montage_rythme(cfg, th_v, aud, stl, caption=texte,
                                      plein_ecran=plein_ecran, theme_caption=th_c,
                                      video=v, marquer=True, nom_sortie=f"remonte_{v['chemin'].stem[:22]}",
                                      paroles=bande, log=lambda m: None, **opts)
            else:
                dest = exporter(cfg, v, th_v, texte, stl, plein_ecran, logo, audio=aud,
                                theme_caption=th_c, paroles=bande)
            if mode_t == "rien":
                detail = "sans texte"
            elif mode_t == "paroles":
                detail = "paroles seules"
            elif deja:
                detail = "caption déjà à l'image"
            elif not texte:
                detail = "sans texte"
            else:
                detail = ("paroles + " if mode_t == "deux" else "") + (
                    f"caption assortie ({assorti}) à {stl.get('position_y')} %" if assorti is not None
                    else f"caption à {stl.get('position_y')} %")
            log(f"✅ {v['nom']} → {dest.parent.relative_to(chemin(cfg, 'centre_controle')).as_posix()}/"
                f"{dest.name}  ({detail})")
            faites += 1
        except Exception as e:  # noqa: BLE001
            log(f"✖ {v['nom']} : {e}")
    return faites


def _eviter_memes_bords(pile: list, premier, dernier, n: int) -> list:
    """Le montage ne doit ni commencer ni finir comme la vidéo d'origine.

    On échange le premier plan s'il est le premier rush de la vidéo, et le dernier s'il en est le
    dernier rush. Avec deux rushs seulement, ça revient à les inverser.
    """
    if n < 2 or len(pile) < n:
        return pile
    if pile[0] == premier:
        for k in range(1, n):
            if pile[k] != premier:
                pile[0], pile[k] = pile[k], pile[0]
                break
    if pile[n - 1] == dernier:
        remplace = False
        for k in range(n - 2, 0, -1):
            if pile[k] != dernier and pile[k] != premier:
                pile[n - 1], pile[k] = pile[k], pile[n - 1]
                remplace = True
                break
        if not remplace and pile[0] != dernier and pile[n - 1] != premier:
            pile[0], pile[n - 1] = pile[n - 1], pile[0]
    return pile


def montage_rythme(cfg: dict, theme: str, audio: dict | None, style: dict, caption: str = "",
                   cale: bool = True, duree_plan: float = 1.5, duree_cible: float = 15.0,
                   exclure_captionnees: bool = False, format_origine: bool = True,
                   pas: int = 2, sur_accents: bool = False, mini: float = 0.7, maxi: float = 3.0,
                   voir_utilisees: bool = False, marquer: bool = True, plein_ecran: bool = True,
                   cadrage_paysage: str = "remplir", theme_caption: str | None = None,
                   video: dict | None = None, nom_sortie: str = "rythme",
                   paroles: dict | None = None, reserve=None, log=print) -> Path:
    """Remonte plusieurs vidéos du thème en changeant de plan au rythme de l'audio.

    L'audio donne la durée totale et les instants de coupe.

    • Sans `video` : les vidéos du thème sont mélangées, chacune donnant un extrait pris au hasard.
    • Avec `video` : c'est **cette seule vidéo** qui est remontée, en mélangeant ses propres rushs
      (les plans repérés par la détection de coupes). Un plan séquence est refusé : il n'a rien à
      remonter.

    Renvoie le fichier monté.
    """
    from . import rythme, zones as mod_zones
    source = Path(str((audio or {}).get("chemin") or "") or "/nulle-part")
    if cale and not source.is_file():
        raise ValueError("Choisis un extrait audio pour caler le montage sur le rythme.")
    vids = [v for v in bibliotheque.videos(cfg, theme) if voir_utilisees or not v["utilisee"]]
    if exclure_captionnees:
        vids = [v for v in vids if not v.get("caption_incrustee")]
    if video is None and not vids:
        raise ValueError(f"Aucune vidéo disponible dans « {theme} ».")

    rep = {"bpm": 0.0, "temps": [], "accents": [], "duree": 0.0}
    protegees: list = []
    if cale:
        log("♪ Lecture du rythme de l'audio…")
        rep = rythme.analyser(source)
        protegees = mod_zones.pour_extrait(audio)
        bornes = rythme.coupes(rep["duree"], rep, pas=pas, mini=mini, maxi=maxi,
                               sur_accents=sur_accents, zones=protegees)
        log(f"   {rep['bpm'] or '?'} battements/minute · {max(1, len(bornes) - 1)} plans "
            f"sur {rep['duree']:.1f} s")
        if protegees:
            log("   🔒 " + str(len(protegees)) + " zone(s) sans coupe : "
                + ", ".join(f"{a:.1f}–{b:.1f} s" for a, b in protegees))
    else:
        totale = float(audios_duree(source) if source.is_file() else 0) or float(duree_cible or 15.0)
        p_plan = max(0.3, float(duree_plan or 1.5))
        bornes = [round(i * p_plan, 3) for i in range(int(totale // p_plan))] or [0.0]
        if totale - bornes[-1] < p_plan / 2 and len(bornes) > 1:
            bornes.pop()
        bornes.append(round(totale, 3))
        rep["duree"] = round(totale, 3)
        log(f"   coupes régulières toutes les {p_plan:.1f} s · {len(bornes) - 1} plans "
            f"sur {totale:.1f} s")
    n_plans = max(1, len(bornes) - 1)

    ex = cfg.get("export", {})
    plans, utilisees = [], []

    if video is not None:
        # ── remonter UNE vidéo : on mélange ses propres rushs ──
        decoupe = video.get("plans") or bibliotheque.analyser(cfg, video).get("plans") or []
        rushs = [r for r in decoupe if r[1] - r[0] >= 0.5]
        if len(rushs) < 2:
            raise ValueError(f"« {video['nom']} » est un plan séquence (aucune coupe détectée) : "
                             "il n'y a rien à remonter. Choisis une vidéo qui a plusieurs plans.")
        info = sonder(video["chemin"])
        if format_origine:
            cadrage = "remplir"            # rien à recadrer : on sort au format de la vidéo elle-même
        else:
            _, _, cadrage = dimensions_export(info, plein_ecran, cfg, cadrage_paysage)
        pile: list[list[float]] = []
        while len(pile) < n_plans:
            tour = list(rushs)
            random.shuffle(tour)
            pile += tour
        pile = _eviter_memes_bords(pile, rushs[0], rushs[-1], n_plans)
        log(f"   {len(rushs)} rushs dans « {video['nom']} »")
        for i in range(n_plans):
            a, b = pile[i]
            duree_plan = round(bornes[i + 1] - bornes[i], 3)
            marge = max(0.0, (b - a) - duree_plan)
            debut = round(a + random.uniform(0, marge), 2)
            plans.append({"chemin": video["chemin"], "debut": debut, "duree": duree_plan, "info": info,
                          "cadrage": cadrage, "decalage": 50.0})
            log(f"   plan {i + 1:>2} · {duree_plan:.2f} s · rush {a:.1f}–{b:.1f} s (à {debut:.1f} s)")
        utilisees.append(video["nom"])
        theme_dest = video.get("theme") or theme
    else:
        # ── mélanger les vidéos du thème : un plan par vidéo, dans le désordre ──
        # une réserve commune à toute la série (sinon, une pour ce montage seul) : toutes les
        # vidéos passent, aucun rush ne revient avant les autres, pas deux scènes qui se ressemblent
        from .rushs import Reserve
        if reserve is None:
            reserve = Reserve(vids, log)
        reserve.nouveau_montage()
        ref = None
        for i in range(n_plans):
            duree_plan = round(bornes[i + 1] - bornes[i], 3)
            pris = reserve.tirer(duree_plan)
            if pris is None:
                raise ValueError(f"Aucun rush utilisable dans « {theme} ».")
            v, debut = pris["video"], pris["debut"]
            info = sonder(v["chemin"])
            if format_origine:
                ref = ref or info
                cadrage = "remplir"        # tout le monde au format de la première vidéo du montage
            else:
                _, _, cadrage = dimensions_export(info, plein_ecran, cfg, cadrage_paysage)
            plans.append({"chemin": v["chemin"], "debut": debut, "duree": duree_plan, "info": info,
                          "cadrage": cadrage, "decalage": 50.0})
            utilisees.append(v["nom"])
            log(f"   plan {i + 1:>2} · {duree_plan:.2f} s · {v['nom'][:38]} "
                f"(rush {pris['rush'][0]:.1f}–{pris['rush'][1]:.1f} s, à {debut:.1f} s)")
        theme_dest = theme

    if format_origine:
        src = info if video is not None else ref
        W = max(2, int(src["largeur"]) // 2 * 2)
        H = max(2, int(src["hauteur"]) // 2 * 2)
        log(f"   format gardé : {W}×{H} (celui de la vidéo d'origine)")
    else:
        W = int(ex.get("largeur", 1080))
        H = int(ex.get("hauteur", 1920))
    horodatage = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
    calques = [(caption, style)] if caption.strip() else []
    log("🎬 Assemblage…")
    # « muet » : l'audio a servi à placer les coupes, mais il n'est pas posé sur l'export
    muet = bool((audio or {}).get("muet"))
    duree_visee = sum(float(p["duree"]) for p in plans)
    lignes_p = paroles_mod.borner((paroles or {}).get("lignes") or [], duree_visee)
    if lignes_p:
        st_cap, st_par = placer_textes(cfg, caption, style, lignes_p, W, H,
                                       (paroles or {}).get("position") or "bas",
                                       (paroles or {}).get("habillage"))
        if st_cap is None:
            caption = ""
        calques = [(caption, st_cap)] if caption.strip() else []
    bande = {"lignes": lignes_p, "style": st_par} if lignes_p else None
    sous = sous_dossier(caption, lignes_p)
    dossier_f = dossier_export(theme_dest, theme_caption, caption, lignes_p)
    dest = chemin(cfg, "centre_controle") / dossier_f / nom_export(
        horodatage, audio if source.is_file() else None, nom_sortie)
    duree = monter_plans(cfg, plans, dest, W, H, calques, TMP,
                         None if muet else (audio if source.is_file() else None), bande)
    shutil.rmtree(TMP, ignore_errors=True)

    stockage.ecrire(bibliotheque.fiche(cfg, dossier_f, dest), {
        "fichier": dest.name,
        "theme": theme_dest,
        "contenu": sous or "sans texte",
        "caption": caption,
        "statut": "pret",
        "format": f"{W}x{H}",
        "duree_s": duree,
        "montage": ("rythme" if cale else "plans") + (" (une vidéo)" if video is not None else ""),
        "plans": [{"video": p["chemin"].name, "debut": p["debut"], "duree": p["duree"]} for p in plans],
        "audio": ("" if muet else (nom_audio(audio) if source.is_file() else "")),
        "son": "muet" if muet else "avec",
        "rythme_de": nom_audio(audio) if source.is_file() else "",
        "bpm": rep["bpm"],
        "zones_sans_coupe": ", ".join(f"{a:.1f}–{b:.1f}" for a, b in protegees),
        "video_originale": ", ".join(dict.fromkeys(utilisees))[:400],
        "cree_le": dt.datetime.now().isoformat(timespec="seconds"),
    })
    if marquer:
        rel = str(dest.relative_to(chemin(cfg, "centre_controle")))
        for nom in dict.fromkeys(utilisees):
            bibliotheque.marquer(nom, True, export=rel, caption=caption)
    if caption.strip():
        captions.marquer(theme_caption or theme, caption, dest.name)
    bibliotheque.exporter_index(cfg)
    log(f"✅ {dossier_f}/{dest.name} — {duree:.1f} s, {n_plans} plans")
    return dest
