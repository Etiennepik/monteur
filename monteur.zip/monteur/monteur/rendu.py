"""Rendu : texte (Pillow → PNG transparent) + montage ffmpeg (logo, format, incrustation)."""
from __future__ import annotations

import re
import json
import subprocess
from pathlib import Path

from PIL import Image, ImageColor, ImageDraw, ImageFilter, ImageFont

from .config import RACINE, chemin

DOSSIERS_POLICES_SYSTEME = [
    Path.home() / "Library" / "Fonts",
    Path("/Library/Fonts"),
    Path("/System/Library/Fonts"),
    Path("/System/Library/Fonts/Supplemental"),
    Path("/usr/share/fonts"),
]


# ───────────────────────────── polices ─────────────────────────────

_CACHE_POLICES: dict[str, tuple[float, dict]] = {}


def vider_cache_polices() -> None:
    _CACHE_POLICES.clear()


def polices_disponibles(cfg: dict) -> dict[str, Path]:
    """{nom_fichier: chemin} — d'abord le dossier 'polices' du projet, puis celles du Mac (cache 60 s)."""
    import time
    cle = str(chemin(cfg, "polices")) + "|" + str((cfg.get("partage") or {}).get("dossier") or "")
    if cle in _CACHE_POLICES and time.time() - _CACHE_POLICES[cle][0] < 60:
        return _CACHE_POLICES[cle][1]
    out: dict[str, Path] = {}
    partagees = []
    pa = (cfg.get("partage") or {}).get("dossier") or ""
    if str(pa).strip():
        from .config import resoudre
        partagees = [resoudre(str(pa).strip()) / "polices"]   # typos communes à toute l'équipe
    for d in [*partagees, chemin(cfg, "polices"), *DOSSIERS_POLICES_SYSTEME]:
        if d.is_dir():
            for f in sorted(d.rglob("*")):
                if f.suffix.lower() in {".ttf", ".otf", ".ttc"} and f.name not in out:
                    out[f.name] = f
    _CACHE_POLICES[cle] = (time.time(), out)
    return out


def _police(cfg: dict, nom: str, taille: int) -> ImageFont.FreeTypeFont:
    p = polices_disponibles(cfg).get(nom)
    if p is None:
        p = RACINE / "polices" / "Poppins-Bold.ttf"
    return ImageFont.truetype(str(p), max(8, int(taille)))


def _couleur(hexa: str, alpha: float = 1.0) -> tuple[int, int, int, int]:
    r, g, b = ImageColor.getrgb(hexa or "#FFFFFF")[:3]
    return (r, g, b, int(max(0.0, min(1.0, float(alpha))) * 255))


def _decouper(texte: str, police, largeur_max: int, draw: ImageDraw.ImageDraw) -> list[str]:
    lignes: list[str] = []
    for para in texte.split("\\n") if "\\n" in texte else texte.split("\n"):
        mots, courante = para.split(), ""
        for m in mots:
            essai = f"{courante} {m}".strip()
            if draw.textlength(essai, font=police) <= largeur_max or not courante:
                courante = essai
            else:
                lignes.append(courante)
                courante = m
        lignes.append(courante)
    return lignes


# Zones occupées par l'interface de TikTok / Reels, en part de l'image. Mesures relevées sur un écran
# 1080×1920 : 160 px en haut (nom d'utilisateur, son), 480 px en bas (boutons, légende, appel à
# l'action — d'autant plus haut que la légende est longue) et 120 px de chaque côté (icônes j'aime,
# commentaires, partage). Il reste une zone sûre d'environ 840 × 1280 px au centre.
MARGES_SURES = {"haut": 160, "bas": 480, "gauche": 120, "droite": 120}
ZONE_SURE = {"haut": MARGES_SURES["haut"] / 1920, "bas": MARGES_SURES["bas"] / 1920,
             "gauche": MARGES_SURES["gauche"] / 1080, "droite": MARGES_SURES["droite"] / 1080}


def bornes_sures(largeur: int, hauteur: int) -> tuple[int, int, int, int]:
    """(gauche, droite, haut, bas) en pixels : le rectangle où une caption reste lisible."""
    z = ZONE_SURE
    return (int(largeur * z["gauche"]), int(largeur * (1 - z["droite"])),
            int(hauteur * z["haut"]), int(hauteur * (1 - z["bas"])))


def mesurer_bloc(cfg: dict, texte: str, style: dict, largeur: int, hauteur: int) -> tuple[float, float]:
    """Largeur et hauteur du bloc de texte, en pourcentage de l'image (pour borner le déplacement)."""
    if not (texte or "").strip():
        return 0.0, 0.0
    img = image_texte(cfg, texte, style, largeur, hauteur, recadrer=False)
    boite = img.getbbox()
    if not boite:
        return 0.0, 0.0
    return (100.0 * (boite[2] - boite[0]) / max(1, largeur),
            100.0 * (boite[3] - boite[1]) / max(1, hauteur))


def image_texte(cfg: dict, texte: str, style: dict, largeur: int, hauteur: int,
                recadrer: bool = True) -> Image.Image:
    """Calque RGBA de la taille de la vidéo avec le texte positionné selon le style.

    `recadrer` ramène le bloc dans l'image (export). L'aperçu le rend centré et le déplace lui-même :
    le ramener décalerait le texte dès qu'un contour épais élargit le bloc.
    """
    echelle = min(largeur, hauteur) / 1080
    taille = int(style["taille"] * echelle)
    police = _police(cfg, style["police"], taille)
    casse = style.get("casse") or ("MAJUSCULES" if style.get("majuscules") else "normal")
    # "normal" reste accepté pour les styles enregistrés avant
    if casse == "MAJUSCULES":
        texte = texte.upper()
    elif casse == "minuscules":
        texte = texte.lower()

    calque = Image.new("RGBA", (largeur, hauteur), (0, 0, 0, 0))
    draw = ImageDraw.Draw(calque)
    contour = int(style.get("contour_epaisseur", 0) * echelle)
    lmax = int(largeur * style["largeur_max"] / 100)
    lignes = _decouper(texte, police, lmax, draw)
    # équilibrage : largeur la plus étroite qui garde le même nombre de lignes (évite un mot seul en bas)
    if len(lignes) > 1:
        bas, haut = lmax // 3, lmax
        while haut - bas > 4:
            mil = (bas + haut) // 2
            if len(_decouper(texte, police, mil, draw)) <= len(lignes):
                haut = mil
            else:
                bas = mil
        lignes = _decouper(texte, police, haut, draw)

    asc, desc = police.getmetrics()
    h_ligne = int((asc + desc) * float(style.get("interligne", 1.15)))
    largeurs = [draw.textlength(l, font=police) for l in lignes]
    bloc_l = int(max(largeurs or [0])) + 2 * contour
    bloc_h = h_ligne * (len(lignes) - 1) + asc + desc + 2 * contour

    cx = largeur * style["position_x"] / 100
    cy = hauteur * style["position_y"] / 100
    x0 = int(cx - bloc_l / 2)
    y0 = int(cy - bloc_h / 2)
    # garder le bloc dans la zone sûre : jamais sous l'interface de TikTok / Reels
    if recadrer:
        g, d, h, b = bornes_sures(largeur, hauteur)
        if bloc_l <= d - g:
            x0 = max(g, min(x0, d - bloc_l))
        else:                               # bloc plus large que la zone sûre : on le centre dessus
            x0 = (g + d) // 2 - bloc_l // 2
        if bloc_h <= b - h:
            y0 = max(h, min(y0, b - bloc_h))
        else:
            y0 = (h + b) // 2 - bloc_h // 2

    # fond (bandeau)
    if float(style.get("fond_opacite", 0)) > 0:
        m = int(style.get("fond_marge", 20) * echelle)
        draw.rounded_rectangle(
            [x0 - m, y0 - m, x0 + bloc_l + m, y0 + bloc_h + m],
            radius=int(m * 0.6),
            fill=_couleur(style["fond_couleur"], style["fond_opacite"]),
        )

    def position_ligne(i):
        l = largeurs[i]
        al = style.get("alignement", "centre")
        if al == "gauche":
            x = x0 + contour
        elif al == "droite":
            x = x0 + bloc_l - contour - l
        else:
            x = x0 + (bloc_l - l) / 2
        return x, y0 + contour + i * h_ligne

    # ombre portée douce
    if style.get("ombre"):
        ombre = Image.new("RGBA", calque.size, (0, 0, 0, 0))
        d2 = ImageDraw.Draw(ombre)
        dec = max(2, int(5 * echelle))
        for i, l in enumerate(lignes):
            x, y = position_ligne(i)
            d2.text((x + dec, y + dec), l, font=police, fill=(0, 0, 0, 170),
                    stroke_width=contour, stroke_fill=(0, 0, 0, 170))
        ombre = ombre.filter(ImageFilter.GaussianBlur(max(2, int(6 * echelle))))
        calque = Image.alpha_composite(ombre, calque)
        draw = ImageDraw.Draw(calque)

    for i, l in enumerate(lignes):
        x, y = position_ligne(i)
        draw.text((x, y), l, font=police, fill=_couleur(style["couleur"]),
                  stroke_width=contour, stroke_fill=_couleur(style.get("contour_couleur", "#000000")))

    if recadrer:
        # dernier contrôle sur le dessin réel (ombre et bandeau compris) : rien ne doit déborder
        # dans les zones de l'interface. On décale le calque entier si besoin.
        boite = calque.getbbox()
        if boite:
            g, d, h, b = bornes_sures(largeur, hauteur)
            dx = dy = 0
            if boite[2] - boite[0] <= d - g:
                dx = g - boite[0] if boite[0] < g else (d - boite[2] if boite[2] > d else 0)
            else:                           # trop large : centré sur la zone sûre
                dx = (g + d) // 2 - (boite[0] + boite[2]) // 2
            if boite[3] - boite[1] <= b - h:
                dy = h - boite[1] if boite[1] < h else (b - boite[3] if boite[3] > b else 0)
            else:
                dy = (h + b) // 2 - (boite[1] + boite[3]) // 2
            if dx or dy:
                decale = Image.new("RGBA", calque.size, (0, 0, 0, 0))
                decale.paste(calque, (dx, dy))
                calque = decale
    return calque


# ───────────────────────────── vidéo ─────────────────────────────

def sonder(video: Path) -> dict:
    r = subprocess.run(
        ["ffprobe", "-v", "error", "-print_format", "json", "-show_streams", "-show_format", str(video)],
        capture_output=True, text=True, check=True,
    )
    d = json.loads(r.stdout)
    # on ignore les vignettes incrustées (yt-dlp en ajoute souvent) : elles n'ont pas le format de la vidéo
    flux = [s for s in d["streams"] if s["codec_type"] == "video"]
    vrais = [s for s in flux if not (s.get("disposition") or {}).get("attached_pic")
             and s.get("codec_name") not in ("mjpeg", "png", "bmp", "gif")]
    v = (vrais or flux)[0]
    l, h = int(v["width"]), int(v["height"])
    rot = 0
    for sd in v.get("side_data_list", []) or []:
        if "rotation" in sd:
            rot = int(sd["rotation"])
    rot = rot or int((v.get("tags") or {}).get("rotate", 0) or 0)
    if abs(rot) % 180 == 90:
        l, h = h, l
    return {
        "largeur": l,
        "hauteur": h,
        "duree": float(d["format"].get("duration") or 0),
        "audio": any(s["codec_type"] == "audio" for s in d["streams"]),
    }


def _pair(n: float) -> int:
    return max(2, int(n) // 2 * 2)


def filtres_logo(logo: dict | None, l: int, h: int) -> str:
    """Filtres ffmpeg pour masquer une ou plusieurs zones (logo, tag).
    logo = {"mode": "aucun" | "flou" | "masque", "zones": [{x, y, largeur, hauteur} en %]}"""
    if not logo or logo.get("mode") not in ("flou", "masque"):
        return ""
    morceaux = []
    for k, z in enumerate(logo.get("zones") or []):
        zl, zh = l * float(z.get("largeur", 0)) / 100, h * float(z.get("hauteur", 0)) / 100
        if zl < 4 or zh < 4:
            continue
        zx = int(min(max(1, l * float(z.get("x", 0)) / 100), l - 5))
        zy = int(min(max(1, h * float(z.get("y", 0)) / 100), h - 5))
        zl = _pair(min(zl, l - zx - 2))
        zh = _pair(min(zh, h - zy - 2))
        if logo["mode"] == "masque":
            morceaux.append(f"delogo=x={zx}:y={zy}:w={zl}:h={zh}")
        else:
            pl, ph = max(2, zl // 14 // 2 * 2), max(2, zh // 14 // 2 * 2)
            morceaux.append(f"split[lg{k}a][lg{k}b];[lg{k}b]crop={zl}:{zh}:{zx}:{zy},scale={pl}:{ph},"
                            f"scale={zl}:{zh}:flags=bilinear,boxblur=2:2[lg{k}f];"
                            f"[lg{k}a][lg{k}f]overlay={zx}:{zy}")
    return ",".join(morceaux)


def filtres_cadrage(mode: str, W: int, H: int, decalage: float = 50.0) -> str:
    """`decalage` (0-100) choisit la partie gardée quand l'image déborde : 0 = gauche/haut, 100 = droite/bas."""
    if mode == "remplir":
        d = max(0.0, min(100.0, float(decalage))) / 100
        return (f"scale={W}:{H}:force_original_aspect_ratio=increase,"
                f"crop={W}:{H}:(iw-ow)*{d:.4f}:(ih-oh)*{d:.4f},setsar=1")
    if mode == "bandes":
        return (f"scale={W}:{H}:force_original_aspect_ratio=decrease:force_divisible_by=2,"
                f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2:black,setsar=1")
    # flou : vidéo entière au centre, fond = même vidéo agrandie et floutée
    return (f"split[cd_a][cd_b];"
            f"[cd_a]scale={W}:{H}:force_original_aspect_ratio=increase,crop={W}:{H},"
            f"scale={W // 8}:{H // 8},boxblur=6:2,scale={W}:{H},eq=brightness=-0.08[cd_fond];"
            f"[cd_b]scale={W}:{H}:force_original_aspect_ratio=decrease:force_divisible_by=2[cd_avant];"
            f"[cd_fond][cd_avant]overlay=(W-w)/2:(H-h)/2,setsar=1")


def est_paysage(info: dict) -> bool:
    return info["largeur"] > info["hauteur"] * 1.05


def meme_format(info: dict, largeur: int, hauteur: int) -> bool:
    """La source a-t-elle (à peu près) le format de l'export ?"""
    try:
        return abs(info["largeur"] / info["hauteur"] - largeur / hauteur) < 0.02
    except ZeroDivisionError:
        return True


def dimensions_export(info: dict, plein_ecran: bool, cfg: dict, cadrage_autre: str = "bandes") -> tuple[int, int, str]:
    """(largeur, hauteur, cadrage) de la vidéo exportée.

    Une source qui n'est pas au format de l'export (9:16) est placée en entier entre deux bandes
    noires ; `cadrage_autre` vaut "remplir" pour l'agrandir à l'écran entier (la partie gardée se
    choisit avec le décalage).
    """
    ex = cfg.get("export", {})
    if plein_ecran:
        L, H = int(ex.get("largeur", 1080)), int(ex.get("hauteur", 1920))
        # le choix est toujours respecté : sur une source déjà au format, les deux donnent la même image
        return L, H, (cadrage_autre if cadrage_autre in ("bandes", "remplir", "flou") else "remplir")
    l, h = info["largeur"], info["hauteur"]
    r = min(1.0, 1920 / max(l, h))          # on garde le format d'origine, plafonné à 1920 px
    return _pair(l * r), _pair(h * r), "remplir"


def _graphe_video(logo: dict | None, info: dict, W: int, H: int, cadrage: str, decalage: float = 50.0) -> str:
    lg = filtres_logo(logo, info["largeur"], info["hauteur"])
    return (lg + "," if lg else "") + filtres_cadrage(cadrage, W, H, decalage)


def apercu(video: Path, t: float, logo: dict | None, W: int, H: int, cadrage: str, info: dict | None = None,
           decalage: float = 50.0):  # noqa: D401
    """Image (PIL) de la vidéo à l'instant t, avec le même traitement logo + cadrage que l'export."""
    import io
    info = info or sonder(video)
    t = max(0.0, min(t, max(0.0, info["duree"] - 0.1)))
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1",
                        "-filter_complex", "[0:v]" + _graphe_video(logo, info, W, H, cadrage, decalage) + "[o]",
                        "-map", "[o]",
                        "-f", "image2pipe", "-vcodec", "png", "-"], capture_output=True)
    if not r.stdout:
        raise RuntimeError(r.stderr.decode(errors="replace")[-800:])
    return Image.open(io.BytesIO(r.stdout)).convert("RGBA")


def frise(video: Path, duree: float, n: int = 32, largeur: int = 120) -> list[bytes]:
    """n vignettes JPEG réparties sur la vidéo, en un seul appel ffmpeg (pour la barre de découpe)."""
    duree = max(0.2, duree)
    taux = max(0.05, n / duree)
    r = subprocess.run(["ffmpeg", "-loglevel", "error", "-i", str(video),
                        "-vf", f"fps={taux:.4f},scale={largeur}:-2", "-vsync", "0", "-q:v", "8",
                        "-f", "image2pipe", "-vcodec", "mjpeg", "-"], capture_output=True)
    brut = r.stdout
    images, debut = [], brut.find(b"\xff\xd8\xff")
    while debut >= 0:
        suivant = brut.find(b"\xff\xd8\xff", debut + 3)
        images.append(brut[debut:suivant] if suivant > 0 else brut[debut:])
        debut = suivant
    return images[:n] or []


def piste_paroles(cfg: dict, lignes: list[dict], style: dict, W: int, H: int, tmp: Path,
                  prefixe: str) -> Path | None:
    """Fabrique UNE superposition pour toutes les paroles, quel qu'en soit le nombre.

    Chaque ligne est une image transparente ; elles s'enchaînent dans une liste « concat » avec
    leur durée, et les silences sont une image vide. Une seule entrée ffmpeg au lieu d'une par
    ligne : un refrain de quarante mots ne fait pas exploser le montage.
    """
    lignes = [l for l in (lignes or []) if str(l.get("texte") or "").strip()]
    if not lignes:
        return None
    tmp.mkdir(parents=True, exist_ok=True)
    vide = tmp / f"paroles_{prefixe}_vide.png"
    Image.new("RGBA", (W, H), (0, 0, 0, 0)).save(vide)
    entrees: list[tuple[Path, float]] = []
    t = 0.0
    for i, l in enumerate(sorted(lignes, key=lambda x: float(x["debut"]))):
        debut, fin = float(l["debut"]), float(l["fin"])
        if fin <= debut:
            continue
        if debut > t + 0.02:
            entrees.append((vide, round(debut - t, 3)))
        png = tmp / f"paroles_{prefixe}_{i}.png"
        image_texte(cfg, str(l["texte"]), style, W, H).save(png)
        entrees.append((png, round(fin - max(debut, t), 3)))
        t = fin
    if not entrees:
        return None
    liste = tmp / f"paroles_{prefixe}.txt"
    lignes_txt = []
    for chemin_png, duree in entrees:
        lignes_txt.append(f"file '{chemin_png}'")
        lignes_txt.append(f"duration {max(0.04, duree):.3f}")
    lignes_txt.append(f"file '{entrees[-1][0]}'")     # le concat garde la dernière image affichée
    liste.write_text("\n".join(lignes_txt) + "\n", encoding="utf-8")
    return liste


def monter(cfg: dict, entree: Path, sortie: Path, logo: dict | None, W: int, H: int, cadrage: str,
           calques: list[tuple[str, dict]], tmp: Path, info: dict | None = None,
           coupe: tuple[float, float] | None = None, decalage: float = 50.0,
           audio: dict | None = None, paroles: dict | None = None) -> dict:
    """Exporte une vidéo : coupe, logo masqué, format, textes incrustés. calques = [(texte, style), …].

    coupe = (début, fin) en secondes dans la vidéo d'origine ; les instants d'apparition des
    textes sont comptés à partir du début de l'extrait.

    audio = {"chemin": …, "volume": 1.0, "garder_son": False} : musique ajoutée, qui remplace le son
    d'origine (ou s'y mélange). L'extrait démarre au début, se répète s'il est plus court que la vidéo
    et se coupe à la fin de la vidéo s'il est plus long.
    """
    info = info or sonder(entree)
    ex = cfg.get("export", {})
    fps = int(ex.get("fps_max") or 30)
    debut_coupe, fin_coupe = (coupe or (0.0, info["duree"]))
    debut_coupe = max(0.0, float(debut_coupe))
    fin_coupe = min(float(fin_coupe or info["duree"]), info["duree"])
    duree = max(0.1, fin_coupe - debut_coupe)
    duree_max = float(ex.get("duree_max_s") or 0)
    if duree_max:
        duree = min(duree, duree_max)

    graphe = ["[0:v]" + _graphe_video(logo, info, W, H, cadrage, decalage) + f",fps={fps}[v0]"]
    entrees = (["-ss", f"{debut_coupe:.3f}"] if debut_coupe > 0 else []) + ["-i", str(entree)]
    piste_audio = None
    muet = bool((audio or {}).get("muet"))      # « exporter sans le son » : aucune piste audio
    if audio and not muet and Path(str(audio.get("chemin") or "")).is_file():
        # l'extrait part de son début et se répète jusqu'à la fin de la vidéo ; s'il est plus long,
        # le `-t` de sortie le coupe. Dans les deux cas la vidéo n'est jamais raccourcie.
        depart = max(0.0, float(audio.get("debut_s") or 0))
        entrees += ["-stream_loop", "-1"] + (["-ss", f"{depart:.3f}"] if depart > 0 else []) \
            + ["-i", str(audio["chemin"])]
        idx_a = entrees.count("-i") - 1
        vol = max(0.0, min(4.0, float(audio.get("volume", 1.0) or 0)))
        graphe.append(f"[{idx_a}:a]volume={vol:.3f},aresample=async=1,apad[am]")
        if audio.get("garder_son") and info["audio"]:
            vol0 = max(0.0, min(4.0, float(audio.get("volume_origine", 1.0) or 0)))
            graphe.append(f"[0:a]volume={vol0:.3f},apad[a0]")
            graphe.append("[a0][am]amix=inputs=2:duration=longest:dropout_transition=0[aout]")
        else:
            graphe.append("[am]anull[aout]")
        piste_audio = "[aout]"
    tmp.mkdir(parents=True, exist_ok=True)
    courant = "v0"
    for i, (texte, style) in enumerate(calques, start=1):
        if not (texte or "").strip():
            continue
        png = tmp / f"calque_{sortie.stem}_{i}.png"
        image_texte(cfg, texte, style, W, H).save(png)
        entrees += ["-loop", "1", "-i", str(png)]
        idx = entrees.count("-i") - 1
        debut, fin = float(style.get("debut_s") or 0), float(style.get("fin_s") or 0)
        cond = f":enable='between(t,{debut},{fin if fin > 0 else 1e6})'" if (debut > 0 or fin > 0) else ""
        graphe.append(f"[{courant}][{idx}:v]overlay=0:0:shortest=1{cond}[v{i}]")
        courant = f"v{i}"

    # les paroles passent par-dessus : une seule entrée, quel que soit le nombre de lignes
    piste = piste_paroles(cfg, (paroles or {}).get("lignes") or [], (paroles or {}).get("style") or {},
                          W, H, tmp, sortie.stem) if paroles else None
    if piste:
        entrees += ["-f", "concat", "-safe", "0", "-i", str(piste)]
        idx = entrees.count("-i") - 1
        graphe.append(f"[{idx}:v]fps={fps},format=rgba,setpts=PTS-STARTPTS[pr]")
        graphe.append(f"[{courant}][pr]overlay=0:0:shortest=0[vpr]")
        courant = "vpr"

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *entrees,
           "-filter_complex", ";".join(graphe), "-map", f"[{courant}]"]
    if piste_audio:
        cmd += ["-map", piste_audio, "-c:a", "aac", "-b:a", "160k"]
    elif info["audio"] and not muet:
        cmd += ["-map", "0:a:0", "-c:a", "aac", "-b:a", "160k"]
    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", str(ex.get("qualite_crf", 20)),
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-t", f"{duree:.3f}", str(sortie)]
    sortie.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sortie.unlink(missing_ok=True)
        raise RuntimeError(r.stderr.strip()[-1500:])
    return info


def monter_plans(cfg: dict, plans: list[dict], sortie: Path, W: int, H: int,
                 calques: list[tuple[str, dict]], tmp: Path, audio: dict | None = None,
                 paroles: dict | None = None) -> float:
    """Assemble plusieurs extraits de vidéos bout à bout, sur une bande son.

    plans = [{"chemin", "debut", "duree", "cadrage", "decalage", "info", "logo"}, …] dans l'ordre du
    montage. Chaque plan est recadré au format d'export avant d'être mis à la suite : c'est ce que
    demande la mise bout à bout (même taille, même cadence, même format de pixel).

    Renvoie la durée totale obtenue.
    """
    ex = cfg.get("export", {})
    fps = int(ex.get("fps_max") or 30)
    entrees: list[str] = []
    graphe: list[str] = []
    total = 0.0
    for i, p in enumerate(plans):
        d = max(0.05, float(p["duree"]))
        debut = max(0.0, float(p.get("debut") or 0))
        entrees += (["-ss", f"{debut:.3f}"] if debut > 0 else []) + ["-t", f"{d + 1.0:.3f}",
                                                                    "-i", str(p["chemin"])]
        cadre = _graphe_video(p.get("logo"), p.get("info") or sonder(Path(p["chemin"])), W, H,
                              p.get("cadrage") or "bandes", float(p.get("decalage", 50)))
        graphe.append(
            f"[{i}:v]setpts=PTS-STARTPTS,{cadre},fps={fps},"
            f"tpad=stop_mode=clone:stop_duration=2,trim=duration={d:.3f},setpts=PTS-STARTPTS,"
            f"format=yuv420p,setsar=1[p{i}]")
        total += d
    graphe.append("".join(f"[p{i}]" for i in range(len(plans)))
                  + f"concat=n={len(plans)}:v=1:a=0[vc]")
    courant = "vc"

    piste_audio = None
    if audio and Path(str(audio.get("chemin") or "")).exists():
        entrees += ["-stream_loop", "-1", "-i", str(audio["chemin"])]
        idx_a = entrees.count("-i") - 1
        vol = max(0.0, min(4.0, float(audio.get("volume", 1.0) or 0)))
        graphe.append(f"[{idx_a}:a]volume={vol:.3f},aresample=async=1,apad[aout]")
        piste_audio = "[aout]"

    tmp.mkdir(parents=True, exist_ok=True)
    for i, (texte, style) in enumerate(calques, start=1):
        if not (texte or "").strip():
            continue
        png = tmp / f"calque_{sortie.stem}_{i}.png"
        image_texte(cfg, texte, style, W, H).save(png)
        entrees += ["-loop", "1", "-i", str(png)]
        idx = entrees.count("-i") - 1
        debut, fin = float(style.get("debut_s") or 0), float(style.get("fin_s") or 0)
        cond = f":enable='between(t,{debut},{fin if fin > 0 else 1e6})'" if (debut > 0 or fin > 0) else ""
        graphe.append(f"[{courant}][{idx}:v]overlay=0:0:shortest=0{cond}[c{i}]")
        courant = f"c{i}"

    piste = piste_paroles(cfg, (paroles or {}).get("lignes") or [], (paroles or {}).get("style") or {},
                          W, H, tmp, sortie.stem) if paroles else None
    if piste:
        entrees += ["-f", "concat", "-safe", "0", "-i", str(piste)]
        idx = entrees.count("-i") - 1
        graphe.append(f"[{idx}:v]fps={fps},format=rgba,setpts=PTS-STARTPTS[pr]")
        graphe.append(f"[{courant}][pr]overlay=0:0:shortest=0[vpr]")
        courant = "vpr"

    cmd = ["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", *entrees,
           "-filter_complex", ";".join(graphe), "-map", f"[{courant}]"]
    if piste_audio:
        cmd += ["-map", piste_audio, "-c:a", "aac", "-b:a", "160k"]
    cmd += ["-c:v", "libx264", "-preset", "medium", "-crf", str(ex.get("qualite_crf", 20)),
            "-pix_fmt", "yuv420p", "-movflags", "+faststart", "-t", f"{total:.3f}", str(sortie)]
    sortie.parent.mkdir(parents=True, exist_ok=True)
    r = subprocess.run(cmd, capture_output=True, text=True)
    if r.returncode != 0:
        sortie.unlink(missing_ok=True)
        raise RuntimeError(r.stderr.strip()[-1500:])
    return round(total, 2)


def plans_video(video: Path, seuil: float = 0.22, duree: float | None = None) -> list[list[float]]:
    """Découpe une vidéo en plans, d'après les changements de scène.

    Renvoie [[début, fin], …]. Une liste d'un seul élément veut dire **plan séquence** : la caméra
    ne coupe jamais, et il n'y a donc rien à remonter dans cette vidéo.
    """
    d = float(duree if duree is not None else sonder(video)["duree"])
    if d <= 0:
        return [[0.0, 0.0]]
    try:
        r = subprocess.run(["ffmpeg", "-hide_banner", "-v", "info", "-i", str(video),
                            "-filter:v", f"select='gt(scene,{seuil})',showinfo", "-f", "null", "-"],
                           capture_output=True, text=True, timeout=300)
        temps = sorted({round(float(x), 2) for x in re.findall(r"pts_time:([0-9.]+)", r.stderr or "")})
    except (OSError, ValueError, subprocess.SubprocessError):
        temps = []
    bornes = [0.0] + [t for t in temps if 0.4 < t < d - 0.4] + [round(d, 2)]
    plans = [[bornes[i], bornes[i + 1]] for i in range(len(bornes) - 1)
             if bornes[i + 1] - bornes[i] >= 0.5]
    return plans or [[0.0, round(d, 2)]]
