"""Monteur — montage vidéo automatisé (téléchargement, recadrage, textes, classement)."""
__version__ = "1.0.0"
