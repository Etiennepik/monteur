"""Associer une caption au contenu d'une vidéo.

Tout se fait sur l'ordinateur, sans service extérieur : on compare les **thèmes** d'une phrase à ceux
de la vidéo. Les thèmes de la vidéo viennent de trois sources, de la plus sûre à la moins sûre :

1. ce que le Mac reconnaît sur les images (Apple Vision : « sunset », « beach », « dog »…) ;
2. le texte déjà incrusté dans la vidéo, s'il y en a un ;
3. le titre, la description et les hashtags du post d'origine.

Ce n'est pas de la compréhension : c'est un rapprochement par champs de sens, bilingue, avec un
seuil en dessous duquel on considère qu'« aucune caption ne colle ». Les cas fins (ironie, double
sens, métaphore) lui échappent, et c'est normal.
"""
from __future__ import annotations

import re
import unicodedata

# Champs de sens : un thème, puis les mots (français et anglais) qui le signalent.
# Les étiquettes d'Apple Vision sont en anglais : elles tombent dans les mêmes champs.
CHAMPS: dict[str, list[str]] = {
    "mer": ["mer", "ocean", "oceans", "sea", "plage", "beach", "sable", "sand", "vague", "vagues", "wave",
            "waves", "surf", "surfing", "maree", "tide", "coast", "cote", "littoral", "shore", "seaside",
            "lagoon", "lagune", "island", "ile", "baie", "bay", "snorkeling", "seashore"],
    "eau": ["eau", "water", "lac", "lake", "riviere", "river", "piscine", "pool", "swimming", "nager",
            "natation", "pluie", "rain", "cascade", "waterfall", "fontaine", "fountain", "bateau", "boat",
            "voilier", "sailboat", "yacht", "underwater", "aquarium"],
    "soleil": ["soleil", "sun", "sunny", "sunlight", "coucher de soleil", "sunset", "sunrise", "aube",
               "dawn", "dusk", "crepuscule", "golden hour", "chaleur", "heat", "bronzage", "tan",
               "lumiere", "light", "ensoleille", "sunshine", "sunbeam"],
    "ete": ["ete", "summer", "summertime", "vacances", "vacation", "holiday", "holidays", "tropical",
            "palmier", "palm", "palms", "cocktail", "glace", "icecream", "maillot", "swimsuit", "bikini",
            "festival", "chill"],
    "hiver": ["hiver", "winter", "neige", "snow", "snowy", "ski", "skiing", "glace", "ice", "froid",
              "cold", "montagne enneigee", "blizzard", "frost", "givre"],
    "nature": ["nature", "foret", "forest", "arbre", "tree", "trees", "woods", "champ", "field", "fields",
               "prairie", "meadow", "herbe", "grass", "fleur", "flower", "flowers", "plante", "plant",
               "jardin", "garden", "feuille", "leaf", "leaves", "campagne", "countryside", "paysage",
               "landscape", "outdoor", "outdoors", "nuage", "cloud", "clouds", "ciel", "sky", "colline",
               "hill", "vallee", "valley", "desert", "canyon", "parc", "park"],
    "montagne": ["montagne", "mountain", "mountains", "sommet", "summit", "peak", "falaise", "cliff",
                 "rocher", "rock", "randonnee", "hiking", "hike", "alpinisme", "climbing", "escalade",
                 "altitude", "glacier"],
    "ville": ["ville", "city", "urbain", "urban", "rue", "street", "building", "immeuble", "gratte ciel",
              "skyscraper", "metro", "subway", "trafic", "traffic", "foule", "crowd", "neon", "downtown",
              "skyline", "pont", "bridge", "beton", "concrete"],
    "nuit": ["nuit", "night", "nocturne", "soir", "evening", "etoile", "star", "stars", "lune", "moon",
             "obscurite", "darkness", "dark", "minuit", "midnight", "insomnie", "insomnia", "reve",
             "dream", "dreams", "sommeil", "sleep"],
    "route": ["route", "road", "roads", "highway", "autoroute", "voiture", "car", "cars", "conduire",
              "driving", "drive", "moto", "motorcycle", "bike", "velo", "bicycle", "train", "avion",
              "plane", "airplane", "voyage", "travel", "trip", "journey", "chemin", "path", "aventure",
              "adventure", "horizon"],
    "sport": ["sport", "sports", "gym", "musculation", "workout", "training", "entrainement", "fitness",
              "courir", "running", "run", "course", "boxe", "boxing", "football", "basketball", "soccer",
              "athlete", "muscle", "weightlifting", "halteres", "dumbbell", "exercice", "exercise",
              "performance", "endurance", "discipline physique"],
    "travail": ["travail", "work", "bureau", "office", "desk", "ordinateur", "computer", "laptop",
                "business", "entreprise", "reunion", "meeting", "argent", "money", "cash", "richesse",
                "wealth", "success", "reussite", "ambition", "carriere", "career", "patron", "boss",
                "costume", "suit", "banque", "bank", "investir", "invest"],
    "maison": ["maison", "home", "house", "chambre", "bedroom", "salon", "living room", "cuisine",
               "kitchen", "canape", "couch", "sofa", "lit", "bed", "fenetre", "window", "interieur",
               "indoor", "cafe", "coffee", "the", "tea", "livre", "book", "books", "lecture", "reading"],
    "amour": ["amour", "love", "coeur", "heart", "couple", "amoureux", "romance", "romantic", "baiser",
              "kiss", "mariage", "wedding", "bride", "relation", "relationship", "ex", "rupture",
              "breakup", "solitude", "lonely", "loneliness", "manque", "miss"],
    "famille": ["famille", "family", "enfant", "child", "children", "kid", "kids", "bebe", "baby",
                "mere", "mother", "mom", "pere", "father", "dad", "parents", "frere", "brother",
                "soeur", "sister", "ami", "friend", "friends", "amitie", "friendship"],
    "animal": ["animal", "animals", "chien", "dog", "dogs", "puppy", "chat", "cat", "cats", "kitten",
               "oiseau", "bird", "birds", "cheval", "horse", "poisson", "fish", "papillon", "butterfly",
               "loup", "wolf", "lion", "tigre", "tiger", "ours", "bear"],
    "nourriture": ["nourriture", "food", "manger", "eat", "eating", "repas", "meal", "restaurant",
                   "cuisine", "cooking", "chef", "gateau", "cake", "dessert", "pizza", "burger",
                   "fruit", "fruits", "legume", "vegetable", "boisson", "drink", "diet", "regime"],
    "fete": ["fete", "party", "soiree", "club", "boite", "nightclub", "danse", "dance", "dancing",
             "musique", "music", "concert", "dj", "chanson", "song", "guitare", "guitar", "piano",
             "ambiance", "celebration", "anniversaire", "birthday"],
    "mental": ["motivation", "discipline", "mindset", "mental", "focus", "concentration", "volonte",
               "willpower", "courage", "peur", "fear", "doute", "doubt", "confiance", "confidence",
               "estime", "esteem", "patience", "perseverance", "resilience", "habitude", "habit",
               "objectif", "goal", "goals", "reussir", "succeed", "echec", "failure", "progres",
               "progress", "effort", "sacrifice", "souffrance", "pain", "force", "strength", "stress",
               "anxiete", "anxiety", "depression", "therapie", "healing", "guerison", "paix", "peace",
               "calme", "calm", "serenite", "liberte", "freedom", "free", "libre", "respirer",
               "breathe", "lacher prise", "letting go", "bonheur", "happiness", "joie", "joy",
               "tristesse", "sadness", "colere", "anger", "silence", "solitude choisie"],
    "temps": ["temps", "time", "jour", "day", "days", "annee", "year", "years", "hier", "yesterday",
              "demain", "tomorrow", "maintenant", "now", "moment", "instant", "passe", "past",
              "futur", "future", "age", "vieillir", "aging", "memoire", "memory", "souvenir",
              "souvenirs", "memories", "enfance", "childhood", "jeunesse", "youth"],
    "mode": ["mode", "fashion", "style", "vetement", "clothing", "clothes", "robe", "dress", "chaussure",
             "shoe", "shoes", "sneaker", "sac", "bag", "bijou", "jewelry", "montre", "watch", "lunettes",
             "sunglasses", "beaute", "beauty", "maquillage", "makeup", "cheveux", "hair", "miroir",
             "mirror", "selfie", "portrait", "visage", "face"],
    "feu": ["feu", "fire", "flamme", "flame", "flames", "bruler", "burn", "burning", "fumee", "smoke",
            "cheminee", "fireplace", "bougie", "candle", "coucher braise", "ember"],
}

# mots trop courants pour signifier quoi que ce soit
VIDES = set("""
a à ai aie au aux avec ce ces cet cette d de des du elle en es est et eux il ils je la le les leur lui
ma mais me mes moi mon ne nos notre nous on ou où par pas pour qu que qui sa se ses son sont sur ta te
tes toi ton tu un une vos votre vous y ça c'est n'est plus moins tout tous toute toutes rien jamais
toujours quand comme si dans entre sans sous vers chez the a an and or but of to in on at for with from
by as is are was were be been being this that these those it its he she they them we you your my our
their not no yes do does did done have has had will would can could should it's don't you're i'm
""".split())


def _sans_accents(t: str) -> str:
    t = unicodedata.normalize("NFD", str(t or "").lower())
    return "".join(c for c in t if unicodedata.category(c) != "Mn")


def mots(texte: str) -> set[str]:
    """Mots utiles d'un texte (sans accents, sans les mots trop courants).

    Les élisions sont coupées : « l'eau » donne bien « eau ».
    """
    t = _sans_accents(texte).replace("’", "'").replace("'", " ")
    bruts = re.findall(r"[a-z0-9]+", t)
    return {m for m in bruts if len(m) >= 3 and m not in VIDES}


_INDEX: dict[str, set[str]] = {}
for _champ, _liste in CHAMPS.items():
    for _m in _liste:
        for _mot in _sans_accents(_m).split():
            if len(_mot) >= 3:
                _INDEX.setdefault(_mot, set()).add(_champ)


def champs(texte: str) -> set[str]:
    """Thèmes évoqués par un texte."""
    out: set[str] = set()
    for m in mots(texte):
        out |= _INDEX.get(m, set())
        if m.endswith("s") and len(m) > 3:
            out |= _INDEX.get(m[:-1], set())
    return out


def sac_video(etiquettes: list, texte_incruste: str = "", meta_texte: str = "") -> dict:
    """Ce que « raconte » une vidéo : thèmes pondérés + mots propres (noms, lieux…)."""
    poids: dict[str, float] = {}

    def ajouter(texte: str, force: float):
        for c in champs(texte):
            poids[c] = max(poids.get(c, 0.0), force)

    for e in etiquettes or []:                       # [("sunset", 0.74), …] ou ["sunset", …]
        nom, conf = (e if isinstance(e, (list, tuple)) else (e, 0.5))
        ajouter(str(nom), 0.6 + 0.4 * min(1.0, float(conf or 0)))    # l'image : la source la plus sûre
    ajouter(texte_incruste, 0.75)
    ajouter(meta_texte, 0.5)
    return {"champs": poids,
            "mots": mots(f"{texte_incruste} {meta_texte}") | {str(e[0] if isinstance(e, (list, tuple)) else e)
                                                              for e in (etiquettes or [])}}


def score(sac: dict, caption: str) -> float:
    """À quel point la caption parle de ce que montre la vidéo (0 = rien à voir)."""
    cc = champs(caption)
    if not cc or not sac.get("champs"):
        return 0.0
    commun = sum(sac["champs"].get(c, 0.0) for c in cc)
    if not commun:
        return 0.0
    mc = mots(caption)
    bonus = 0.25 * len(mc & set(sac.get("mots") or ()))
    return round((commun + bonus) / (len(cc) ** 0.5), 3)


def choisir(sac: dict, captions: list[dict], seuil: float = 0.6) -> tuple[dict | None, float]:
    """La caption qui colle le mieux à la vidéo, et son score. (None, score) si rien n'atteint le seuil."""
    if not captions:
        return None, 0.0
    notes = [(score(sac, c.get("texte", "")), c) for c in captions]
    notes.sort(key=lambda x: x[0], reverse=True)
    meilleure, caption = notes[0][0], notes[0][1]
    return (caption if meilleure >= seuil else None), meilleure


def repartir(sacs: dict, captions: list[dict], seuil: float = 0.6) -> tuple[dict, dict]:
    """Répartit les captions sur les vidéos **d'un seul coup**, par affinité décroissante.

    Autrement dit : la quote qui parle de l'océan est posée sur la vidéo qui montre le plus l'océan,
    et pas sur la première vidéo venue qui la frôle. On traite les meilleurs couples d'abord ; chaque
    vidéo et chaque caption ne servent qu'une fois.

    `sacs` : {nom de la vidéo: sac_video(...)}.
    Renvoie ({nom: (caption, note)}, {nom: meilleure note possible pour cette vidéo}).
    """
    paires, meilleures = [], {}
    for nom, sac in sacs.items():
        for c in captions:
            s = score(sac, c.get("texte", ""))
            if s > meilleures.get(nom, 0.0):
                meilleures[nom] = s
            if s >= seuil:
                paires.append((s, nom, c))
    paires.sort(key=lambda p: (-p[0], p[1]))
    pris_v: set[str] = set()
    pris_c: set[str] = set()
    out: dict[str, tuple[dict, float]] = {}
    for s, nom, c in paires:
        cle = str(c.get("id") or c.get("texte"))
        if nom in pris_v or cle in pris_c:
            continue
        out[nom] = (c, s)
        pris_v.add(nom)
        pris_c.add(cle)
    return out, meilleures
