"""Paroles : transcription minutée d'un extrait audio, puis découpe en lignes à incruster.

La transcription est faite **sur l'ordinateur**, par faster-whisper : rien n'est envoyé ailleurs.
Elle rend la liste des mots avec leur instant d'apparition. Ces mots sont ensuite regroupés en
lignes affichables, de trois façons au choix :

    "mot"     un mot à la fois, pile sur le chant
    "groupe"  deux ou trois mots, ça bouge au rythme sans devenir illisible
    "ligne"   une phrase entière, découpée aux silences

Sur du chant, aucune transcription n'est parfaite : le texte se relit et se corrige ligne par ligne
dans Monteur, et le minutage, lui, est conservé.

Tout est gardé en cache à côté des données, par extrait audio (chemin + date de modification) :
on ne retranscrit pas deux fois le même morceau.
"""
from __future__ import annotations

import hashlib
import json
import re
import subprocess
import sys
from pathlib import Path

from . import stockage
from .config import DOSSIER_DONNEES

DOSSIER = DOSSIER_DONNEES / "paroles"
MODELE_DEFAUT = "small"          # bon compromis justesse / vitesse sur un Mac récent
MODES = ("ligne", "groupe", "mot")
MOTS_PAR_GROUPE = 3
MOTS_PAR_LIGNE = 7
TROU = 0.55                      # silence (s) au-delà duquel on passe à la ligne suivante
TROU_LIGNE = 0.95                # en mode « ligne », on ne coupe qu'aux vrais silences :
                                 # entre deux mots chantés il y a souvent un demi-temps
DUREE_MINI = 0.45                # une ligne reste lisible même si le mot est très court
RESTE_TOLERE = 2.5               # au-delà, la fin du morceau n'est pas couverte : on reprend


# ───────────── moteur ─────────────

def moteur_pret() -> bool:
    """La transcription est-elle installée ?"""
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:  # noqa: BLE001
        return False


def explication() -> str:
    if moteur_pret():
        return "Transcription prête (faster-whisper, sur cet ordinateur)."
    return ("La transcription n'est pas encore installée. Un seul clic suffit : elle se télécharge "
            "une fois, puis fonctionne hors ligne.")


def installer(log=print) -> bool:
    """Installe faster-whisper dans l'environnement de Monteur. Une seule fois."""
    log("→ Installation de la transcription (quelques minutes la première fois)…")
    r = subprocess.run([sys.executable, "-m", "pip", "install", "faster-whisper"],
                       capture_output=True, text=True)
    for ligne in (r.stdout or "").splitlines()[-6:]:
        log(ligne)
    if r.returncode != 0:
        log((r.stderr or "").strip()[-600:] or "Échec de l'installation.")
        return False
    log("✅ Transcription installée.")
    return moteur_pret()


# ───────────── cache ─────────────

def _cle(fichier: Path) -> str:
    try:
        return hashlib.md5(f"{Path(fichier)}|{Path(fichier).stat().st_mtime_ns}"
                           .encode("utf-8", "replace")).hexdigest()[:16]
    except OSError:
        return ""


def _fichier_cache(fichier: Path) -> Path:
    return DOSSIER / f"{_cle(fichier)}.json"


def lire(fichier: Path) -> dict:
    """Ce que Monteur sait déjà de cet extrait : {mots, lignes, mode, langue}."""
    c = _cle(fichier)
    return stockage.lire(_fichier_cache(fichier), {}) if c else {}


def ecrire(fichier: Path, data: dict) -> None:
    if _cle(fichier):
        stockage.ecrire(_fichier_cache(fichier), data)


def oublier(fichier: Path) -> None:
    _fichier_cache(fichier).unlink(missing_ok=True)


# ───────────── transcription ─────────────

def duree(fichier: Path) -> float:
    """Durée de l'extrait en secondes (0 si illisible)."""
    try:
        r = subprocess.run(["ffprobe", "-v", "error", "-show_entries", "format=duration",
                            "-of", "default=nw=1:nk=1", str(fichier)],
                           capture_output=True, text=True, timeout=25)
        return round(float((r.stdout or "0").strip() or 0), 2)
    except (OSError, ValueError, subprocess.SubprocessError):
        return 0.0


def _morceau(fichier: Path, depart: float) -> Path:
    """Copie de l'extrait à partir de `depart`, pour reprendre une transcription en cours de route."""
    DOSSIER.mkdir(parents=True, exist_ok=True)
    cible = DOSSIER / f"_reprise_{_cle(fichier)}_{int(depart * 100)}.wav"
    subprocess.run(["ffmpeg", "-y", "-hide_banner", "-loglevel", "error", "-ss", f"{depart:.3f}",
                    "-i", str(fichier), "-ac", "1", "-ar", "16000", str(cible)],
                   capture_output=True, text=True)
    return cible


def _passe(moteur, fichier: Path, langue: str, decalage: float = 0.0) -> tuple[list[dict], str]:
    """Une lecture complète du fichier. Les réglages sont faits pour du **chant**, pas pour une dictée.

    Par défaut, Whisper jette les passages qu'il juge silencieux, peu sûrs ou trop répétitifs : sur
    une chanson, c'est exactement ce qu'il ne faut pas — l'instrumental passe pour du silence et un
    refrain qui revient passe pour une répétition. Les trois garde-fous sont donc désactivés, et le
    détecteur de voix (VAD) aussi : il coupait tout ce qui n'était pas de la parole nette, d'où des
    paroles qui s'arrêtaient après quelques secondes.
    """
    segments, info = moteur.transcribe(
        str(fichier), language=(langue or None), word_timestamps=True,
        vad_filter=False,                     # le VAD prenait le chant sur fond musical pour du silence
        condition_on_previous_text=False,     # évite les boucles sur les refrains
        no_speech_threshold=None,             # ne jamais écarter un passage pour « silence »
        compression_ratio_threshold=None,     # un refrain qui se répète n'est pas un défaut
        log_prob_threshold=None,              # le chant est toujours moins sûr qu'une voix parlée
        beam_size=5)
    mots: list[dict] = []
    for seg in segments:
        for m in (getattr(seg, "words", None) or []):
            texte = str(m.word).strip()
            if not texte:
                continue
            d = round(float(m.start) + decalage, 2)
            mots.append({"mot": texte, "debut": d,
                         "fin": round(max(float(m.end) + decalage, d + 0.08), 2)})
    return mots, str(getattr(info, "language", "") or "")


def transcrire(fichier: Path, langue: str = "", modele: str = MODELE_DEFAUT, log=print) -> list[dict]:
    """Les mots de l'extrait, avec leur minutage. [{"mot", "debut", "fin"}, …].

    `langue` vide = Monteur la devine. Le modèle se télécharge au premier usage, puis reste sur
    l'ordinateur. Si la lecture s'arrête avant la fin du morceau — ça arrive sur un long passage
    instrumental — Monteur **reprend là où elle s'est arrêtée** jusqu'à couvrir tout l'extrait.
    """
    from faster_whisper import WhisperModel

    totale = duree(fichier)
    log(f"→ Lecture du chant (modèle « {modele} », {totale:.1f} s)…")
    moteur = WhisperModel(modele, device="cpu", compute_type="int8")
    mots, trouvee = _passe(moteur, fichier, langue)
    langue = langue or trouvee

    reprises, temporaires, precedent = 0, [], -1.0
    while totale and reprises < 12:
        atteint = mots[-1]["fin"] if mots else 0.0
        if totale - atteint <= RESTE_TOLERE or atteint <= precedent + 0.1:
            break                            # couvert, ou la reprise n'avance plus
        precedent = atteint
        depart = max(0.0, atteint - 0.2)
        log(f"   ↻ reprise à {depart:.1f} s (il reste {totale - atteint:.1f} s)…")
        bout = _morceau(fichier, depart)
        temporaires.append(bout)
        suite, _ = _passe(moteur, bout, langue, decalage=depart)
        suite = [m for m in suite if m["debut"] > atteint - 0.05]
        if not suite:
            break
        mots += suite
        reprises += 1
    for f in temporaires:
        f.unlink(missing_ok=True)

    mots.sort(key=lambda m: m["debut"])
    couvert = mots[-1]["fin"] if mots else 0.0
    if mots:
        log(f"✓ {len(mots)} mot(s) reconnus — de {mots[0]['debut']:.1f} s à {couvert:.1f} s "
            f"sur {totale:.1f} s")
    else:
        log("✓ aucun mot reconnu dans cet extrait.")
    if mots and totale and totale - couvert > RESTE_TOLERE:
        log(f"⚠ Les {totale - couvert:.1f} dernières secondes n'ont rien donné "
            "(instrumental ? voix trop couverte ?). Tu peux ajouter les lignes à la main.")
    return mots


# ───────────── découpe en lignes ─────────────

def grouper(mots: list[dict], mode: str = "ligne", par_groupe: int = MOTS_PAR_GROUPE,
            par_ligne: int = MOTS_PAR_LIGNE, trou: float = TROU) -> list[dict]:
    """Regroupe les mots en lignes affichables. Renvoie [{"texte", "debut", "fin"}, …]."""
    mots = [m for m in (mots or []) if str(m.get("mot") or "").strip()]
    if not mots:
        return []
    mode = mode if mode in MODES else "ligne"
    if mode == "ligne" and trou <= TROU:
        trou = TROU_LIGNE        # sinon une phrase chantée se casse en petits bouts
    paquets: list[list[dict]] = []
    courant: list[dict] = []
    for i, m in enumerate(mots):
        if courant:
            silence = float(m["debut"]) - float(courant[-1]["fin"])
            plein = len(courant) >= (par_groupe if mode == "groupe" else par_ligne)
            coupe_phrase = mode == "ligne" and re.search(r"[.!?…]$", courant[-1]["mot"])
            if mode == "mot" or plein or silence > trou or coupe_phrase:
                paquets.append(courant)
                courant = []
        courant.append(m)
    if courant:
        paquets.append(courant)

    lignes = []
    for p in paquets:
        debut = round(float(p[0]["debut"]), 2)
        fin = round(max(float(p[-1]["fin"]), debut + DUREE_MINI), 2)
        lignes.append({"texte": " ".join(m["mot"] for m in p).strip(), "debut": debut, "fin": fin})
    # une ligne ne déborde jamais sur la suivante
    for a, b in zip(lignes, lignes[1:]):
        if a["fin"] > b["debut"]:
            a["fin"] = round(max(a["debut"] + 0.1, b["debut"]), 2)
    return lignes


def depuis_grille(texte: str, temps: list[float], duree: float) -> list[dict]:
    """Repli sans transcription : les lignes collées sont réparties sur la grille du rythme.

    `temps` = les instants des temps détectés par le module rythme. À défaut, découpe régulière.
    """
    phrases = [l.strip() for l in str(texte or "").splitlines() if l.strip()]
    if not phrases:
        return []
    duree = max(0.5, float(duree or 0))
    pts = sorted(float(t) for t in (temps or []) if 0 <= float(t) < duree)
    if len(pts) < len(phrases) + 1:
        pas = duree / len(phrases)
        pts = [i * pas for i in range(len(phrases) + 1)]
    else:
        # on répartit les phrases sur les temps, à intervalle régulier de temps forts
        saut = max(1, len(pts) // len(phrases))
        pts = [pts[min(i * saut, len(pts) - 1)] for i in range(len(phrases))] + [duree]
    lignes = []
    for i, ph in enumerate(phrases):
        debut = round(pts[i], 2)
        fin = round(max(pts[i + 1] if i + 1 < len(pts) else duree, debut + DUREE_MINI), 2)
        lignes.append({"texte": ph, "debut": debut, "fin": min(fin, round(duree, 2))})
    return lignes


def decaler(lignes: list[dict], debut: float = 0.0, fin: float = 0.0) -> list[dict]:
    """Recale les lignes sur un extrait rogné : ce qui tombe hors de [debut, fin] est écarté."""
    debut = max(0.0, float(debut or 0))
    fin = float(fin or 0)
    out = []
    for l in (lignes or []):
        d, f = float(l["debut"]) - debut, float(l["fin"]) - debut
        if fin and float(l["debut"]) >= fin:
            continue
        if f <= 0:
            continue
        if fin:
            f = min(f, fin - debut)
        out.append({"texte": l["texte"], "debut": round(max(0.0, d), 2), "fin": round(f, 2)})
    return out


def borner(lignes: list[dict], duree: float) -> list[dict]:
    """Ne garde que ce qui tient dans la vidéo, et coupe la dernière ligne à la fin."""
    duree = float(duree or 0)
    if duree <= 0:
        return list(lignes or [])
    out = []
    for l in (lignes or []):
        if float(l["debut"]) >= duree - 0.05:
            continue
        out.append({**l, "fin": round(min(float(l["fin"]), duree), 2)})
    return out


def nettoyer(lignes: list[dict], duree: float = 0.0) -> list[dict]:
    """Remet de l'ordre après une correction à la main.

    Les lignes vides disparaissent, le reste est trié, borné à l'extrait, et une ligne ne déborde
    jamais sur la suivante.
    """
    out = []
    for l in (lignes or []):
        texte = str(l.get("texte") or "").strip()
        if not texte:
            continue                        # une ligne vidée est une ligne supprimée
        d = max(0.0, round(float(l.get("debut") or 0), 2))
        f = round(float(l.get("fin") or 0), 2)
        if duree:
            d = min(d, max(0.0, duree - 0.1))
        if f <= d:
            f = d + DUREE_MINI
        if duree:
            f = min(f, duree)
        out.append({"texte": texte, "debut": d, "fin": round(max(f, d + 0.1), 2)})
    out.sort(key=lambda x: x["debut"])
    for a, b in zip(out, out[1:]):
        if a["fin"] > b["debut"]:
            a["fin"] = round(max(a["debut"] + 0.1, b["debut"]), 2)
    return out


def texte_entier(lignes: list[dict]) -> str:
    return "\n".join(str(l.get("texte") or "") for l in (lignes or []))
