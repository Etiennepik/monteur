"""Petits fichiers JSON d'état (écriture atomique + verrou)."""
from __future__ import annotations

import json
import threading
from pathlib import Path

_verrous: dict[str, threading.RLock] = {}
_global = threading.Lock()


def verrou(p: Path) -> threading.RLock:
    with _global:
        return _verrous.setdefault(str(p), threading.RLock())


def lire(p: Path, defaut):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        return defaut


def ecrire(p: Path, data) -> None:
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(p.suffix + ".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=1), encoding="utf-8")
    tmp.replace(p)


def modifier(p: Path, defaut, fonction):
    """Lit, applique fonction(data) -> data, réécrit. Renvoie la nouvelle valeur."""
    with verrou(p):
        data = fonction(lire(p, defaut))
        ecrire(p, data)
        return data
