"""Réserve de rushs pour les mélanges : toutes les vidéos du thème, sans doublons visuels.

Une série « Mélanger les rushs du thème » pioche dans UNE réserve commune à tous ses montages :
- chaque vidéo du thème est découpée en rushs (ses plans ; un plan séquence ou un plan très long est
  coupé en morceaux de quelques secondes, pour ne pas toujours reprendre le même passage) ;
- on prend d'abord les vidéos, puis les rushs, qui ont **le moins servi** dans la série : toutes les
  vidéos passent avant qu'une seule ne revienne ;
- chaque rush a une petite empreinte d'image (image du milieu : dHash 64 bits pour les formes, plus
  une vignette 9×8 en couleurs) : deux rushs qui se ressemblent par la forme ET la couleur — la
  même scène dans deux vidéos, ou deux plans presque identiques — forment un même groupe, et un montage ne prend jamais deux fois le même groupe tant qu'il reste autre chose ;
- jamais deux plans de suite tirés de la même vidéo.
Découpage et empreintes sont mémorisés dans donnees/rushs.json.
"""
from __future__ import annotations

import random
import subprocess
from pathlib import Path

from . import stockage
from .config import DOSSIER_DONNEES
from .rendu import plans_video, sonder

CACHE = DOSSIER_DONNEES / "rushs.json"
MORCEAU = 3.0          # un rush plus long que LONG est coupé en morceaux de cette durée
LONG = 6.0
PROCHES = 10           # distance de Hamming (sur 64 bits) en dessous de laquelle les formes se ressemblent
COULEURS = 18          # écart moyen (0-255) des vignettes en dessous duquel les couleurs se ressemblent


def _empreinte(video: Path, t: float) -> dict | None:
    """Empreinte de l'image à l'instant t : {"h": dHash 64 bits, "c": vignette 9×8 RGB}."""
    try:
        r = subprocess.run(["ffmpeg", "-v", "error", "-ss", f"{max(0.0, t):.2f}", "-i", str(video),
                            "-frames:v", "1", "-vf", "scale=9:8,format=rgb24", "-f", "rawvideo", "-"],
                           capture_output=True, timeout=30)
    except (OSError, subprocess.SubprocessError):
        return None
    c = list(r.stdout[:216])
    if len(c) < 216:
        return None
    gris = [(c[3 * i] + c[3 * i + 1] + c[3 * i + 2]) / 3 for i in range(72)]
    h = 0
    for y in range(8):
        for x in range(8):
            h = (h << 1) | (1 if gris[y * 9 + x] > gris[y * 9 + x + 1] else 0)
    return {"h": h, "c": c}


def _semblables(a: dict | None, b: dict | None) -> bool:
    if not a or not b:
        return False
    if bin(a["h"] ^ b["h"]).count("1") > PROCHES:          # test rapide d'abord
        return False
    return sum(abs(x - y) for x, y in zip(a["c"], b["c"])) / len(a["c"]) <= COULEURS


def _decouper(plans: list, duree: float) -> list[list[float]]:
    out = []
    for a, b in (plans or [[0.0, duree]]):
        a, b = float(a), float(b)
        if b - a < 0.5:
            continue
        if b - a <= LONG:
            out.append([round(a, 2), round(b, 2)])
            continue
        n = max(2, int((b - a) // MORCEAU))
        pas = (b - a) / n
        out += [[round(a + i * pas, 2), round(a + (i + 1) * pas, 2)] for i in range(n)]
    return out or [[0.0, round(duree, 2)]]


class Reserve:
    def __init__(self, videos: list[dict], log=print):
        self.rushs: list[dict] = []
        self.usage_video: dict[str, int] = {}
        self.usage_groupe: dict[int, int] = {}
        cache = stockage.lire(CACHE, {}) or {}
        change = False
        for v in videos:
            chemin = Path(v["chemin"])
            try:
                cle = f"{v['nom']}|{int(chemin.stat().st_mtime)}"
            except OSError:
                continue
            fiche = cache.get(cle)
            if not fiche or any(not isinstance(r.get("h"), (dict, type(None))) for r in fiche["rushs"]):
                try:
                    info = sonder(chemin)
                    plans = v.get("plans") or plans_video(chemin, duree=info["duree"])
                except Exception:  # noqa: BLE001
                    continue
                morceaux = _decouper(plans, float(info["duree"]))
                fiche = {"duree": info["duree"],
                         "rushs": [{"a": a, "b": b, "h": _empreinte(chemin, (a + b) / 2)} for a, b in morceaux]}
                cache[cle] = fiche
                change = True
            self.usage_video[v["nom"]] = 0
            for r in fiche["rushs"]:
                self.rushs.append({"video": v, "a": float(r["a"]), "b": float(r["b"]), "h": r.get("h"),
                                   "usage": 0})
        if change:
            stockage.ecrire(CACHE, cache)
        # regroupe les rushs qui se ressemblent (même scène, vidéos en double…)
        groupes: list[int] = []
        for i, r in enumerate(self.rushs):
            g = i
            for j in range(i):
                if _semblables(r["h"], self.rushs[j]["h"]):
                    g = self.rushs[j]["groupe"]
                    break
            r["groupe"] = g
            groupes.append(g)
        self.n_groupes = len(set(groupes))
        doublons = len(self.rushs) - self.n_groupes
        log(f"   🎞 {len(self.usage_video)} vidéo(s), {len(self.rushs)} rushs"
            + (f" ({doublons} trop ressemblant(s) à un autre, écartés tant qu'il reste du neuf)" if doublons else ""))
        self.nouveau_montage()

    def nouveau_montage(self):
        self._groupes_pris: set[int] = set()
        self._derniere = None

    def tirer(self, duree: float) -> dict | None:
        """Le rush le plus « neuf » pour un plan de `duree` secondes. Renvoie {video, debut}."""
        if not self.rushs:
            return None

        def note(r):
            return (r["groupe"] in self._groupes_pris,                 # déjà vu dans ce montage
                    r["video"]["nom"] == self._derniere,               # même vidéo que le plan d'avant
                    self.usage_groupe.get(r["groupe"], 0),             # scène déjà servie dans la série
                    self.usage_video[r["video"]["nom"]],               # vidéo déjà servie
                    r["usage"],
                    (r["b"] - r["a"]) + 0.05 < duree,                  # trop court pour le plan
                    random.random())
        r = min(self.rushs, key=note)
        r["usage"] += 1
        self.usage_video[r["video"]["nom"]] += 1
        self.usage_groupe[r["groupe"]] = self.usage_groupe.get(r["groupe"], 0) + 1
        self._groupes_pris.add(r["groupe"])
        self._derniere = r["video"]["nom"]
        marge = max(0.0, (r["b"] - r["a"]) - duree)
        return {"video": r["video"], "debut": round(r["a"] + random.uniform(0, marge), 2),
                "rush": (r["a"], r["b"])}

    def bilan(self) -> str:
        servies = sum(1 for n in self.usage_video.values() if n)
        return f"{servies}/{len(self.usage_video)} vidéos utilisées"
