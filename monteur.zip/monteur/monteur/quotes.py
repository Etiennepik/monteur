"""Extraction de quotes depuis des visuels (images, vidéos, carrousels) envoyés par l'extension Chrome.

Parcours d'un visuel :
  1. récupération du média : post Instagram / TikTok / YouTube (vidéo ou carrousel via yt-dlp, ou vidéo déjà
     dans la bibliothèque), vidéo directe, sinon l'image envoyée par l'extension ;
  2. lecture du texte (ocr.py) — pour une vidéo, plusieurs images sont lues et le texte le plus présent est gardé ;
  3. nettoyage : @compte, filigranes, éléments d'interface, retours à la ligne, guillemets, auteur séparé ;
  4. thème : celui choisi, ou deviné (mots-clés du thème + captions déjà rangées), sinon « À classer » ;
  5. ajout dans les captions, sans doublon (même à la ponctuation près).
"""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import math
import re
import shutil
import subprocess
import threading
import time
import unicodedata
import urllib.request
import uuid
from collections import Counter
from pathlib import Path

from . import captions, ocr, stockage
from .config import DOSSIER_DONNEES

FILE = DOSSIER_DONNEES / "file_quotes.json"
DOSSIER = DOSSIER_DONNEES / "quotes"
ENTREES = DOSSIER / "entrees"          # images envoyées par l'extension
MINIATURES = DOSSIER / "miniatures"    # vignettes affichées dans l'onglet Captions
AUTO = "auto"
A_CLASSER = captions.A_CLASSER
UA = ("Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) "
      "Chrome/129.0 Safari/537.36")
_travail = threading.Lock()
_etat = {"en_cours": False, "job": ""}


def maintenant() -> str:
    return dt.datetime.now().isoformat(timespec="seconds")


# ════════════════════════════ nettoyage du texte ════════════════════════════

_BRUIT = re.compile(
    r"^(?:@[\w.]+|#\w+(?:\s+#\w+)*|(?:https?://|www\.)\S+|\S+\.(?:com|fr|net|org|io|co)(?:/\S*)?|"
    r"\d+[\d\s.,:/kKmM]*|(?:\d+\s*)?(?:likes?|j'aime|comments?|commentaires?|vues|views|reposts?|shares?)|"
    r"follow|suivre|abonn[ée]s?|followers?|following|abonnements|reply|r[ée]pondre|voir la traduction|"
    r"see translation|traduire|more|plus|\.\.\.\s*plus|share|partager|save|enregistrer|liked by.*|aim[ée] par.*|"
    r"original audio|audio original|son original|sponsored|sponsoris[ée]|publicit[ée]|"
    r"voir plus|see more|il y a \d+.*|\d+\s*(?:h|min|j|d|w|sem)|instagram|tiktok|pinterest|"
    r"envoyer|send|message|ajouter un commentaire.*|add a comment.*)$",
    re.IGNORECASE)
_TIRETS = "—–-~•·"
_GUILLEMETS = "\"“”«»„‟'‘’`´"


def _bruit(texte: str) -> bool:
    t = texte.strip(" .·•|")
    if len(re.sub(r"\W", "", t)) < 2:
        return True
    if _BRUIT.match(t):
        return True
    mots = t.split()
    return bool(mots) and all(m.startswith(("@", "#")) for m in mots)


def _hauteur(l: dict) -> float:
    return l["h"]


def _blocs(lignes: list[dict]) -> list[list[dict]]:
    """Regroupe les lignes proches (même paragraphe) : écart vertical faible, tailles voisines, chevauchement."""
    lignes = sorted(lignes, key=lambda l: (l["y"], l["x"]))
    blocs: list[list[dict]] = []
    for l in lignes:
        place = None
        for b in blocs:
            d = b[-1]
            hm = (d["h"] + l["h"]) / 2
            ecart = l["y"] - (d["y"] + d["h"])
            taille_ok = max(d["h"], l["h"]) / max(1e-6, min(d["h"], l["h"])) < 1.9
            recouvre = min(d["x"] + d["w"], l["x"] + l["w"]) - max(d["x"], l["x"]) > -0.08
            if -0.6 * hm < ecart < 1.6 * hm and taille_ok and recouvre:
                place = b
                break
        if place is not None:
            place.append(l)
        else:
            blocs.append([l])
    return blocs


def _joindre(lignes: list[dict]) -> str:
    rangs: list[list[dict]] = []
    for l in sorted(lignes, key=lambda l: l["y"]):
        if rangs and abs(l["y"] - rangs[-1][0]["y"]) < 0.5 * max(l["h"], rangs[-1][0]["h"]):
            rangs[-1].append(l)          # même hauteur : morceaux d'une même ligne
        else:
            rangs.append([l])
    morceaux: list[str] = []
    for l in (x for r in rangs for x in sorted(r, key=lambda l: l["x"])):
        t = " ".join(l["texte"].split())
        if morceaux and morceaux[-1].endswith("-") and t[:1].islower():
            morceaux[-1] = morceaux[-1][:-1] + t
        else:
            morceaux.append(t)
    return " ".join(morceaux)


def _casse_phrase(t: str) -> str:
    """TEXTE TOUT EN MAJUSCULES → Texte en casse normale (le style majuscules se règle au montage)."""
    lettres = [c for c in t if c.isalpha()]
    if len(lettres) < 12 or sum(c.isupper() for c in lettres) / len(lettres) < 0.85:
        return t
    t = t.lower()
    t = re.sub(r"(^|[.!?…]\s+|[\"“«]\s*)([a-zà-ÿ])", lambda m: m.group(1) + m.group(2).upper(), t)
    t = re.sub(r"\bi\b", "I", t)
    t = re.sub(r"\bi'(m|ll|ve|d)\b", lambda m: "I'" + m.group(1), t)
    return t


def nettoyer(texte: str) -> tuple[str, str]:
    """(quote, auteur) à partir du texte brut d'un bloc."""
    t = " ".join((texte or "").replace(" ", " ").split())
    t = t.replace("’", "'").replace("‘", "'")
    auteur = ""
    m = re.match(rf"^(.*?[\w.!?…{re.escape(_GUILLEMETS)}])(?:\s+[{re.escape(_TIRETS)}]{{1,2}}\s*|\s*[—–~]\s*)"
                 rf"([A-ZÀ-Ý][\w .'\-]{{1,40}})$", t)
    if m and len(m.group(2).split()) <= 5 and len(m.group(1).split()) >= 3:
        t, auteur = m.group(1), m.group(2).strip()
    t = t.strip(" " + _GUILLEMETS)
    t = re.sub(r"\s+([,.])", r"\1", t)
    t = _casse_phrase(t)
    if t[:1].islower():
        t = t[:1].upper() + t[1:]
    return t.strip(), auteur.strip(" .")


def extraire(lignes: list[dict]) -> dict | None:
    """Choisit la quote dans les lignes lues : le bloc de texte le plus grand et le plus central.

    Renvoie {"texte", "auteur", "conf", "a_verifier"} ou None si rien de lisible.
    """
    utiles = [l for l in lignes if l.get("texte", "").strip() and l.get("conf", 0) >= 0.25 and not _bruit(l["texte"])]
    if not utiles:
        return None
    blocs = _blocs(utiles)

    def score(b):
        chars = sum(len(l["texte"]) for l in b)
        h = sum(l["h"] for l in b) / len(b)
        cy = sum(l["y"] + l["h"] / 2 for l in b) / len(b)
        centre = 1.15 - 0.3 * abs(cy - 0.5)
        mots = len(" ".join(l["texte"] for l in b).split())
        seul = 0.4 if mots < 3 else 1.0
        return chars * math.sqrt(h) * centre * seul

    blocs.sort(key=score, reverse=True)
    meilleur = blocs[0]
    ambigu = len(blocs) > 1 and score(blocs[1]) > 0.7 * score(meilleur) and \
        len(" ".join(l["texte"] for l in blocs[1]).split()) >= 4

    # auteur : ligne courte commençant par un tiret, juste sous le bloc
    auteur = ""
    bas = max(l["y"] + l["h"] for l in meilleur)
    hm = sum(l["h"] for l in meilleur) / len(meilleur)
    corps = []
    for l in meilleur:
        if l["texte"].strip()[:1] in _TIRETS and len(l["texte"].split()) <= 6 and l is meilleur[-1] and len(meilleur) > 1:
            auteur = l["texte"].strip(" " + _TIRETS)
        else:
            corps.append(l)
    if not auteur:
        for b in blocs[1:]:
            for l in b:
                t = l["texte"].strip()
                if t[:1] in _TIRETS and len(t.split()) <= 6 and 0 <= l["y"] - bas < 4 * hm:
                    auteur = t.strip(" " + _TIRETS)
                    break
            if auteur:
                break

    texte, auteur2 = nettoyer(_joindre(corps))
    auteur = (auteur or auteur2).strip(" .")
    if not texte or len(re.sub(r"\W", "", texte)) < 4:
        return None
    conf = sum(l["conf"] * len(l["texte"]) for l in corps) / max(1, sum(len(l["texte"]) for l in corps))
    nb_mots = len(texte.split())
    a_verifier = conf < 0.6 or nb_mots < 3 or nb_mots > 80 or ambigu
    return {"texte": texte, "auteur": auteur, "conf": round(conf, 3), "a_verifier": bool(a_verifier)}


def _similaires_ou_inclus(a: str, b: str) -> bool:
    na, nb = captions.normaliser(a), captions.normaliser(b)
    if not na or not nb:
        return False
    if captions.similaires(a, b):
        return True
    court, long_ = sorted((na, nb), key=len)
    return len(court) >= 12 and court in long_


# ════════════════════════════ lecture des images / vidéos ════════════════════════════

def lire_image(chemin: Path) -> dict | None:
    return extraire(ocr.lire(chemin))


def _ffprobe() -> str:
    for p in ("/opt/homebrew/bin/ffprobe", "/usr/local/bin/ffprobe"):
        if Path(p).exists():
            return p
    return shutil.which("ffprobe") or "ffprobe"


def _duree(video: Path) -> float:
    try:
        r = subprocess.run([_ffprobe(), "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0",
                            str(video)], capture_output=True, text=True, timeout=30)
        return float(r.stdout.strip() or 0)
    except Exception:  # noqa: BLE001
        return 0.0


def _ffmpeg() -> str:
    for p in ("/opt/homebrew/bin/ffmpeg", "/usr/local/bin/ffmpeg"):
        if Path(p).exists():
            return p
    return shutil.which("ffmpeg") or "ffmpeg"


def images_video(video: Path, dossier: Path, n: int = 8, agrandir: bool = False) -> list[Path]:
    """Extrait n images réparties sur la vidéo (début et fin évités : fondus, écrans de fin).

    `agrandir` : deuxième passage, image agrandie pour les textes petits ou peu contrastés.
    """
    duree = _duree(video)
    dossier.mkdir(parents=True, exist_ok=True)
    if duree <= 0.5:
        # durée inconnue (ffprobe absent) ou vidéo très courte : on tente quand même plusieurs instants
        instants = [0.0, 0.3, 1.0, 2.0, 4.0][:max(3, n // 2)]
    else:
        instants = [duree * (0.04 + 0.92 * i / max(1, n - 1)) for i in range(n)]
    filtre = "scale='min(1920,iw*2)':-2,unsharp=5:5:0.8" if agrandir else "scale='min(1280,iw)':-2"
    sorties = []
    for i, t in enumerate(instants):
        out = dossier / f"image_{i:02d}.jpg"
        subprocess.run([_ffmpeg(), "-y", "-v", "error", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1",
                        "-vf", filtre, "-q:v", "2", str(out)],
                       capture_output=True, timeout=60)
        if out.exists() and out.stat().st_size > 0:
            sorties.append(out)
    return sorties


def _lire_images(images: list[Path]) -> list[tuple[dict, Path]]:
    lus = []
    for im in images:
        try:
            q = lire_image(im)
        except Exception:  # noqa: BLE001
            q = None
        if q and len(q["texte"].split()) >= 2:
            lus.append((q, im))
    return lus


def lire_video(video: Path, dossier: Path) -> tuple[dict | None, Path | None]:
    """Lit plusieurs images de la vidéo et garde le texte qui revient le plus souvent.

    Rien de lisible au premier passage ? On recommence avec deux fois plus d'images, agrandies :
    beaucoup de vidéos n'affichent leur phrase qu'une seconde, ou en petits caractères.
    """
    images = images_video(video, dossier)
    lus = _lire_images(images)
    if not lus:
        images2 = images_video(video, dossier / "bis", n=16, agrandir=True)
        lus = _lire_images(images2)
        if lus:
            images = images2
    if not lus:
        return None, (images[len(images) // 2] if images else None)
    groupes: list[list[tuple[dict, Path]]] = []
    for q, im in lus:
        for g in groupes:
            if _similaires_ou_inclus(g[0][0]["texte"], q["texte"]):
                g.append((q, im))
                break
        else:
            groupes.append([(q, im)])
    groupes.sort(key=lambda g: (len(g), sum(x[0]["conf"] for x in g)), reverse=True)
    g = groupes[0]
    conf_max = max(x[0]["conf"] for x in g)
    # le texte complet (une phrase qui s'affiche mot à mot est plus longue sur la dernière image)
    q, im = max((x for x in g if x[0]["conf"] >= conf_max - 0.15), key=lambda x: len(x[0]["texte"]))
    q = dict(q)
    plusieurs = sum(1 for x in groupes if len(x) >= 2) > 1
    q["a_verifier"] = bool(q["a_verifier"] or plusieurs or (len(g) == 1 and len(images) > 2))
    return q, im


def analyser_video(video: Path, dossier: Path, n: int = 6) -> dict:
    """Une seule lecture d'images pour tout savoir d'une vidéo : texte incrusté **et** contenu montré.

    Renvoie {"presente", "texte", "vues", "images", "etiquettes"}. `etiquettes` est ce que le Mac
    reconnaît à l'image ([("sunset", 0.74), …]) ; liste vide ailleurs que sur un Mac.
    """
    images = images_video(video, dossier, n=n)
    r = _verdict_texte(images)
    vues: dict[str, float] = {}
    for im in images[:: max(1, len(images) // 3 or 1)][:3]:      # trois images suffisent pour le décor
        try:
            for nom, conf in ocr.etiquettes(im):
                vues[nom] = max(vues.get(nom, 0.0), conf)
        except Exception:  # noqa: BLE001
            continue
    r["etiquettes"] = sorted(vues.items(), key=lambda x: x[1], reverse=True)[:14]
    return r


def texte_incruste(video: Path, dossier: Path, n: int = 6) -> dict:
    """La vidéo porte-t-elle déjà une phrase incrustée ?

    On lit quelques images et on ne retient qu'un texte qui **revient** d'une image à l'autre : un
    filigrane, un @compte ou un bouton d'interface ne passent pas (ils sont déjà écartés par `_bruit`),
    et une phrase affichée une seule fois sur six images n'est retenue que si elle est longue et nette.

    Renvoie {"presente": bool, "texte": str, "vues": int, "images": int}.
    """
    return _verdict_texte(images_video(video, dossier, n=n))


def _verdict_texte(images: list[Path]) -> dict:
    lus = _lire_images(images)
    if not lus:
        return {"presente": False, "texte": "", "vues": 0, "images": len(images)}
    groupes: list[list[dict]] = []
    for q, _im in lus:
        for g in groupes:
            if _similaires_ou_inclus(g[0]["texte"], q["texte"]):
                g.append(q)
                break
        else:
            groupes.append([q])
    groupes.sort(key=lambda g: (len(g), sum(x["conf"] for x in g)), reverse=True)
    g = groupes[0]
    q = max(g, key=lambda x: len(x["texte"]))
    mots = len(q["texte"].split())
    conf = max(x["conf"] for x in g)
    presente = (len(g) >= 2 and mots >= 3) or (len(g) == 1 and mots >= 6 and conf >= 0.65)
    return {"presente": bool(presente), "texte": q["texte"] if presente else "",
            "vues": len(g), "images": len(images)}


# ════════════════════════════ récupération des médias ════════════════════════════

def plateforme(url: str) -> str:
    u = (url or "").lower()
    for p in ("instagram", "tiktok", "pinterest"):
        if p in u:
            return p
    if "youtu" in u:
        return "youtube"
    return "web"


MOTIFS_POST = [
    r"instagram\.com/(?:[\w.]+/)?(?:p|reels?|tv)/[\w-]+",
    r"tiktok\.com/@[^/]+/(?:video|photo)/\d+",
    r"youtube\.com/shorts/[\w-]+",
    r"youtube\.com/watch\?v=[\w-]+",
    r"youtu\.be/[\w-]+",
    r"pinterest\.[a-z.]+/pin/[\w-]+",
]


def est_post(url: str) -> bool:
    """Lien d'un post précis (et non d'un compte, d'un tableau ou d'une recherche)."""
    u = (url or "").lower()
    return any(re.search(m, u) for m in MOTIFS_POST)


def cle(post_url: str = "", image_url: str = "", donnees: bytes | None = None) -> str:
    """Identifiant d'un visuel, pour ne pas extraire deux fois le même."""
    from .telechargement import cle_post
    if post_url:
        k = cle_post(post_url)
        if k:
            return k
        m = re.search(r"pinterest\.[a-z.]+/pin/([\w-]+)", post_url)
        if m:
            return f"pin:{m.group(1)}"
    if image_url and not image_url.startswith(("data:", "blob:")):
        return "img:" + hashlib.sha1(image_url.encode()).hexdigest()[:16]
    if donnees:
        return "img:" + hashlib.sha1(donnees).hexdigest()[:16]
    return "img:" + uuid.uuid4().hex[:16]


def telecharger(url: str, dest: Path, limite: int = 300_000_000, referer: str = "") -> Path:
    req = urllib.request.Request(url, headers={"User-Agent": UA, **({"Referer": referer} if referer else {})})
    with urllib.request.urlopen(req, timeout=60) as r, open(dest, "wb") as f:
        total = 0
        while True:
            bloc = r.read(1 << 16)
            if not bloc:
                break
            total += len(bloc)
            if total > limite:
                raise ValueError("fichier trop lourd")
            f.write(bloc)
    return dest


def _video_bibliotheque(cfg: dict, post_url: str) -> Path | None:
    from . import bibliotheque
    from .telechargement import cle_post
    k = cle_post(post_url)
    if not k:
        return None
    for v in bibliotheque.videos(cfg):
        if cle_post(v.get("url", "")) == k and Path(v["chemin"]).exists():
            return Path(v["chemin"])
    return None


def medias_post(cfg: dict, url: str, dossier: Path, log=print) -> list[tuple[str, Path]]:
    """[(« video » | « image », fichier)] d'un post (une entrée par image / vidéo d'un carrousel)."""
    import yt_dlp

    from .telechargement import fichier_cookies

    deja = _video_bibliotheque(cfg, url)
    if deja:
        return [("video", deja)]
    dossier.mkdir(parents=True, exist_ok=True)
    opts = {
        "outtmpl": str(dossier / "%(id)s.%(ext)s"),
        "format": "bv*[height<=1280]/b[height<=1280]/bv*/b",
        "ignore_no_formats_error": True,     # posts photo : on récupère quand même les images
        "noplaylist": True,                  # un carrousel Instagram reste lu en entier
        "playlistend": 20,
        "quiet": True, "no_warnings": True, "noprogress": True,
        "retries": 2,
    }
    nav = ((cfg.get("telechargement") or {}).get("cookies_navigateur") or "").strip()
    cookies = fichier_cookies(nav, log) if nav else None
    if cookies:
        opts["cookiefile"] = str(cookies)
    with yt_dlp.YoutubeDL(opts) as ydl:
        info = ydl.extract_info(url, download=True)
    if not info:
        return []
    entrees = [e for e in (info.get("entries") or [info]) if e]
    sortie: list[tuple[str, Path]] = []
    for i, e in enumerate(entrees):
        fichier = None
        for rd in e.get("requested_downloads") or []:
            p = Path(rd.get("filepath") or rd.get("_filename") or "")
            if p.is_file():
                fichier = p
        if fichier is None and e.get("id"):
            fichier = next((p for p in dossier.glob(f"{e['id']}.*") if p.suffix not in (".part", ".json")), None)
        if fichier is not None and fichier.suffix.lower() not in (".jpg", ".jpeg", ".png", ".webp", ".heic"):
            sortie.append(("video", fichier))
            continue
        vignettes = [t for t in (e.get("thumbnails") or []) if t.get("url")]
        if not vignettes and e.get("thumbnail"):
            vignettes = [{"url": e["thumbnail"]}]
        if vignettes:
            meilleure = max(vignettes, key=lambda t: ((t.get("width") or 0) * (t.get("height") or 0),
                                                      t.get("preference") or 0))
            try:
                sortie.append(("image", telecharger(meilleure["url"], dossier / f"image_{i:02d}.jpg", 40_000_000)))
            except Exception as ex:  # noqa: BLE001
                log(f"   image {i + 1} introuvable : {ex}")
    return sortie


# ════════════════════════════ thème ════════════════════════════

_VIDES = set("""le la les un une des de du d l et ou mais donc or ni car que qui quoi dont ce cet cette ces mon ma mes
ton ta tes son sa ses notre nos votre vos leur leurs je tu il elle on nous vous ils elles me te se y en ne pas plus
est sont etre avoir a ai as ont fait faire tout tous toute toutes pour par sur dans avec sans sous entre vers chez
the a an and or but of to in on at for with without from by is are was were be been being it its this that these
those you your yours he she they them we our us i me my mine his her their not no do does did have has had will
would can could should just so if as than then there here when what who how why all any some""".split())


def _mots(t: str) -> list[str]:
    t = unicodedata.normalize("NFKD", (t or "").lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return [m for m in re.findall(r"[a-z0-9]+", t) if len(m) > 2 and m not in _VIDES]


def deviner_theme(cfg: dict, texte: str, auteur: str = "") -> str | None:
    """Thème le plus probable : mots-clés du thème (et son nom) + ressemblance avec ses captions existantes."""
    from . import bibliotheque
    themes = bibliotheque.themes(cfg)
    if not themes:
        return None
    mots = _mots(f"{texte} {auteur}")
    if not mots:
        return None
    phrase = " " + " ".join(mots) + " "
    toutes = captions.tout()
    vocab = {t: Counter(m for it in toutes.get(t, []) for m in set(_mots(it.get("texte", "")))) for t in themes}
    nb = len(themes)
    scores = {}
    for t in themes:
        mc = [*((cfg.get("themes") or {}).get(t, {}).get("mots_cles", []) or []), t]
        s = 0.0
        for k in mc:
            k = " ".join(_mots(str(k)))
            if k:
                s += 3.0 * phrase.count(" " + k)          # début de mot : « motiv » trouve « motivation »
        for m in set(mots):
            if vocab[t].get(m):
                df = sum(1 for x in themes if vocab[x].get(m))
                s += math.log(1 + nb / df) * min(2, vocab[t][m]) / 2
        scores[t] = s / math.sqrt(len(set(mots)) / 6 + 1)
    classement = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    meilleur, s1 = classement[0]
    s2 = classement[1][1] if len(classement) > 1 else 0.0
    if s1 >= 1.2 and s1 >= 1.3 * s2:
        return meilleur
    return None


# ════════════════════════════ file d'attente ════════════════════════════

def lire_file() -> list[dict]:
    return stockage.lire(FILE, [])


def modifier_file(fonction) -> None:
    stockage.modifier(FILE, [], fonction)


def etat_visuels() -> dict[str, str]:
    """{clé visuel: statut} pour les badges de l'extension."""
    out = {}
    for j in lire_file():
        st = j.get("statut", "")
        if j.get("cle"):
            out[j["cle"]] = st
        for u in (j.get("image_url"), j.get("video_url")):
            if u:
                out["url:" + u] = st           # clé utilisée par l'extension pour les images sans post
    return out


def ajouter(elements: list[dict], theme: str, page_url: str = "", force: bool = False) -> dict:
    """Ajoute des visuels à extraire. Chaque élément : post_url, image_url, video_url, image_b64, video (bool).

    Un visuel déjà extrait (ou en cours) n'est pas repris ; un visuel en échec est relancé.
    `force` relit un visuel déjà pris (demandé explicitement par l'utilisateur dans l'extension).
    """
    ENTREES.mkdir(parents=True, exist_ok=True)
    ajoutes, doublons = 0, 0
    nouveaux = []
    for el in elements[:500]:
        post = str(el.get("post_url") or "")[:2000]
        img = str(el.get("image_url") or "")[:4000]
        vid = str(el.get("video_url") or "")[:4000]
        brut = None
        if el.get("image_b64"):
            try:
                b64 = str(el["image_b64"])
                brut = base64.b64decode(b64.split(",", 1)[1] if b64.startswith("data:") else b64)
            except Exception:  # noqa: BLE001
                brut = None
        if not (post or img.startswith("http") or vid.startswith("http") or brut):
            continue
        k = cle(post, img if not img.startswith("data:") else "", brut)
        jid = uuid.uuid4().hex[:12]
        fichier = ""
        if brut:
            ext = ".png" if brut[:4] == b"\x89PNG" else ".webp" if brut[8:12] == b"WEBP" else ".jpg"
            (ENTREES / f"{jid}{ext}").write_bytes(brut)
            fichier = f"{jid}{ext}"
        nouveaux.append({"id": jid, "cle": k, "theme": theme or "", "post_url": post,
                         "image_url": "" if img.startswith("data:") else img, "video_url": vid,
                         "video": bool(el.get("video")), "image": fichier, "page_url": page_url[:2000],
                         "statut": "en_attente", "message": "", "resultats": [], "ajoute_le": maintenant()})

    def f(items):
        nonlocal ajoutes, doublons
        actifs = {} if force else {i["cle"]: i for i in items
                                   if i.get("statut") in ("en_attente", "en_cours", "ok", "doublon")}
        for n in nouveaux:
            if n["cle"] in actifs:
                doublons += 1
                if n["image"]:
                    (ENTREES / n["image"]).unlink(missing_ok=True)
                continue
            items = [i for i in items if i["cle"] != n["cle"]]   # ancien échec : on remplace
            items.append(n)
            actifs[n["cle"]] = n
            ajoutes += 1
        return items[-3000:]
    modifier_file(f)
    # les clés permettent à l'extension d'afficher le bon badge sur la bonne vignette
    return {"ajoutes": ajoutes, "doublons": doublons, "cles": [n["cle"] for n in nouveaux]}


def relancer(ids: list[str] | None = None) -> int:
    n = 0

    def f(items):
        nonlocal n
        for i in items:
            if i.get("statut") in ("erreur", "vide") and (ids is None or i["id"] in ids):
                i.update(statut="en_attente", message="")
                n += 1
        return items
    modifier_file(f)
    return n


def oublier(ids: list[str]) -> None:
    modifier_file(lambda items: [i for i in items if i["id"] not in ids])


def miniature(source: Path, nom: str) -> str:
    """Vignette 320 px pour l'onglet Captions. Renvoie le nom du fichier (dans donnees/quotes/miniatures)."""
    from PIL import Image, ImageOps
    MINIATURES.mkdir(parents=True, exist_ok=True)
    dest = MINIATURES / f"{nom}.jpg"
    try:
        with Image.open(source) as im:
            im = ImageOps.exif_transpose(im).convert("RGB")
            im.thumbnail((320, 320))
            im.save(dest, "JPEG", quality=80)
        return dest.name
    except Exception:  # noqa: BLE001
        return ""


def _traiter(cfg: dict, job: dict, log=print) -> dict:
    """Extrait les quotes d'un visuel. Renvoie les champs à mettre à jour dans la file."""
    travail = DOSSIER / "travail" / job["id"]
    if travail.exists():
        shutil.rmtree(travail, ignore_errors=True)
    travail.mkdir(parents=True, exist_ok=True)
    try:
        medias: list[tuple[str, Path]] = []
        notes = []
        post = job.get("post_url") or ""
        pf = plateforme(post)
        if post and (pf in ("instagram", "tiktok", "youtube") or (pf == "pinterest" and job.get("video"))):
            try:
                medias = medias_post(cfg, post, travail / "post", log)
            except Exception as e:  # noqa: BLE001
                from .telechargement import _message_clair
                msg = _message_clair(str(e))[:160]
                nav = ((cfg.get("telechargement") or {}).get("cookies_navigateur") or "").strip()
                if not nav and plateforme(post) in ("instagram", "tiktok"):
                    msg += " — ⚙️ Réglages : choisis le navigateur où tu es connecté"
                notes.append(msg)
        if not medias and job.get("video_url", "").startswith("http"):
            try:
                medias = [("video", telecharger(job["video_url"], travail / "video.mp4", referer=job.get("page_url", "")))]
            except Exception as e:  # noqa: BLE001
                notes.append(f"vidéo : {e}"[:160])
        if not medias and job.get("image"):
            p = ENTREES / job["image"]
            if p.exists():
                medias = [("image", p)]
        if not medias and job.get("image_url", "").startswith("http"):
            try:
                medias = [("image", telecharger(job["image_url"], travail / "image", 40_000_000,
                                                referer=job.get("page_url", "")))]
            except Exception as e:  # noqa: BLE001
                notes.append(f"image : {e}"[:160])
        if not medias:
            return {"statut": "erreur", "message": " · ".join(notes) or "visuel introuvable"}

        source = post or job.get("image_url") or job.get("video_url") or job.get("page_url") or ""
        resultats, vides = [], 0
        for i, (genre, fichier) in enumerate(medias):
            if genre == "video":
                q, image = lire_video(fichier, travail / f"images_{i}")
            else:
                q, image = lire_image(fichier), fichier
            if not q:
                vides += 1
                continue
            theme = job.get("theme") or ""
            if theme == AUTO:
                theme = deviner_theme(cfg, q["texte"], q["auteur"]) or A_CLASSER
            elif not theme:
                theme = A_CLASSER
            vignette = miniature(image, f"{job['id']}_{i}") if image else ""
            r = captions.ajouter_quote(theme, q["texte"], auteur=q["auteur"], source=source,
                                       page=job.get("page_url", ""), miniature=vignette,
                                       a_verifier=True if q["a_verifier"] else None,
                                       visuel=job["cle"] + (f"#{i + 1}" if len(medias) > 1 else ""))
            if not r["ajoutee"] and vignette:
                (MINIATURES / vignette).unlink(missing_ok=True)
            resultats.append({"texte": q["texte"], "theme": r["theme"], "id": r["id"], "nouvelle": r["ajoutee"],
                              "a_verifier": q["a_verifier"]})
        if not resultats and job.get("image"):
            # la vidéo n'a rien donné : on lit la photo de l'écran envoyée par l'extension
            p_ecran = ENTREES / job["image"]
            q = lire_image(p_ecran) if p_ecran.exists() else None
            if q:
                theme = job.get("theme") or ""
                if theme == AUTO:
                    theme = deviner_theme(cfg, q["texte"], q["auteur"]) or A_CLASSER
                elif not theme:
                    theme = A_CLASSER
                vignette = miniature(p_ecran, f"{job['id']}_ecran")
                r = captions.ajouter_quote(theme, q["texte"], auteur=q["auteur"], source=source,
                                           page=job.get("page_url", ""), miniature=vignette,
                                           a_verifier=True, visuel=job["cle"])
                if not r["ajoutee"] and vignette:
                    (MINIATURES / vignette).unlink(missing_ok=True)
                resultats.append({"texte": q["texte"], "theme": r["theme"], "id": r["id"],
                                  "nouvelle": r["ajoutee"], "a_verifier": True})
                vides = max(0, vides - 1)
                notes.append("lu sur l'image affichée")

        nouvelles = sum(1 for r in resultats if r["nouvelle"])
        if nouvelles:
            statut = "ok"
        elif resultats:
            statut = "doublon"
        else:
            statut = "vide"
        morceaux = []
        if len(medias) > 1:
            morceaux.append(f"{len(medias)} visuels")
        if nouvelles:
            morceaux.append(f"{nouvelles} quote(s) ajoutée(s)")
        if len(resultats) - nouvelles:
            morceaux.append(f"{len(resultats) - nouvelles} déjà présente(s)")
        if vides:
            morceaux.append(f"{vides} sans texte lisible")
        return {"statut": statut, "message": " · ".join(morceaux + notes), "resultats": resultats}
    finally:
        shutil.rmtree(travail, ignore_errors=True)


def traiter_file(cfg_charger, log=print) -> int:
    """Traite tous les visuels en attente (un seul traitement à la fois)."""
    if not _travail.acquire(blocking=False):
        return 0
    _etat["en_cours"] = True
    n = 0
    try:
        # visuels restés « en cours » après un arrêt brutal
        modifier_file(lambda items: [{**i, "statut": "en_attente"} if i.get("statut") == "en_cours" else i
                                     for i in items])
        while True:
            job = next((i for i in lire_file() if i.get("statut") == "en_attente"), None)
            if job is None:
                break
            _etat["job"] = job["id"]
            modifier_file(lambda items, j=job["id"]: [{**i, "statut": "en_cours"} if i["id"] == j else i
                                                       for i in items])
            try:
                maj = _traiter(cfg_charger(), job, log)
            except Exception as e:  # noqa: BLE001
                maj = {"statut": "erreur", "message": str(e)[:300]}
            maj["traite_le"] = maintenant()
            if maj["statut"] in ("ok", "doublon") and job.get("image"):
                (ENTREES / job["image"]).unlink(missing_ok=True)     # gardée seulement pour réessayer un échec
            log(f"💬 {job.get('post_url') or job.get('image_url') or job['id']} → {maj['statut']} {maj.get('message', '')}")
            modifier_file(lambda items, j=job["id"], m=maj: [{**i, **m} if i["id"] == j else i for i in items])
            n += 1
            if job.get("post_url") and plateforme(job["post_url"]) == "instagram":
                time.sleep(1.5)                  # Instagram limite les rafales
        return n
    finally:
        _etat.update(en_cours=False, job="")
        _travail.release()


def lancer_en_fond(cfg_charger, log=print) -> bool:
    if _etat["en_cours"]:
        return False
    threading.Thread(target=traiter_file, args=(cfg_charger, log), daemon=True).start()
    return True


def en_cours() -> bool:
    return bool(_etat["en_cours"])
