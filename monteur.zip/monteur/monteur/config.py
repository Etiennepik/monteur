"""Chargement / sauvegarde de la configuration et chemins du projet."""
from __future__ import annotations

import copy
from pathlib import Path

import yaml

RACINE = Path(__file__).resolve().parent.parent
FICHIER_CONFIG = RACINE / "config" / "config.yaml"
FICHIER_DEFAUT = RACINE / "config" / "config.defaut.yaml"
DOSSIER_DONNEES = RACINE / "donnees"

STYLE_DEFAUT = {
    "police": "Poppins-Bold.ttf",
    "taille": 64,
    "couleur": "#FFFFFF",
    "contour_couleur": "#000000",
    "contour_epaisseur": 6,
    "fond_couleur": "#000000",
    "fond_opacite": 0.0,
    "fond_marge": 24,
    "ombre": True,
    "position_x": 50,
    "position_y": 20,
    "largeur_max": 86,
    "alignement": "centre",
    "majuscules": False,
    "casse": "minuscules",
    "interligne": 1.15,
    "debut_s": 0,
    "fin_s": 0,
}

DEFAUTS = {
    "dossiers": {"bibliotheque": "bibliotheque", "centre_controle": "centre_de_controle", "polices": "polices",
                 "audios": "audios"},
    "telechargement": {"cookies_navigateur": "", "duree_max_s": 600},
    "export": {"largeur": 1080, "hauteur": 1920, "qualite_crf": 20, "fps_max": 30, "duree_max_s": 0},
    "comptes": [],
    "pages_quotes": [],
    "themes": {},
    "phrases_drive": {"mode": "dossier", "dossier": "", "google_sheet_url": ""},
    "partage": {"dossier": "", "videos": True, "captions": True},
    "maj": {"url": "", "auto": True},
    "styles": {"classique": dict(STYLE_DEFAUT)},
}


def charger(chemin_cfg: Path = FICHIER_CONFIG) -> dict:
    # Au tout premier lancement (ou après une réinstallation), on part du modèle livré
    # sans jamais écraser la configuration existante de l'utilisateur.
    if not chemin_cfg.exists() and FICHIER_DEFAUT.exists():
        chemin_cfg.parent.mkdir(parents=True, exist_ok=True)
        chemin_cfg.write_bytes(FICHIER_DEFAUT.read_bytes())
    try:
        with open(chemin_cfg, encoding="utf-8") as f:
            brut = yaml.safe_load(f) or {}
    except FileNotFoundError:
        brut = {}
    cfg = copy.deepcopy(DEFAUTS)
    for k, v in brut.items():
        if isinstance(v, dict) and isinstance(cfg.get(k), dict) and k not in ("themes", "styles"):
            cfg[k].update(v)
        elif v is not None:
            cfg[k] = v
    cfg["themes"] = {str(n): {"mots_cles": list((t or {}).get("mots_cles", [])),
                              "onglets": [str(o) for o in (t or {}).get("onglets", [])]}
                     for n, t in (cfg["themes"] or {}).items()}
    cfg["styles"] = {n: {**STYLE_DEFAUT, **(s or {})} for n, s in (cfg["styles"] or {}).items()} or \
        {"classique": dict(STYLE_DEFAUT)}
    # adresse de publication : une installation plus ancienne la récupère du modèle livré
    if not str((cfg.get("maj") or {}).get("url") or "").strip() and FICHIER_DEFAUT.exists():
        try:
            with open(FICHIER_DEFAUT, encoding="utf-8") as f:
                cfg["maj"]["url"] = ((yaml.safe_load(f) or {}).get("maj") or {}).get("url", "")
        except OSError:
            pass
    cfg["comptes"] = [c for c in (cfg["comptes"] or []) if isinstance(c, dict) and c.get("url")]
    cfg["pages_quotes"] = [c for c in (cfg.get("pages_quotes") or []) if isinstance(c, dict) and c.get("url")]
    return cfg


def sauver(cfg: dict, chemin_cfg: Path = FICHIER_CONFIG) -> None:
    chemin_cfg.parent.mkdir(parents=True, exist_ok=True)
    tmp = chemin_cfg.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        yaml.safe_dump(cfg, f, allow_unicode=True, sort_keys=False, width=120)
    tmp.replace(chemin_cfg)


def chemin(cfg: dict, cle: str) -> Path:
    """Dossier de la config (relatif à la racine du projet ou absolu, ~ accepté).

    Si un dossier partagé est réglé, la bibliothèque et le centre de contrôle y sont pris :
    tout le monde travaille alors sur les mêmes vidéos.
    """
    p = cfg.get("partage") or {}
    sous = {"bibliotheque": "bibliotheque", "centre_controle": "centre_de_controle",
            "audios": "audios"}.get(cle)
    if sous and str(p.get("dossier") or "").strip():
        d = resoudre(str(p["dossier"]).strip())
        if d.is_dir():
            return d / sous
    return resoudre(cfg["dossiers"][cle])


def resoudre(p: str) -> Path:
    q = Path(str(p or "")).expanduser()
    return q if q.is_absolute() else RACINE / q
