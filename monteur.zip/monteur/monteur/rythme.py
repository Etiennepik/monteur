"""Repérer le rythme d'un audio pour y caler des changements de plan.

Tout se fait sur l'ordinateur, sans rien installer de plus : ffmpeg décode le son, numpy (déjà livré
avec Streamlit) calcule l'énergie qui apparaît d'un instant à l'autre — le « flux spectral ». Les
pics de ce flux sont les attaques (grosse caisse, caisse claire, accord) ; leur espacement le plus
régulier donne le tempo.

`analyser(fichier)` renvoie {"bpm", "temps", "accents", "duree"} :
  • `temps`   : la grille régulière du morceau (le « un deux trois quatre »), recalée sur les attaques ;
  • `accents` : les attaques réellement détectées, utiles pour un montage moins mécanique.
"""
from __future__ import annotations

import subprocess
from pathlib import Path

SR = 22050
FENETRE = 1024
SAUT = 256                      # ≈ 11,6 ms de résolution


def _ffmpeg() -> str:
    from .quotes import _ffmpeg as f
    return f()


def pcm(fichier: Path, sr: int = SR):
    """Décode l'audio en un signal mono (numpy float32 entre -1 et 1)."""
    import numpy as np
    r = subprocess.run([_ffmpeg(), "-v", "error", "-i", str(fichier), "-f", "f32le", "-acodec",
                        "pcm_f32le", "-ac", "1", "-ar", str(sr), "-"],
                       capture_output=True)
    if r.returncode != 0 or not r.stdout:
        return np.zeros(0, dtype="float32")
    return np.frombuffer(r.stdout, dtype="float32")


def _flux(x, sr: int = SR):
    """Énergie nouvelle d'une fenêtre à l'autre : c'est là que se trouvent les attaques."""
    import numpy as np
    if x.size < FENETRE * 4:
        return np.zeros(0), 0.0
    n = 1 + (x.size - FENETRE) // SAUT
    fen = np.hanning(FENETRE).astype("float32")
    trames = np.lib.stride_tricks.as_strided(
        x, shape=(n, FENETRE), strides=(x.strides[0] * SAUT, x.strides[0])) * fen
    spectre = np.abs(np.fft.rfft(trames, axis=1))
    spectre = np.log1p(spectre * 8.0)                     # l'oreille entend en logarithme
    diff = np.diff(spectre, axis=0)
    env = np.maximum(diff, 0).sum(axis=1)
    if env.max() > 0:
        env = env / env.max()
    # on retire la tendance lente : un morceau qui monte en intensité ne doit pas tout masquer
    k = 31
    fond = np.convolve(env, np.ones(k) / k, mode="same")
    env = np.maximum(env - fond, 0)
    return env, sr / SAUT


def _pics(env, ips: float, ecart_mini: float = 0.11) -> list[float]:
    """Instants des attaques : maxima locaux au-dessus du bruit ambiant."""
    import numpy as np
    if env.size == 0:
        return []
    k = max(3, int(0.35 * ips) | 1)
    seuil = np.convolve(env, np.ones(k) / k, mode="same") + 0.55 * env[env > 0].std() if env.any() else env
    saut_min = max(1, int(ecart_mini * ips))
    pics = []
    dernier = -saut_min
    for i in range(1, env.size - 1):
        if env[i] >= env[i - 1] and env[i] > env[i + 1] and env[i] > seuil[i] and i - dernier >= saut_min:
            pics.append(i / ips)
            dernier = i
    return pics


def _tempo(env, ips: float) -> float:
    """Tempo le plus probable, par auto-corrélation de l'enveloppe (60 à 190 battements/minute)."""
    import numpy as np
    if env.size < int(4 * ips):
        return 0.0
    e = env - env.mean()
    ac = np.correlate(e, e, mode="full")[e.size - 1:]
    lag_min, lag_max = int(60 / 190 * ips), int(60 / 60 * ips)
    if lag_max >= ac.size:
        lag_max = ac.size - 1
    if lag_max <= lag_min:
        return 0.0
    zone = ac[lag_min:lag_max]
    lag = int(np.argmax(zone)) + lag_min
    if lag <= 0:
        return 0.0
    bpm = 60.0 * ips / lag
    while bpm < 70:                      # un tempo trouvé à la moitié reste un tempo
        bpm *= 2
    while bpm > 180:
        bpm /= 2
    return round(bpm, 1)


def _grille(duree: float, bpm: float, accents: list[float]) -> list[float]:
    """Grille régulière au tempo trouvé, décalée pour tomber sur les attaques."""
    if bpm <= 0:
        return []
    import numpy as np
    periode = 60.0 / bpm
    meilleur = 0.0
    if accents:
        # moyenne circulaire des attaques dans la mesure : donne la phase au centième de seconde,
        # là où un balayage grossier se calait parfois sur un contretemps
        angles = 2 * np.pi * (np.array(accents) % periode) / periode
        meilleur = float((np.angle(np.mean(np.exp(1j * angles))) % (2 * np.pi)) * periode / (2 * np.pi))
        if meilleur > periode / 2:       # on préfère démarrer juste avant la première attaque
            meilleur -= periode
        meilleur = max(0.0, meilleur)
    t, out = meilleur, []
    while t < duree - 0.02:
        out.append(round(t, 3))
        t += periode
    return out


def analyser(fichier: Path) -> dict:
    """Tempo, grille des temps et attaques d'un fichier audio."""
    x = pcm(Path(fichier))
    if x.size == 0:
        return {"bpm": 0.0, "temps": [], "accents": [], "duree": 0.0}
    duree = x.size / SR
    env, ips = _flux(x)
    accents = _pics(env, ips) if ips else []
    bpm = _tempo(env, ips) if ips else 0.0
    return {"bpm": bpm, "temps": _grille(duree, bpm, accents), "accents": accents,
            "duree": round(duree, 3)}


def _zone_de(t: float, zones: list) -> list | None:
    """La zone sans coupe qui contient cet instant, s'il y en a une."""
    for z in zones:
        if z[0] <= t <= z[1]:
            return z
    return None


def coupes(duree: float, rep: dict, pas: int = 2, mini: float = 0.6, maxi: float = 4.0,
           sur_accents: bool = False, zones: list | None = None) -> list[float]:
    """Instants des changements de plan, de 0 à `duree`.

    `pas` : un plan tous les N temps. `sur_accents` : suivre les attaques plutôt que la grille.
    `mini` / `maxi` encadrent la durée d'un plan — sans tempo trouvé, on coupe régulièrement.
    `zones` : passages [début, fin] à ne pas couper. Même la coupe forcée des plans trop longs les
    respecte : elle est posée juste avant la zone, et si c'est impossible le plan la traverse.
    """
    zones = [list(z) for z in (zones or [])]
    base = list(rep.get("accents") or []) if sur_accents else list(rep.get("temps") or [])
    if not sur_accents and base:
        base = base[:: max(1, int(pas))]
    bornes = [0.0]

    def forcer(limite: float) -> None:
        """Découpe les plans qui dépassent `maxi` avant d'arriver à `limite`."""
        while limite - bornes[-1] > maxi:
            t = bornes[-1] + maxi
            z = _zone_de(t, zones)
            if z:
                t = z[0]                                 # on coupe juste avant d'entrer dans la zone
                if t - bornes[-1] < mini:                # trop tôt : le plan traverse la zone
                    t = z[1]
            if t >= limite or t - bornes[-1] < mini or t >= duree - mini / 2:
                return
            bornes.append(round(t, 3))

    for t in base:
        if t <= bornes[-1] + mini or t >= duree - mini / 2 or _zone_de(t, zones):
            continue
        forcer(t)
        if t - bornes[-1] >= mini:
            bornes.append(round(t, 3))
    forcer(duree)
    if duree - bornes[-1] < mini and len(bornes) > 1:    # dernier plan trop court : on le fond
        bornes.pop()
    bornes.append(round(duree, 3))
    return bornes
