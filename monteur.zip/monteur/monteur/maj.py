"""Vérification de version : Monteur prévient quand une nouvelle version existe.

Le dépôt publie un petit fichier `version.json` :

    {"version": "2.9.0", "zip": "https://…/monteur.zip", "notes": "Ce qui change"}

L'adresse de ce fichier est dans les réglages (`maj.url`). Rien n'est installé automatiquement :
Monteur affiche un bandeau, et la mise à jour se fait en double-cliquant sur Mettre-a-jour.command.
"""
from __future__ import annotations

import json
import threading
import time
import urllib.request

from . import stockage
from .config import DOSSIER_DONNEES, RACINE

VERSION_LOCALE = RACINE / "VERSION"
CACHE = DOSSIER_DONNEES / "derniere_version.json"
_verrou = threading.Lock()
_lance = False


def version_installee() -> str:
    try:
        return VERSION_LOCALE.read_text(encoding="utf-8").strip() or "0"
    except OSError:
        return "0"


def _nombres(v: str) -> tuple:
    return tuple(int(x) for x in (v or "0").replace("v", "").split(".") if x.isdigit())


def plus_recente(distante: str, locale: str) -> bool:
    try:
        return _nombres(distante) > _nombres(locale)
    except Exception:  # noqa: BLE001
        return False


def lire_cache() -> dict:
    return stockage.lire(CACHE, {})


def verifier(url: str, timeout: int = 8) -> dict:
    """Lit le version.json distant. Renvoie {version, zip, notes, le} ou {erreur}."""
    url = (url or "").strip()
    if not url:
        return {}
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Monteur", "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            d = json.loads(r.read(200_000).decode("utf-8"))
        res = {"version": str(d.get("version") or ""), "zip": str(d.get("zip") or ""),
               "notes": str(d.get("notes") or ""), "le": time.strftime("%Y-%m-%dT%H:%M:%S")}
    except Exception as e:  # noqa: BLE001
        res = {"erreur": str(e)[:200], "le": time.strftime("%Y-%m-%dT%H:%M:%S")}
    stockage.ecrire(CACHE, res)
    return res


def verifier_en_fond(cfg: dict) -> bool:
    """Une seule vérification par lancement, sans ralentir l'ouverture de Monteur."""
    global _lance
    m = cfg.get("maj") or {}
    if not (m.get("url") and m.get("auto", True)):
        return False
    with _verrou:
        if _lance:
            return False
        _lance = True
    threading.Thread(target=verifier, args=(m["url"],), daemon=True).start()
    return True


def nouveaute(cfg: dict) -> dict | None:
    """La version distante connue, si elle est plus récente que celle installée."""
    d = lire_cache()
    if d.get("version") and plus_recente(d["version"], version_installee()):
        return d
    return None
