"""Lecture des listes de phrases depuis un dossier Drive synchronisé ou un Google Sheet."""
from __future__ import annotations

import csv
import io
import re
import urllib.parse
import urllib.request
from pathlib import Path

from .config import DOSSIER_DONNEES, resoudre

CACHE = DOSSIER_DONNEES / "cache_phrases"
EXTENSIONS = {".txt", ".csv", ".tsv", ".md"}


def _nettoyer(lignes) -> list[str]:
    vues, out = set(), []
    for l in lignes:
        l = (l or "").strip()
        if len(l) > 1 and l[0] == l[-1] == '"':
            l = l[1:-1].strip()
        if not l or l.startswith("#") or l in vues:
            continue
        vues.add(l)
        out.append(l)
    return out


def _lire_fichier(p: Path) -> list[str]:
    texte = p.read_text(encoding="utf-8-sig", errors="replace")
    if p.suffix.lower() in {".csv", ".tsv"}:
        delim = "\t" if p.suffix.lower() == ".tsv" else ","
        return _nettoyer(r[0] for r in csv.reader(io.StringIO(texte), delimiter=delim) if r)
    return _nettoyer(texte.splitlines())


def _id_sheet(url: str) -> str | None:
    m = re.search(r"/spreadsheets/d/([a-zA-Z0-9_-]+)", url or "")
    return m.group(1) if m else None


def _lire_onglet(sheet_id: str, onglet: str) -> list[str]:
    url = (f"https://docs.google.com/spreadsheets/d/{sheet_id}/gviz/tq?tqx=out:csv&headers=0&sheet="
           + urllib.parse.quote(onglet))
    with urllib.request.urlopen(url, timeout=30) as r:
        texte = r.read().decode("utf-8")
    return _nettoyer(row[0] for row in csv.reader(io.StringIO(texte)) if row)


def listes_disponibles(cfg: dict, noms_utiles: list[str] | None = None) -> dict[str, list[str]]:
    """Renvoie {nom_liste: [phrases]}.

    Mode dossier : chaque fichier = une liste (nom du fichier sans extension).
    Mode google_sheet : chaque onglet demandé (noms_utiles) = une liste. En cas d'échec
    réseau, on se rabat sur la dernière copie en cache.
    """
    p = cfg.get("phrases", {})
    listes: dict[str, list[str]] = {}
    if p.get("mode") == "google_sheet":
        sid = _id_sheet(p.get("google_sheet_url", ""))
        if not sid:
            raise ValueError("Lien Google Sheet invalide dans la config (phrases.google_sheet_url).")
        CACHE.mkdir(parents=True, exist_ok=True)
        for nom in noms_utiles or []:
            cache = CACHE / f"{nom}.txt"
            try:
                listes[nom] = _lire_onglet(sid, nom)
                cache.write_text("\n".join(listes[nom]), encoding="utf-8")
            except Exception:
                if cache.exists():
                    listes[nom] = _lire_fichier(cache)
    else:
        dossier = resoudre(p.get("dossier") or "")
        if dossier.is_dir():
            for f in sorted(dossier.iterdir()):
                if f.suffix.lower() in EXTENSIONS and not f.name.startswith("."):
                    listes[f.stem] = _lire_fichier(f)
    return listes
