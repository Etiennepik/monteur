"""Détection automatique d'un logo / tag incrusté (élément fixe et contrasté qui ne bouge pas pendant la vidéo)."""
from __future__ import annotations

import subprocess
from collections import deque
from pathlib import Path

import numpy as np
from PIL import Image, ImageFilter

LARGEUR_ANALYSE = 320


def _images(video: Path, duree: float, n: int = 12) -> np.ndarray | None:
    imgs = []
    h = None
    for k in range(n):
        t = duree * (0.04 + 0.92 * k / max(1, n - 1)) if duree > 0 else k * 0.5
        r = subprocess.run(["ffmpeg", "-loglevel", "error", "-ss", f"{t:.2f}", "-i", str(video), "-frames:v", "1",
                            "-vf", f"scale={LARGEUR_ANALYSE}:-2,format=gray", "-f", "rawvideo", "-"],
                           capture_output=True)
        if not r.stdout:
            continue
        hh = len(r.stdout) // LARGEUR_ANALYSE
        if h is None:
            h = hh
        if hh == h:
            imgs.append(np.frombuffer(r.stdout[: h * LARGEUR_ANALYSE], np.uint8).reshape(h, LARGEUR_ANALYSE))
    return np.stack(imgs).astype(np.float32) if len(imgs) >= 6 else None


def _composantes(masque: np.ndarray) -> list[tuple[int, int, int, int, list]]:
    """Composantes connexes (4-voisinage) → [(x0, y0, x1, y1, pixels)]."""
    h, w = masque.shape
    vu = np.zeros_like(masque, dtype=bool)
    out = []
    ys, xs = np.nonzero(masque)
    for y, x in zip(ys, xs):
        if vu[y, x]:
            continue
        q = deque([(y, x)])
        vu[y, x] = True
        pix = []
        while q:
            cy, cx = q.popleft()
            pix.append((cy, cx))
            for ny, nx in ((cy + 1, cx), (cy - 1, cx), (cy, cx + 1), (cy, cx - 1)):
                if 0 <= ny < h and 0 <= nx < w and masque[ny, nx] and not vu[ny, nx]:
                    vu[ny, nx] = True
                    q.append((ny, nx))
        py = [p[0] for p in pix]
        px = [p[1] for p in pix]
        out.append((min(px), min(py), max(px) + 1, max(py) + 1, pix))
    return out


def detecter(video: Path, duree: float) -> dict:
    """Renvoie {"trouve": bool, "zones": [{x, y, largeur, hauteur} en %], "message": str}."""
    F = _images(video, duree)
    if F is None:
        return {"trouve": False, "zones": [], "message": "Vidéo trop courte ou illisible pour l'analyse."}
    n, h, w = F.shape
    gx = np.abs(np.diff(F, axis=2, prepend=F[:, :, :1]))
    gy = np.abs(np.diff(F, axis=1, prepend=F[:, :1, :]))
    bords = gx + gy
    bords_min = np.percentile(bords, 25, axis=0)      # contour présent sur (presque) toutes les images
    ecart = F.std(axis=0)                             # pixel qui ne change pas

    fixe = ecart < 6
    if fixe.mean() > 0.6:
        return {"trouve": False, "zones": [], "message": "Vidéo trop statique pour repérer un logo automatiquement : "
                                            "règle la zone à la main."}

    masque = (bords_min > 22) & (ecart < 14)
    # on ignore le centre de l'image (le sujet), les logos sont sur les côtés / en haut / en bas
    masque[int(h * 0.30):int(h * 0.70), int(w * 0.22):int(w * 0.78)] = False
    if masque.sum() < 12:
        return {"trouve": False, "zones": [], "message": "Aucun logo fixe détecté."}

    dilate = np.array(Image.fromarray((masque * 255).astype(np.uint8)).filter(ImageFilter.MaxFilter(9))) > 0
    candidats = []
    for x0, y0, x1, y1, _pix in _composantes(dilate):
        aire = (x1 - x0) * (y1 - y0) / (w * h)
        score = int(masque[y0:y1, x0:x1].sum())
        if 0.0008 <= aire <= 0.12 and score >= 12:
            candidats.append((score, x0, y0, x1, y1))
    if not candidats:
        return {"trouve": False, "zones": [], "message": "Aucun logo fixe détecté."}
    candidats.sort(reverse=True)
    garde = [c for c in candidats if c[0] >= 0.25 * candidats[0][0]][:3]
    zones = []
    for _score, x0, y0, x1, y1 in garde:
        mx, my = 0.012 * w, 0.010 * h
        x0, y0 = max(0.0, x0 - mx), max(0.0, y0 - my)
        x1, y1 = min(float(w), x1 + mx), min(float(h), y1 + my)
        zones.append({"x": round(100 * x0 / w, 1), "y": round(100 * y0 / h, 1),
                      "largeur": round(100 * (x1 - x0) / w, 1), "hauteur": round(100 * (y1 - y0) / h, 1)})
    zones = [{k: float(v) for k, v in z.items()} for z in zones]
    return {"trouve": True, "zones": zones,
            "message": f"{len(zones)} élément(s) fixe(s) détecté(s) — vérifie les rectangles sur l'aperçu."}
