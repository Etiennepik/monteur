"""File d'attente des posts sélectionnés (extension Chrome) et téléchargement vers la bibliothèque."""
from __future__ import annotations

import datetime as dt
import re
import threading
import time
from pathlib import Path

from . import bibliotheque, stockage
from .config import DOSSIER_DONNEES, chemin

ARCHIVE = DOSSIER_DONNEES / "deja_telecharges.txt"
COOKIES = DOSSIER_DONNEES / "cookies.txt"
FILE_ATTENTE = DOSSIER_DONNEES / "file_attente.json"
AUTO = "auto"            # thème « classer automatiquement »
_en_cours = threading.Lock()
_etat_courant = {"debut": 0.0, "fait": 0, "total": 0, "url": ""}


def slug(s: str) -> str:
    s = re.sub(r"[^\w\-]+", "_", str(s).strip().lower(), flags=re.UNICODE)
    return s.strip("_") or "x"


def plateforme(url: str) -> str:
    u = (url or "").lower()
    if "instagram" in u:
        return "instagram"
    if "tiktok" in u:
        return "tiktok"
    if "youtu" in u:
        return "youtube"
    return "autre"


def cle_post(url: str) -> str | None:
    """Identifiant stable d'un post, quelle que soit la forme de l'URL (p/ vs reel/, paramètres…)."""
    u = url or ""
    m = re.search(r"instagram\.com/(?:[\w.]+/)?(?:p|reels?|tv)/([\w-]+)", u)
    if m:
        return f"ig:{m.group(1)}"
    m = re.search(r"tiktok\.com/.*?/(?:video|photo)/(\d+)", u)
    if m:
        return f"tt:{m.group(1)}"
    m = re.search(r"youtube\.com/shorts/([\w-]+)", u) or re.search(r"[?&]v=([\w-]+)", u) or \
        re.search(r"youtu\.be/([\w-]+)", u)
    if m:
        return f"yt:{m.group(1)}"
    return None


def normaliser_url(u: str) -> str:
    u = (u or "").strip().split("#")[0]
    if not u.startswith("http"):
        return ""
    if "instagram.com" in u or "tiktok.com" in u:
        u = u.split("?")[0]
    return u


# ───────────── file d'attente ─────────────

def lire_file() -> list[dict]:
    return stockage.lire(FILE_ATTENTE, [])


def modifier_file(fonction) -> None:
    stockage.modifier(FILE_ATTENTE, [], fonction)


def ajouter_a_la_file(urls: list[str], theme: str, compte: str = "", force: bool = False) -> int:
    """Ajoute des posts à la file (doublons ignorés). theme = nom de thème, "auto" ou "" (à classer).

    `force` retélécharge un post déjà pris (demandé explicitement dans l'extension).
    """
    n = 0

    def f(items):
        nonlocal n
        if force:
            voulues = {cle_post(normaliser_url(u)) or normaliser_url(u) for u in urls}
            items = [i for i in items if (i.get("cle") or i["url"]) not in voulues]
        connues = {i.get("cle") or i["url"] for i in items}
        for u in urls:
            u = normaliser_url(u)
            cle = cle_post(u) or u
            if u and cle not in connues:
                items.append({"url": u, "cle": cle, "theme": theme or "", "compte": compte,
                              "statut": "en_attente", "ajoute_le": dt.datetime.now().isoformat(timespec="seconds")})
                connues.add(cle)
                n += 1
        return items
    modifier_file(f)
    return n


def signature() -> str:
    """Empreinte de la file : change dès qu'un post est ajouté, téléchargé ou en échec."""
    import hashlib
    try:
        return hashlib.md5(FILE_ATTENTE.read_bytes()).hexdigest()
    except OSError:
        return ""


def etat_posts(cfg: dict) -> dict[str, str]:
    """{cle_post: "en_attente" | "telecharge" | "utilisee" | "erreur"} pour marquer les posts dans l'extension."""
    out = {}
    for i in lire_file():
        out[i.get("cle") or cle_post(i["url"]) or i["url"]] = i.get("statut", "")
    for v in bibliotheque.videos(cfg):
        k = cle_post(v.get("url", ""))
        if k:
            out[k] = "utilisee" if v["utilisee"] else "telecharge"
    return out


def fichier_cookies(nav: str, log=print, forcer: bool = False) -> Path | None:
    """Extrait une fois les cookies du navigateur vers donnees/cookies.txt et réutilise ce fichier ensuite.

    macOS ne demande alors l'autorisation du trousseau qu'au premier téléchargement (et non à chaque vidéo).
    """
    import time

    import yt_dlp
    if not nav:
        return None
    frais = COOKIES.exists() and COOKIES.stat().st_size > 0 and time.time() - COOKIES.stat().st_mtime < 6 * 3600
    if frais and not forcer:
        return COOKIES
    try:
        class _Silence:
            def debug(self, *a):
                pass
            info = warning = error = debug

        pot = yt_dlp.cookies.extract_cookies_from_browser(nav, logger=_Silence())
        COOKIES.parent.mkdir(parents=True, exist_ok=True)
        pot.save(str(COOKIES), ignore_discard=True, ignore_expires=True)
        COOKIES.chmod(0o600)
        log(f"🔑 Cookies {nav} enregistrés ({sum(1 for _ in pot)} cookies) — plus de demande de trousseau ensuite.")
        return COOKIES
    except Exception as e:  # noqa: BLE001
        log(f"⚠ Lecture des cookies {nav} impossible : {str(e)[:200]}")
        return COOKIES if COOKIES.exists() else None


_ANSI = re.compile(r"\x1b?\[[0-9;]*m")


def _message_clair(e: str) -> str:
    """Traduit les erreurs yt-dlp les plus courantes."""
    e = _ANSI.sub("", e).replace("\n", " ").strip()
    b = e.lower()
    if "no video formats" in b or "no video could be found" in b:
        return "post photo : aucune vidéo à télécharger"
    if "rate-limit" in b or "login required" in b or "login_required" in b:
        return ("Instagram a refusé (limite de requêtes ou connexion) — souvent un post photo, sinon réessaie "
                "dans quelques minutes ; si tous les posts échouent, ⚙️ Réglages → « Relire les cookies »")
    if "private" in b or "not available" in b and "requested content" in b:
        return "post privé ou supprimé"
    if "age" in b and "restricted" in b:
        return "contenu limité par l'âge"
    if "unsupported url" in b:
        return "lien non reconnu"
    return e[:300]


def telecharger_file(cfg: dict, log=print) -> int:
    """Télécharge les posts en attente dans la bibliothèque et les range dans leur thème."""
    import yt_dlp

    if not _en_cours.acquire(blocking=False):
        log("Un téléchargement est déjà en cours.")
        return 0
    try:
        a_faire = [i for i in lire_file() if i.get("statut") == "en_attente"]
        if not a_faire:
            return 0
        _etat_courant.update(debut=time.time(), fait=0, total=len(a_faire), url="")
        log(f"▶ {len(a_faire)} post(s) à télécharger")
        dl = cfg.get("telechargement", {})
        nav = (dl.get("cookies_navigateur") or "").strip()
        cookies = fichier_cookies(nav, log)
        a_classer = chemin(cfg, "bibliotheque") / bibliotheque.A_CLASSER
        a_classer.mkdir(parents=True, exist_ok=True)
        n = 0
        for item in a_faire:
            _etat_courant["url"] = item["url"]
            fichiers: list[Path] = []

            def post(d):
                if d.get("status") == "finished" and d.get("info_dict", {}).get("filepath"):
                    fichiers.append(Path(d["info_dict"]["filepath"]))

            opts = {
                "outtmpl": str(a_classer / "%(extractor_key)s_%(id)s.%(ext)s"),
                "format": "bv*[ext=mp4][height<=1920]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b",
                "merge_output_format": "mp4",
                "noplaylist": True,
                "writeinfojson": True,
                "quiet": True,
                "no_warnings": True,
                "noprogress": True,
                "postprocessor_hooks": [post],
                "sleep_interval": 2,          # espace les requêtes : Instagram limite les rafales
                "max_sleep_interval": 5,
                "retries": 3,
            }
            if cookies:
                opts["cookiefile"] = str(cookies)
            statut, msg, rangee = "telecharge", "", ""
            try:
                with yt_dlp.YoutubeDL(opts) as ydl:
                    info = ydl.extract_info(item["url"], download=True)
                    if info and not fichiers:
                        p = Path(ydl.prepare_filename(info)).with_suffix(".mp4")
                        if p.exists():
                            fichiers.append(p)
                if not fichiers:
                    statut, msg = "erreur", "aucune vidéo dans ce post (photo ?)"
            except Exception as e:  # noqa: BLE001
                statut, msg = "erreur", _message_clair(str(e))

            for f in {p for p in fichiers if p.exists()}:
                theme = item.get("theme") or ""
                if theme == AUTO:
                    theme = bibliotheque.deviner_theme(cfg, f) or ""
                if theme and theme != bibliotheque.A_CLASSER:
                    f = bibliotheque.deplacer(cfg, f.name, theme) or f
                rangee = theme or bibliotheque.A_CLASSER
                bibliotheque.noter_ajout(f.name)
                bibliotheque.miniature(f)
            log(f"   {'↓' if statut == 'telecharge' else '✖'} {item['url']}"
                f"{' → ' + bibliotheque.nom_affiche(rangee) if rangee else ''} {msg}")
            n += statut == "telecharge"
            _etat_courant["fait"] += 1

            if len(a_faire) > 1:
                time.sleep(2.5)

            def maj(items, cle=item.get("cle"), st=statut, m=msg, r=rangee):
                for i in items:
                    if i.get("cle") == cle:
                        i.update(statut=st, message=m, range_dans=r,
                                 traite_le=dt.datetime.now().isoformat(timespec="seconds"))
                return items
            modifier_file(maj)
        if n < len(a_faire) and not nav:
            log("💡 Aucun navigateur choisi : Instagram et TikTok refusent presque tout sans connexion. "
                "Va dans ⚙️ Réglages → « Navigateur où tu es connecté ».")
        return n
    finally:
        _etat_courant["url"] = ""
        _en_cours.release()


def progression() -> dict:
    """{en_cours, fait, total, url, depuis_s} pour l'affichage."""
    actif = telechargement_en_cours()
    return {"en_cours": actif, **_etat_courant,
            "depuis_s": int(time.time() - _etat_courant["debut"]) if actif and _etat_courant["debut"] else 0}


def telechargement_en_cours() -> bool:
    if _en_cours.acquire(blocking=False):
        _en_cours.release()
        return False
    return True
