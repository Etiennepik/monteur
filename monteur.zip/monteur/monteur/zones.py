"""Zones sans coupe : les passages d'un extrait audio pendant lesquels le montage ne coupe pas.

Un montage calé sur le rythme change de plan à chaque temps. Parfois, ce n'est pas souhaitable :
une phrase chantée qu'on veut laisser filer, un passage parlé, une montée qu'une coupe casserait.
On cale alors ces passages avec les mêmes poignées que pour découper un extrait, on les valide, et
`rythme.coupes()` les enjambe.

Chaque zone garde une case **active** : on la décoche avant un export pour l'ignorer cette fois-ci,
sans la perdre. Les zones sont repérées **sur l'extrait d'origine**, en secondes depuis son début,
et gardées par chemin de fichier seulement : retoucher l'audio n'efface pas ce travail à la main.

Forme en mémoire : [{"id": 1, "debut": 3.0, "fin": 8.4, "active": True}, …]
"""
from __future__ import annotations

import hashlib
from pathlib import Path

from . import stockage
from .config import DOSSIER_DONNEES

DOSSIER = DOSSIER_DONNEES / "zones"
MINI = 0.2                       # en dessous, une zone ne protège rien de perceptible


def _cle(fichier: Path) -> str:
    try:
        return hashlib.md5(str(Path(fichier)).encode("utf-8", "replace")).hexdigest()[:16]
    except (OSError, TypeError):
        return ""


def _fichier_cache(fichier: Path) -> Path:
    return DOSSIER / f"{_cle(fichier)}.json"


def ranger(brutes, duree: float | None = None) -> list[dict]:
    """Met les zones au propre : bornes dans l'ordre, trop courtes jetées, numéros uniques.

    Accepte aussi bien des dictionnaires que de simples paires [début, fin].
    """
    propres: list[dict] = []
    for z in brutes or []:
        if isinstance(z, dict):
            brut, actif, zid = (z.get("debut"), z.get("fin")), z.get("active", True), z.get("id")
        else:
            try:
                brut, actif, zid = (z[0], z[1]), True, None
            except (TypeError, IndexError):
                continue
        try:
            a, b = float(brut[0]), float(brut[1])
        except (TypeError, ValueError):
            continue
        if b < a:
            a, b = b, a
        a = max(0.0, a)
        if duree:
            b = min(float(duree), b)
            a = min(a, float(duree))
        if b - a < MINI:
            continue
        propres.append({"id": int(zid) if isinstance(zid, (int, float)) else 0,
                        "debut": round(a, 2), "fin": round(b, 2), "active": bool(actif)})
    propres.sort(key=lambda z: (z["debut"], z["fin"]))
    pris = {z["id"] for z in propres if z["id"]}
    suivant = (max(pris) + 1) if pris else 1
    for z in propres:                      # une zone sans numéro en reçoit un, jamais déjà pris
        if not z["id"]:
            z["id"] = suivant
            suivant += 1
    return propres


def fondre(paires) -> list[list[float]]:
    """Fond les passages qui se chevauchent : la protection, elle, n'a pas besoin de doublons."""
    out: list[list[float]] = []
    for a, b in sorted([round(float(p[0]), 2), round(float(p[1]), 2)] for p in paires):
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def actives(liste) -> list[list[float]]:
    """Les seules zones cochées, en paires [début, fin], chevauchements fondus."""
    return fondre([[z["debut"], z["fin"]] for z in liste or [] if z.get("active", True)])


def lire(fichier: Path) -> list[dict]:
    """Les zones notées sur cet extrait, cochées ou non."""
    if not _cle(fichier):
        return []
    return ranger(stockage.lire(_fichier_cache(fichier), {}).get("zones") or [])


def ecrire(fichier: Path, liste) -> list[dict]:
    propres = ranger(liste)
    if _cle(fichier):
        stockage.ecrire(_fichier_cache(fichier), {"zones": propres})
    return propres


def ajouter(fichier: Path, debut: float, fin: float) -> list[dict]:
    """Valide un nouveau passage. Un doublon exact ne crée pas une deuxième ligne."""
    liste = lire(fichier)
    a, b = round(min(debut, fin), 2), round(max(debut, fin), 2)
    if b - a < MINI:
        return liste
    if any(abs(z["debut"] - a) < 0.01 and abs(z["fin"] - b) < 0.01 for z in liste):
        return liste
    return ecrire(fichier, liste + [{"id": 0, "debut": a, "fin": b, "active": True}])


def basculer(fichier: Path, zid: int, actif: bool) -> list[dict]:
    """Coche ou décoche une zone, sans la supprimer."""
    liste = lire(fichier)
    for z in liste:
        if z["id"] == int(zid):
            z["active"] = bool(actif)
    return ecrire(fichier, liste)


def enlever(fichier: Path, zid: int) -> list[dict]:
    return ecrire(fichier, [z for z in lire(fichier) if z["id"] != int(zid)])


def oublier(fichier: Path) -> None:
    _fichier_cache(fichier).unlink(missing_ok=True)


def pour_extrait(audio: dict | None) -> list[list[float]]:
    """Les zones cochées de l'audio choisi, ramenées au repère du fichier réellement monté.

    L'extrait peut avoir été raccourci dans Post montage (« ✂️ Raccourcir l'extrait ») : le fichier
    monté commence alors au milieu de l'extrait d'origine. On décale les zones d'autant et on jette
    ce qui tombe en dehors.
    """
    if not audio:
        return []
    source = Path(str(audio.get("source") or audio.get("chemin") or ""))
    if not source.exists():
        return []
    coupe = audio.get("coupe") or [0.0, 0.0]
    try:
        depart = max(0.0, float(coupe[0]))
        fin = float(coupe[1])
    except (TypeError, ValueError, IndexError):
        depart, fin = 0.0, 0.0
    longueur = (fin - depart) if fin > depart else None
    decalees = [{"debut": a - depart, "fin": b - depart} for a, b in actives(lire(source))]
    return actives(ranger(decalees, longueur))
