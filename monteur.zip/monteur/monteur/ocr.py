"""Lecture du texte d'une image.

Moteur principal : la reconnaissance de texte intégrée au Mac (Apple Vision) — gratuite, locale, sans clé.
Repli : tesseract s'il est installé (pratique pour les tests hors Mac).

`lire(chemin)` renvoie une liste de lignes : {"texte", "conf" (0-1), "x", "y", "w", "h"} avec des coordonnées
relatives à l'image (0-1, origine en haut à gauche).
"""
from __future__ import annotations

import contextlib
import shutil
import subprocess
import tempfile
from pathlib import Path

LANGUES_VISION = ["fr-FR", "en-US"]
_moteur: str | None = None
_erreur_vision = ""


def moteur() -> str | None:
    """« vision », « tesseract » ou None si aucun moteur n'est disponible."""
    global _moteur, _erreur_vision
    if _moteur is None:
        try:
            import Vision  # noqa: F401  (pyobjc-framework-Vision, installé par Lancer.command)
            _moteur = "vision"
        except Exception as e:  # noqa: BLE001
            _erreur_vision = str(e)[:200]
            _moteur = "tesseract" if shutil.which("tesseract") else ""
    return _moteur or None


def explication() -> str:
    m = moteur()
    if m == "vision":
        return "Reconnaissance de texte du Mac (Apple Vision)"
    if m == "tesseract":
        return "tesseract (Apple Vision indisponible)"
    return ("Aucun moteur de lecture : relance Lancer.command (il installe le module Apple Vision). "
            + (f"Détail : {_erreur_vision}" if _erreur_vision else ""))


def _preparer(chemin: Path, dossier: Path) -> tuple[Path, int, int]:
    """Convertit en PNG (webp, avif, gif… → format sûr) et agrandit les petites images (meilleure lecture)."""
    from PIL import Image, ImageOps

    with Image.open(chemin) as im:
        im = ImageOps.exif_transpose(im)
        if getattr(im, "is_animated", False):
            im.seek(0)
        if im.mode in ("RGBA", "LA", "P"):
            im = im.convert("RGBA")
            fond = Image.new("RGB", im.size, (255, 255, 255))
            fond.paste(im, mask=im.split()[-1])
            im = fond
        else:
            im = im.convert("RGB")
        w, h = im.size
        f = 1.0
        if max(w, h) < 900:
            f = min(3.0, 1200 / max(w, h))
        elif max(w, h) > 2600:
            f = 2600 / max(w, h)
        if f != 1.0:
            im = im.resize((max(1, int(w * f)), max(1, int(h * f))), Image.LANCZOS)
        sortie = dossier / "ocr.png"
        im.save(sortie)
        return sortie, im.size[0], im.size[1]


def _vision(chemin: Path) -> list[dict]:
    import objc
    import Quartz
    import Vision
    from Foundation import NSURL

    pool = getattr(objc, "autorelease_pool", None)
    with (pool() if pool else contextlib.nullcontext()):
        src = Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(chemin)), None)
        if src is None:
            raise ValueError("image illisible")
        image = Quartz.CGImageSourceCreateImageAtIndex(src, 0, None)
        if image is None:
            raise ValueError("image illisible")

        def executer(langues):
            r = Vision.VNRecognizeTextRequest.alloc().init()
            r.setRecognitionLevel_(Vision.VNRequestTextRecognitionLevelAccurate)
            r.setUsesLanguageCorrection_(True)
            if langues:
                with contextlib.suppress(Exception):
                    r.setRecognitionLanguages_(langues)
            handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(image, {})
            res = handler.performRequests_error_([r], None)
            ok, err = res if isinstance(res, tuple) else (res, None)
            return r, ok, err

        req, ok, err = executer(LANGUES_VISION)
        if not ok:                       # langue non prise en charge par cette version de macOS
            req, ok, err = executer(None)
        if not ok:
            raise RuntimeError(f"Vision : {err}")
        lignes = []
        for obs in req.results() or []:
            cands = obs.topCandidates_(1)
            if not cands:
                continue
            c = cands[0]
            bb = obs.boundingBox()           # origine en bas à gauche, coordonnées 0-1
            x, y, w, h = bb.origin.x, bb.origin.y, bb.size.width, bb.size.height
            lignes.append({"texte": str(c.string()), "conf": float(c.confidence()),
                           "x": float(x), "y": float(1 - y - h), "w": float(w), "h": float(h)})
        return lignes


def _langues_tesseract() -> str:
    try:
        sortie = subprocess.run(["tesseract", "--list-langs"], capture_output=True, text=True, timeout=20).stdout
        dispo = {l.strip() for l in sortie.splitlines()[1:]}
    except Exception:  # noqa: BLE001
        dispo = set()
    return "+".join(l for l in ("fra", "eng") if l in dispo) or "eng"


def _tesseract(chemin: Path, largeur: int, hauteur: int) -> list[dict]:
    tsv = subprocess.run(["tesseract", str(chemin), "stdout", "-l", _langues_tesseract(), "--psm", "11", "tsv"],
                         capture_output=True, text=True, timeout=120).stdout
    par_ligne: dict[tuple, list] = {}
    for l in tsv.splitlines()[1:]:
        c = l.split("\t")
        if len(c) < 12 or not c[11].strip():
            continue
        try:
            conf = float(c[10])
        except ValueError:
            continue
        if conf < 0:
            continue
        cle = (c[2], c[3], c[4])
        par_ligne.setdefault(cle, []).append((int(c[6]), int(c[7]), int(c[8]), int(c[9]), conf, c[11]))
    lignes = []
    for mots in par_ligne.values():
        x0 = min(m[0] for m in mots)
        y0 = min(m[1] for m in mots)
        x1 = max(m[0] + m[2] for m in mots)
        y1 = max(m[1] + m[3] for m in mots)
        lignes.append({"texte": " ".join(m[5] for m in sorted(mots)), "conf": sum(m[4] for m in mots) / len(mots) / 100,
                       "x": x0 / largeur, "y": y0 / hauteur, "w": (x1 - x0) / largeur, "h": (y1 - y0) / hauteur})
    return sorted(lignes, key=lambda l: (round(l["y"], 3), l["x"]))


def lire(chemin: Path) -> list[dict]:
    m = moteur()
    if not m:
        raise RuntimeError(explication())
    with tempfile.TemporaryDirectory() as tmp:
        prep, w, h = _preparer(Path(chemin), Path(tmp))
        lignes = _vision(prep) if m == "vision" else _tesseract(prep, w, h)
    for l in lignes:
        l["ratio"] = w / h if h else 1.0          # utile pour comparer les hauteurs de lignes
    return lignes


# ════════════════════════════ reconnaissance du contenu de l'image ════════════════════════════

def etiquettes(chemin: Path, mini: float = 0.12, maxi: int = 14) -> list[tuple[str, float]]:
    """Ce que l'image montre, d'après le classeur d'images du Mac (Apple Vision).

    Renvoie [("sunset", 0.74), ("beach", 0.51), …] — des mots anglais génériques. Liste vide si le
    Mac ne sait pas faire (autre système, module absent) : l'appelant se rabat sur les textes.
    """
    if moteur() != "vision":
        return []
    try:
        import objc
        import Quartz
        import Vision
        from Foundation import NSURL
    except Exception:  # noqa: BLE001
        return []
    pool = getattr(objc, "autorelease_pool", None)
    try:
        with (pool() if pool else contextlib.nullcontext()):
            src = Quartz.CGImageSourceCreateWithURL(NSURL.fileURLWithPath_(str(chemin)), None)
            if src is None:
                return []
            image = Quartz.CGImageSourceCreateImageAtIndex(src, 0, None)
            if image is None:
                return []
            r = Vision.VNClassifyImageRequest.alloc().init()
            handler = Vision.VNImageRequestHandler.alloc().initWithCGImage_options_(image, {})
            res = handler.performRequests_error_([r], None)
            ok = res[0] if isinstance(res, tuple) else res
            if not ok:
                return []
            out = []
            for obs in (r.results() or []):
                try:
                    c = float(obs.confidence())
                    if c >= mini:
                        out.append((str(obs.identifier()).replace("_", " ").lower(), round(c, 3)))
                except Exception:  # noqa: BLE001
                    continue
            out.sort(key=lambda x: x[1], reverse=True)
            return out[:maxi]
    except Exception:  # noqa: BLE001
        return []
