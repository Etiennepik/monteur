"""Ligne de commande.

  python -m monteur telecharger                       télécharge les posts en file d'attente
  python -m monteur serie --theme humour --n 10       monte 10 vidéos non utilisées du thème
         [--style classique] [--original] [--logo aucun|flou|masque]
  python -m monteur index                             reconstruit l'index du centre de contrôle
  python -m monteur recepteur                         écoute l'extension Chrome (sans l'interface)
"""
import argparse
import datetime as dt

from . import bibliotheque, config, postmontage, telechargement


def main():
    ap = argparse.ArgumentParser(prog="monteur")
    ap.add_argument("action", choices=["telecharger", "serie", "index", "recepteur"])
    ap.add_argument("--theme")
    ap.add_argument("--n", type=int, default=5)
    ap.add_argument("--style", default=None)
    ap.add_argument("--original", action="store_true", help="garder le format d'origine (sinon 9:16 plein écran)")
    ap.add_argument("--logo", default="aucun", choices=["aucun", "flou", "masque"])
    a = ap.parse_args()
    cfg = config.charger()
    bibliotheque.synchroniser(cfg)

    def log(m):
        print(f"[{dt.datetime.now():%H:%M:%S}] {m}", flush=True)

    if a.action == "telecharger":
        telechargement.telecharger_file(cfg, log)
    elif a.action == "serie":
        if not a.theme:
            ap.error("--theme est obligatoire")
        style = cfg["styles"].get(a.style) or next(iter(cfg["styles"].values()))
        postmontage.serie(cfg, a.theme, a.n, style, not a.original, a.logo, log)
    elif a.action == "recepteur":
        from . import recepteur
        if recepteur.demarrer(bloquant=True) is None:
            log("Le récepteur tourne déjà (port 8765 occupé).")
    else:
        log(f"Index : {bibliotheque.exporter_index(cfg)}")


if __name__ == "__main__":
    main()
