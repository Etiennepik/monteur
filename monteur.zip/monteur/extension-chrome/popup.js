const $ = (id) => document.getElementById(id);
async function maj() {
  const r = await chrome.runtime.sendMessage({ type: "etat" });
  $("etat").innerHTML = r && r.ok
    ? `<span class="ok">● Connecté</span> · ${r.en_attente} post(s) en file${r.en_cours ? " · <b>téléchargement…</b>" : ""}` +
      (r.quotes_en_attente ? `<br>💬 ${r.quotes_en_attente} visuel(s) en cours de lecture` : "")
    : `<span class="ko">● Logiciel non lancé</span><br>Ouvre <b>Lancer.command</b> sur ton Mac.`;
}
$("sel").onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: "mode-selection", actif: true }).catch(() => {
    $("etat").innerHTML = "Ouvre une page Instagram, TikTok ou YouTube (recharge-la si l'extension vient d'être installée).";
  });
  window.close();
};
$("quotes").onclick = async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  chrome.tabs.sendMessage(tab.id, { type: "quotes-mode", actif: true }, { frameId: 0 }).then(() => window.close()).catch(() => {
    $("etat").innerHTML = "Recharge la page (l'extension vient d'être installée ou mise à jour), puis réessaie.";
  });
};
$("lancer").onclick = async () => {
  const r = await chrome.runtime.sendMessage({ type: "lancer" });
  $("etat").textContent = r && r.ok ? (r.lance ? "Téléchargement lancé ✔" : "Déjà en cours…") : "Logiciel non lancé";
};
maj();
