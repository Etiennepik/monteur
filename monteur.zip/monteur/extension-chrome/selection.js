// Monteur — sélection des posts sur Instagram / TikTok / YouTube
//  • s'active tout seul sur les pages enregistrées dans l'onglet « Bibliothèque vidéo »
//  • clic sur un post = cocher / décocher ; cliquer-glisser = rectangle de sélection (Alt = désélectionner)
//  • badges sur les posts déjà pris (en file, dans la bibliothèque, déjà utilisés)
(() => {
  if (window.__monteur) return;
  window.__monteur = true;

  const MOTIFS = [
    /instagram\.com\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+/,
    /tiktok\.com\/@[^/]+\/video\/\d+/,
    /youtube\.com\/shorts\/[\w-]+/,
    /youtube\.com\/watch\?v=[\w-]+/,
  ];
  const estPost = (href) => !!href && MOTIFS.some((m) => m.test(href));

  function clePost(u) {
    let m = u.match(/instagram\.com\/(?:[\w.]+\/)?(?:p|reels?|tv)\/([\w-]+)/);
    if (m) return "ig:" + m[1];
    m = u.match(/tiktok\.com\/.*?\/(?:video|photo)\/(\d+)/);
    if (m) return "tt:" + m[1];
    m = u.match(/youtube\.com\/shorts\/([\w-]+)/) || u.match(/[?&]v=([\w-]+)/);
    if (m) return "yt:" + m[1];
    return u;
  }
  function normaliser(href) {
    try {
      const u = new URL(href, location.href);
      if (u.hostname.includes("youtube.com") && u.pathname === "/watch") return `https://www.youtube.com/watch?v=${u.searchParams.get("v")}`;
      return `${u.origin}${u.pathname}`;
    } catch { return null; }
  }
  // « instagram.com/nom » ou « tiktok.com/@nom » → clé de compte
  function cleCompte(href) {
    try {
      const u = new URL(href, location.href);
      const seg = u.pathname.split("/").filter(Boolean);
      if (!seg.length) return null;
      const h = u.hostname.replace(/^www\.|^m\./, "");
      if (h.includes("youtube.com")) return h + "/" + seg.slice(0, seg[0].startsWith("@") ? 1 : 2).join("/").toLowerCase();
      return h + "/" + seg[0].toLowerCase();
    } catch { return null; }
  }

  // ── état ──
  let actif = false;
  const choisis = new Map();          // cle -> url
  let etatPosts = {};                 // cle -> statut (en_attente / telecharge / utilisee / erreur)
  let barre, compteur, selTheme, observateur, sondage, dernierLien = null, desactiveIci = null;

  const BADGES = {
    en_attente: ["⏳ en cours", "monteur-b-attente"],
    telecharge: ["✓ bibliothèque", "monteur-b-ok"],
    utilisee: ["★ déjà utilisée", "monteur-b-utilisee"],
    erreur: ["✖ échec", "monteur-b-erreur"],
  };
  const dejaPris = (cle) => ["en_attente", "telecharge", "utilisee"].includes(etatPosts[cle]);

  document.addEventListener("contextmenu", (e) => {
    const a = e.target.closest && e.target.closest("a[href]");
    dernierLien = a && estPost(a.href) ? normaliser(a.href) : (estPost(location.href) ? normaliser(location.href) : null);
  }, true);

  function vignettes() {
    return [...document.querySelectorAll("a[href]")].filter((a) => {
      if (!estPost(a.href) || (barre && barre.contains(a))) return false;
      const r = a.getBoundingClientRect();
      return (a.querySelector("img, video, canvas") || r.height > 90) && r.width > 60 && r.height > 60;
    });
  }

  function decorer() {
    if (!actif) return;
    for (const a of vignettes()) {
      const url = normaliser(a.href);
      const cle = clePost(url);
      if (!a.querySelector(":scope > .monteur-case")) {
        if (getComputedStyle(a).position === "static") a.classList.add("monteur-relatif");
        const c = document.createElement("div");
        c.className = "monteur-case";
        a.appendChild(c);
        const b = document.createElement("div");
        b.className = "monteur-badge";
        a.appendChild(b);
      }
      a.dataset.monteurUrl = url;
      a.dataset.monteurCle = cle;
      a.classList.add("monteur-cible");
      a.classList.toggle("monteur-choisi", choisis.has(cle));
      const badge = a.querySelector(":scope > .monteur-badge");
      const b = BADGES[etatPosts[cle]];
      badge.textContent = b ? b[0] : "";
      badge.className = "monteur-badge " + (b ? b[1] : "");
    }
  }

  function rafraichir() {
    document.querySelectorAll("a.monteur-cible").forEach((a) => a.classList.toggle("monteur-choisi", choisis.has(a.dataset.monteurCle)));
    if (compteur) compteur.textContent = `${choisis.size} sélectionné${choisis.size > 1 ? "s" : ""}`;
  }
  function basculerPost(a, forcer) {
    const cle = a.dataset.monteurCle;
    const on = forcer !== undefined ? forcer : !choisis.has(cle);
    on ? choisis.set(cle, a.dataset.monteurUrl) : choisis.delete(cle);
  }

  // ── souris : clic = cocher, glisser = rectangle ──
  let depart = null, rect = null, autoScroll = null, derniereSouris = null;
  const horsBarre = (e) => !(barre && barre.contains(e.target));

  function bloquer(e) { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); }

  function majRectangle() {
    if (!depart || !derniereSouris) return;
    const x2 = derniereSouris.clientX + scrollX, y2 = derniereSouris.clientY + scrollY;
    const x = Math.min(depart.x, x2), y = Math.min(depart.y, y2);
    Object.assign(rect.style, { left: x + "px", top: y + "px", width: Math.abs(x2 - depart.x) + "px", height: Math.abs(y2 - depart.y) + "px" });
  }

  window.addEventListener("mousedown", (e) => {
    if (!actif || e.button !== 0 || !horsBarre(e)) return;
    bloquer(e);
    depart = { x: e.clientX + scrollX, y: e.clientY + scrollY, cx: e.clientX, cy: e.clientY, alt: e.altKey,
      cible: e.target.closest && e.target.closest("a.monteur-cible"), glisse: false };
  }, true);

  window.addEventListener("mousemove", (e) => {
    if (!actif || !depart) return;
    derniereSouris = e;
    if (!depart.glisse && Math.hypot(e.clientX - depart.cx, e.clientY - depart.cy) > 6) {
      depart.glisse = true;
      rect = document.createElement("div");
      rect.id = "monteur-rectangle";
      if (depart.alt) rect.classList.add("monteur-retrait");
      document.documentElement.appendChild(rect);
      document.documentElement.classList.add("monteur-glisse");
      autoScroll = setInterval(() => {   // défilement auto quand on approche du bord
        if (!derniereSouris) return;
        const m = 60, y = derniereSouris.clientY;
        if (y > innerHeight - m) scrollBy(0, 18); else if (y < m) scrollBy(0, -18);
        majRectangle();
      }, 30);
    }
    if (depart.glisse) { bloquer(e); majRectangle(); }
  }, true);

  window.addEventListener("mouseup", (e) => {
    if (!actif || !depart) return;
    if (horsBarre(e) || depart.glisse) bloquer(e);
    if (depart.glisse) {
      const r = rect.getBoundingClientRect();
      for (const a of vignettes()) {
        const v = a.getBoundingClientRect();
        if (v.right > r.left && v.left < r.right && v.bottom > r.top && v.top < r.bottom) {
          decorer();
          if (!depart.alt && dejaPris(a.dataset.monteurCle)) continue;
          basculerPost(a, !depart.alt);
        }
      }
      rect.remove(); rect = null;
      clearInterval(autoScroll);
      document.documentElement.classList.remove("monteur-glisse");
    } else if (depart.cible) {
      basculerPost(depart.cible);
    }
    depart = null; derniereSouris = null;
    rafraichir();
  }, true);

  ["click", "dblclick", "auxclick"].forEach((t) =>
    window.addEventListener(t, (e) => { if (actif && horsBarre(e)) bloquer(e); }, true));
  // pas de preventDefault sur pointerdown : cela supprimerait les événements souris qui suivent
  ["pointerdown", "pointerup", "touchstart"].forEach((t) =>
    window.addEventListener(t, (e) => { if (actif && horsBarre(e)) { e.stopPropagation(); e.stopImmediatePropagation(); } }, true));
  window.addEventListener("dragstart", (e) => { if (actif) bloquer(e); }, true);

  // ── barre flottante ──
  function creerBarre(themes) {
    barre = document.createElement("div");
    barre.id = "monteur-barre";
    barre.innerHTML = `
      <span class="monteur-logo">🎬 Monteur</span>
      <span class="monteur-compteur">0 sélectionné</span>
      <button data-a="tout" title="Coche tous les posts chargés et pas encore pris (fais défiler pour en charger plus)">Tout cocher</button>
      <button data-a="vider">Vider</button>
      <label>Ranger dans <select class="monteur-theme"></select></label>
      <button data-a="envoyer" class="monteur-principal">Envoyer à la bibliothèque</button>
      <button data-a="quitter" title="Quitter le mode sélection (Échap)">✕</button>
      <span class="monteur-aide">Clic = cocher · glisser = sélection rectangle · Alt + glisser = décocher</span>`;
    document.documentElement.appendChild(barre);
    compteur = barre.querySelector(".monteur-compteur");
    selTheme = barre.querySelector(".monteur-theme");
    const esc = (t) => t.replace(/[<>&"]/g, "");
    selTheme.innerHTML = `<option value="auto">🤖 Classer automatiquement</option>
      <option value="">📥 À classer (je choisirai)</option>` + themes.map((t) => `<option value="${esc(t)}">📁 ${esc(t)}</option>`).join("");
    chrome.storage.local.get(["theme"], (v) => { if (v.theme !== undefined && [...selTheme.options].some((o) => o.value === v.theme)) selTheme.value = v.theme; });
    selTheme.onchange = () => chrome.storage.local.set({ theme: selTheme.value });
    barre.addEventListener("click", async (e) => {
      const act = e.target.dataset && e.target.dataset.a;
      if (!act) return;
      if (act === "tout") { decorer(); vignettes().forEach((a) => { if (!dejaPris(a.dataset.monteurCle)) basculerPost(a, true); }); rafraichir(); }
      if (act === "vider") { choisis.clear(); rafraichir(); }
      if (act === "quitter") { desactiveIci = location.pathname; basculer(false); }
      if (act === "envoyer") {
        if (!choisis.size) return toast("Aucun post sélectionné", "info");
        const urls = [...choisis.values()];
        let r = await chrome.runtime.sendMessage({ type: "envoyer", urls, theme: selTheme.value, compte: location.href });
        if (!r || !r.ok) return toast((r && r.erreur) || "Erreur", "erreur");
        if (r.doublons) {
          const refaire = await demander(
            `${r.doublons} post(s) déjà pris précédemment. Les retélécharger quand même ?`, "Oui, retélécharger");
          if (refaire) {
            const r2 = await chrome.runtime.sendMessage({ type: "envoyer", urls, theme: selTheme.value,
                                                          compte: location.href, force: true });
            if (r2 && r2.ok) r = { ajoutes: r.ajoutes + (r2.ajoutes || 0), doublons: 0 };
          }
        }
        for (const cle of choisis.keys()) etatPosts[cle] = "en_attente";
        toast(`${r.ajoutes} post(s) envoyé(s) — téléchargement en cours` + (r.doublons ? ` · ${r.doublons} déjà pris` : ""), "ok");
        choisis.clear(); decorer(); rafraichir();
      }
    });
  }

  async function chargerEtat() {
    try {
      const r = await chrome.runtime.sendMessage({ type: "etat" });
      if (r && r.ok) { etatPosts = r.posts || {}; return r; }
    } catch (e) {}
    return null;
  }

  async function basculer(on) {
    if (on === actif) return;
    if (on) {
      const r = await chargerEtat();
      if (!r) return toast("Logiciel Monteur injoignable — lance Lancer.command", "erreur");
      if (window.__monteurQuotes && window.__monteurQuotes.actif) window.dispatchEvent(new CustomEvent("monteur-videos-actif"));
      actif = true;
      creerBarre(r.themes || []);
      decorer(); rafraichir();
      observateur = new MutationObserver(() => { clearTimeout(observateur.t); observateur.t = setTimeout(decorer, 250); });
      observateur.observe(document.body, { childList: true, subtree: true });
      sondage = setInterval(async () => { await chargerEtat(); decorer(); }, 4000);
      toast("Mode sélection : clique ou glisse sur les posts à prendre", "info");
    } else {
      actif = false;
      observateur && observateur.disconnect();
      clearInterval(sondage);
      barre && barre.remove(); barre = null;
      choisis.clear();
      document.querySelectorAll(".monteur-case, .monteur-badge").forEach((n) => n.remove());
      document.querySelectorAll(".monteur-cible").forEach((a) => a.classList.remove("monteur-cible", "monteur-choisi", "monteur-relatif"));
    }
  }

  // ── demande de confirmation (deux clics avant de reprendre un post déjà pris) ──
  function demander(texte, ouiTexte) {
    return new Promise((resolve) => {
      document.querySelectorAll(".monteur-confirme").forEach((e) => e.remove());
      const c = document.createElement("div");
      c.className = "monteur-confirme";
      const p = document.createElement("span");
      p.textContent = texte;
      const oui = document.createElement("button");
      oui.className = "mq-principal";
      oui.textContent = ouiTexte || "Oui";
      const non = document.createElement("button");
      non.textContent = "Annuler";
      c.append(p, non, oui);
      document.documentElement.appendChild(c);
      setTimeout(() => c.classList.add("monteur-visible"), 10);
      const fin = (v) => { c.remove(); resolve(v); };
      oui.onclick = () => fin(true);
      non.onclick = () => fin(false);
      setTimeout(() => { if (c.isConnected) fin(false); }, 20000);
    });
  }

  function toast(texte, niveau = "ok") {
    const t = document.createElement("div");
    t.className = `monteur-toast monteur-${niveau}`;
    t.textContent = texte;
    document.documentElement.appendChild(t);
    setTimeout(() => t.classList.add("monteur-visible"), 10);
    setTimeout(() => { t.classList.remove("monteur-visible"); setTimeout(() => t.remove(), 300); }, 3500);
  }

  // activation automatique sur les comptes enregistrés (et sur les liens ouverts depuis Monteur : #monteur)
  let derniereUrl = null;
  async function verifierAuto() {
    if (location.href === derniereUrl) return;
    derniereUrl = location.href;
    if (desactiveIci && desactiveIci !== location.pathname) desactiveIci = null;
    if (actif || desactiveIci) return;
    // la page a été ouverte pour les quotes : pas de sélection de vidéos
    if (/monteur-quotes/.test(location.hash) || (window.__monteurQuotes && window.__monteurQuotes.actif)) return;
    if (/(^#|&)monteur($|&)/.test(location.hash)) return basculer(true);
    const r = await chargerEtat();
    if (!r) return;
    const ici = cleCompte(location.href);
    if (ici && (r.comptes || []).some((c) => cleCompte(c) === ici) && !estPost(location.href)) basculer(true);
  }
  setTimeout(verifierAuto, 800);
  setInterval(verifierAuto, 1500);

  chrome.runtime.onMessage.addListener((msg, _s, repondre) => {
    if (msg.type === "mode-selection") basculer(msg.actif !== false);
    if (msg.type === "toast") toast(msg.texte, msg.niveau);
    if (msg.type === "post-sous-souris") repondre(dernierLien);
    if (msg.type === "demander") { demander(msg.texte, msg.oui).then(repondre); return true; }
  });
  window.addEventListener("monteur-quotes-actif", () => { if (actif) { desactiveIci = location.pathname; basculer(false); } });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && actif) { desactiveIci = location.pathname; basculer(false); } });
})();
