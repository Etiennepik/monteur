// Monteur — service worker : menus clic droit + relais vers le logiciel local (127.0.0.1:8765)
const SERVEUR = "http://127.0.0.1:8765";
const DOCS = ["https://*.instagram.com/*", "https://*.tiktok.com/*", "https://*.youtube.com/*"];
let cleMenus = null;

async function etat() {
  const r = await fetch(`${SERVEUR}/etat`, { cache: "no-store" });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

async function poster(chemin, corps) {
  const r = await fetch(`${SERVEUR}${chemin}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(corps),
  });
  if (!r.ok) throw new Error("HTTP " + r.status);
  return r.json();
}

const envoyer = (urls, theme, compte = "", force = false) => poster("/ajouter", { urls, theme, compte, force, lancer: true });

// ── images : téléchargement par l'extension (évite les blocages des sites), sinon capture d'écran ──
function enBase64(buffer) {
  const octets = new Uint8Array(buffer);
  let s = "";
  for (let i = 0; i < octets.length; i += 0x8000) s += String.fromCharCode.apply(null, octets.subarray(i, i + 0x8000));
  return btoa(s);
}

async function imageEnBase64(url) {
  let r = null;
  try { r = await fetch(url, { credentials: "include" }); } catch (e) { r = await fetch(url); }
  if (!r || !r.ok) throw new Error("HTTP " + (r && r.status));
  const type = r.headers.get("content-type") || "";
  if (type && !type.startsWith("image/") && !type.startsWith("application/octet-stream")) throw new Error("pas une image : " + type);
  const buf = await r.arrayBuffer();
  if (buf.byteLength < 200 || buf.byteLength > 25_000_000) throw new Error("taille inattendue");
  return enBase64(buf);
}

async function capturer(tab, rect, largeurVue) {
  const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: "png" });
  const bmp = await createImageBitmap(await (await fetch(dataUrl)).blob());
  const k = bmp.width / (largeurVue || bmp.width);
  const x = Math.max(0, Math.round(rect.x * k)), y = Math.max(0, Math.round(rect.y * k));
  const w = Math.min(bmp.width - x, Math.round(rect.w * k)), h = Math.min(bmp.height - y, Math.round(rect.h * k));
  if (w < 20 || h < 20) throw new Error("zone hors écran");
  const toile = new OffscreenCanvas(w, h);
  toile.getContext("2d").drawImage(bmp, x, y, w, h, 0, 0, w, h);
  const blob = await toile.convertToBlob({ type: "image/png" });
  return enBase64(await blob.arrayBuffer());
}

// ── menus clic droit ──
async function construireMenus() {
  let themes = [];
  let enLigne = true;
  try { themes = (await etat()).themes || []; } catch (e) { enLigne = false; }
  const cle = (enLigne ? "1" : "0") + themes.join("|");
  if (cle === cleMenus) return;
  cleMenus = cle;

  await chrome.contextMenus.removeAll();
  const tout = ["all"];
  chrome.contextMenus.create({ id: "monteur", title: "Monteur", contexts: tout });
  if (!enLigne) {
    chrome.contextMenus.create({ id: "hors-ligne", parentId: "monteur", enabled: false,
      title: "Logiciel non lancé — ouvre Lancer.command", contexts: tout });
    return;
  }
  const choix = [["auto", "🤖 Classer automatiquement"], ["", "📥 À classer (je choisirai)"], ...themes.map((t) => [t, "📁 " + t])];
  // quotes : sur tous les sites
  const ctxQ = ["image", "video", "link", "page"];
  chrome.contextMenus.create({ id: "quote", parentId: "monteur", title: "💬 Extraire la quote de ce visuel", contexts: ctxQ });
  for (const [val, titre] of choix) {
    chrome.contextMenus.create({ id: "quote:" + val, parentId: "quote", title: titre, contexts: ctxQ });
  }
  chrome.contextMenus.create({ id: "quotes-selection", parentId: "monteur", title: "☑︎ Choisir plusieurs visuels pour leurs quotes…",
    contexts: tout });
  // vidéos : Instagram / TikTok / YouTube
  chrome.contextMenus.create({ id: "sep", parentId: "monteur", type: "separator", contexts: tout, documentUrlPatterns: DOCS });
  for (const [val, titre] of choix) {
    chrome.contextMenus.create({ id: "ajouter:" + val, parentId: "monteur", title: `Ajouter ce post à la bibliothèque → ${titre}`,
      contexts: ["link", "image", "video", "page"], documentUrlPatterns: DOCS });
  }
  chrome.contextMenus.create({ id: "selection", parentId: "monteur", title: "☑︎ Sélectionner plusieurs posts (vidéos) sur cette page…",
    contexts: tout, documentUrlPatterns: DOCS });
}

function notifier(tabId, texte, type = "ok") {
  if (tabId) chrome.tabs.sendMessage(tabId, { type: "toast", texte, niveau: type }).catch(() => {});
}

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  const id = String(info.menuItemId);
  if (id === "selection") {
    chrome.tabs.sendMessage(tab.id, { type: "mode-selection", actif: true }).catch(() => {});
    return;
  }
  if (id === "quotes-selection") {
    chrome.tabs.sendMessage(tab.id, { type: "quotes-mode", actif: true }, { frameId: 0 }).catch(() => {});
    return;
  }
  if (id.startsWith("quote:")) {
    const theme = id.slice("quote:".length);
    const msg = { type: "quotes-clic-droit", theme, srcUrl: info.srcUrl || "", mediaType: info.mediaType || "", linkUrl: info.linkUrl || "" };
    try {
      await chrome.tabs.sendMessage(tab.id, msg, { frameId: info.frameId || 0 });
    } catch (e) {
      // page ouverte avant l'installation de l'extension : envoi direct de l'image cliquée
      if (!info.srcUrl) return;
      const el = { image_url: info.srcUrl, post_url: "", video: info.mediaType === "video" };
      try { el.image_b64 = await imageEnBase64(info.srcUrl); } catch (x) {}
      try { await poster("/quotes", { elements: [el], theme, page_url: info.pageUrl || "" }); } catch (x) {}
    }
    return;
  }
  if (id.startsWith("ajouter:")) {
    const theme = id.slice("ajouter:".length);
    // lien survolé (vignette d'un profil) sinon la page elle-même (post ouvert)
    let url = info.linkUrl || null;
    if (!url) {
      try { url = await chrome.tabs.sendMessage(tab.id, { type: "post-sous-souris" }); } catch (e) {}
    }
    url = url || info.pageUrl;
    try {
      const r = await envoyer([url], theme, info.pageUrl);
      if (r.ajoutes) notifier(tab.id, "Ajouté — téléchargement en cours", "ok");
      else {
        // déjà pris : on demande confirmation dans la page avant de retélécharger
        let refaire = false;
        try {
          refaire = await chrome.tabs.sendMessage(tab.id, {
            type: "demander", texte: "Ce post a déjà été pris. Le retélécharger ?", oui: "Oui, retélécharger" });
        } catch (e) {}
        if (!refaire) return notifier(tab.id, "Ce post est déjà pris", "info");
        const r2 = await envoyer([url], theme, info.pageUrl, true);
        notifier(tab.id, r2.ajoutes ? "Retéléchargement en cours" : "Impossible de reprendre ce post",
                 r2.ajoutes ? "ok" : "erreur");
      }
    } catch (e) {
      notifier(tab.id, "Logiciel Monteur injoignable — lance Lancer.command", "erreur");
    }
  }
});

chrome.runtime.onMessage.addListener((msg, sender, repondre) => {
  (async () => {
    // images et captures : ne nécessitent pas le logiciel
    if (msg.type === "quotes-image") {
      try { repondre({ ok: true, b64: await imageEnBase64(msg.url) }); } catch (e) { repondre({ ok: false, erreur: String(e) }); }
      return;
    }
    if (msg.type === "quotes-capturer") {
      try { repondre({ ok: true, b64: await capturer(sender.tab, msg.rect, msg.largeurVue) }); } catch (e) { repondre({ ok: false, erreur: String(e) }); }
      return;
    }
    try {
      if (msg.type === "etat") repondre({ ok: true, ...(await etat()) });
      else if (msg.type === "envoyer") repondre({ ok: true, ...(await envoyer(msg.urls, msg.theme, msg.compte, msg.force)) });
      else if (msg.type === "quotes-envoyer") {
        repondre({ ok: true, ...(await poster("/quotes", { elements: msg.elements, theme: msg.theme, page_url: msg.page_url, force: !!msg.force })) });
      } else if (msg.type === "lancer") {
        const r = await fetch(`${SERVEUR}/lancer`, { method: "POST", headers: { "Content-Type": "application/json" }, body: "{}" });
        repondre({ ok: true, ...(await r.json()) });
      } else repondre({ ok: false });
      construireMenus();
    } catch (e) {
      repondre({ ok: false, erreur: "Logiciel Monteur injoignable — lance Lancer.command" });
    }
  })();
  return true; // réponse asynchrone
});

chrome.runtime.onInstalled.addListener(() => { chrome.alarms.create("menus", { periodInMinutes: 1 }); construireMenus(); });
chrome.runtime.onStartup.addListener(construireMenus);
chrome.alarms.onAlarm.addListener(construireMenus);
