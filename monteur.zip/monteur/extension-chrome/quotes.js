// Monteur — quotes : choisir des images / vidéos sur n'importe quel site pour en extraire le texte
//  • s'active sur les pages ouvertes depuis Monteur (lien #monteur-quotes), ou par clic droit / l'icône 🎬
//  • clic sur un visuel = cocher / décocher ; cliquer-glisser = rectangle de sélection (Alt = décocher)
//  • clic droit sur un visuel → Monteur → Extraire la quote (sans passer par la sélection)
(() => {
  if (window.__monteurQuotes) return;
  const etatGlobal = (window.__monteurQuotes = { actif: false });
  const MIN = 90;                                  // taille minimale d'un visuel (px)
  const MOTIFS = [
    /instagram\.com\/(?:[\w.]+\/)?(?:p|reels?|tv)\/[\w-]+/,
    /tiktok\.com\/@[^/]+\/(?:video|photo)\/\d+/,
    /youtube\.com\/shorts\/[\w-]+/,
    /youtube\.com\/watch\?v=[\w-]+/,
    /pinterest\.[a-z.]+\/pin\/[\w-]+/,
  ];
  const estPost = (h) => !!h && MOTIFS.some((m) => m.test(h));
  const estVideoPost = (h) => !!h && (/instagram\.com\/(?:[\w.]+\/)?(?:reels?|tv)\//.test(h) || /tiktok\.com\/.*\/video\//.test(h) || /youtube\.com/.test(h));

  function normaliser(href) {
    try {
      const u = new URL(href, location.href);
      if (u.hostname.includes("youtube.com") && u.pathname === "/watch") return `https://www.youtube.com/watch?v=${u.searchParams.get("v")}`;
      return `${u.origin}${u.pathname}`;
    } catch { return null; }
  }
  // même clé que le logiciel (badges « déjà prise »)
  function cleVisuel(d) {
    const u = d.post_url || "";
    let m = u.match(/instagram\.com\/(?:[\w.]+\/)?(?:p|reels?|tv)\/([\w-]+)/);
    if (m) return "ig:" + m[1];
    m = u.match(/tiktok\.com\/.*?\/(?:video|photo)\/(\d+)/);
    if (m) return "tt:" + m[1];
    m = u.match(/youtube\.com\/shorts\/([\w-]+)/) || u.match(/[?&]v=([\w-]+)/);
    if (m) return "yt:" + m[1];
    m = u.match(/pinterest\.[a-z.]+\/pin\/([\w-]+)/);
    if (m) return "pin:" + m[1];
    return "url:" + (d.image_url || d.video_url || "");
  }

  // ── description d'un visuel ──
  function meilleureSource(img) {
    let url = img.currentSrc || img.src || "";
    // srcset : la plus grande variante
    const set = img.getAttribute("srcset");
    if (set) {
      let best = 0;
      for (const part of set.split(",")) {
        const [u, w] = part.trim().split(/\s+/);
        const n = parseFloat(w) || 0;
        if (u && n > best) { best = n; url = new URL(u, location.href).href; }
      }
    }
    // Pinterest : version grande
    if (/i\.pinimg\.com\/\d+x\//.test(url)) url = url.replace(/i\.pinimg\.com\/\d+x\//, "i.pinimg.com/736x/");
    // Google Images : lien vers l'image d'origine quand il est présent
    const a = img.closest("a[href*='imgurl=']");
    if (a) {
      try { const o = new URL(a.href).searchParams.get("imgurl"); if (o) return { url: o, secours: url }; } catch {}
    }
    return { url, secours: "" };
  }

  function decrire(el) {
    const lien = el.closest && el.closest("a[href]");
    let post = null;
    if (lien && estPost(lien.href)) post = normaliser(lien.href);
    else if (estPost(location.href) && !(lien && lien.href && !lien.href.startsWith("javascript"))) post = normaliser(location.href);
    const d = { post_url: post || "", image_url: "", secours_url: "", video_url: "", video: false };
    if (el.tagName === "VIDEO") {
      d.video = true;
      const src = el.currentSrc || el.src || "";
      if (/^https?:/.test(src)) d.video_url = src;
      if (el.poster) d.image_url = new URL(el.poster, location.href).href;
    } else {
      const s = meilleureSource(el);
      d.image_url = s.url;
      d.secours_url = s.secours;
    }
    if (estVideoPost(post)) d.video = true;
    if (!d.video && lien && lien.querySelector("video")) d.video = true;
    d.src = el.currentSrc || el.src || "";          // ce que l'élément affichait à cet instant
    // identifiant toujours unique : sans URL exploitable (vidéo en blob:), deux tuiles auraient la même clé
    if (!el.__mqId) el.__mqId = "el" + Math.random().toString(36).slice(2, 10);
    d.cle = cleVisuel(d);
    if (d.cle === "url:") d.cle = "url:" + (d.src || el.__mqId);
    return d;
  }

  // ── visuels candidats ──
  const nous = (el) => el.closest && el.closest("#monteur-q-barre, #monteur-q-calque, #monteur-barre");
  function visuels() {
    const out = [];
    for (const el of document.querySelectorAll("img, video")) {
      if (nous(el)) continue;
      const r = el.getBoundingClientRect();
      // une vidéo (reel, lecteur) compte même si elle est plus petite que les images
      if (r.width < (el.tagName === "VIDEO" ? 60 : MIN) || r.height < (el.tagName === "VIDEO" ? 60 : MIN)) continue;
      if (el.tagName === "IMG" && !(el.currentSrc || el.src)) continue;
      const st = getComputedStyle(el);
      if (st.visibility === "hidden" || st.display === "none" || parseFloat(st.opacity) < 0.05) continue;
      out.push(el);
    }
    return out;
  }
  function visuelAuPoint(x, y) {
    let meilleur = null, aire = Infinity;
    for (const el of document.elementsFromPoint(x, y)) {
      if (nous(el)) continue;
      if ((el.tagName === "IMG" || el.tagName === "VIDEO")) {
        const r = el.getBoundingClientRect();
        if (r.width >= MIN && r.height >= MIN) return el;
      }
    }
    // visuel recouvert par un calque transparent (Instagram, Pinterest…) : le plus petit qui contient le point
    for (const el of visuels()) {
      const r = el.getBoundingClientRect();
      if (x >= r.left && x <= r.right && y >= r.top && y <= r.bottom && r.width * r.height < aire) {
        meilleur = el; aire = r.width * r.height;
      }
    }
    return meilleur;
  }

  // dernier clic droit (pour « Extraire la quote » du menu contextuel)
  let dernierVisuel = null;
  document.addEventListener("contextmenu", (e) => { dernierVisuel = visuelAuPoint(e.clientX, e.clientY); }, true);

  // ── état ──
  let actif = false;
  const choisis = new Map();          // cle -> {el, d} figés au moment du clic
  const correspondances = new Map();  // clé de la page -> clé du logiciel (badges justes)
  let etatVisuels = {};               // cle -> statut
  let themes = [];
  let barre, compteur, selTheme, calque, observateur, sondage, envoiEnCours = false;
  const BADGES = {
    en_attente: ["⏳ en cours", "mq-b-attente"], en_cours: ["⏳ lecture…", "mq-b-attente"],
    ok: ["✓ quote prise", "mq-b-ok"], doublon: ["✓ déjà dans Captions", "mq-b-gris"],
    vide: ["∅ pas de texte", "mq-b-gris"], erreur: ["✖ échec", "mq-b-erreur"],
  };
  const statut = (cle) => etatVisuels[correspondances.get(cle) || cle];
  const dejaPris = (cle) => ["en_attente", "en_cours", "ok", "doublon"].includes(statut(cle));

  // ── calque de cases (dessiné par-dessus la page, sans toucher à son code) ──
  const boites = new Map();           // élément -> div
  let tracePrevu = false;
  function tracer() {
    if (tracePrevu) return;
    tracePrevu = true;
    requestAnimationFrame(() => { tracePrevu = false; dessiner(); });
  }
  function dessiner() {
    if (!actif || !calque) return;
    const vus = new Set();
    for (const el of visuels()) {
      const r = el.getBoundingClientRect();
      if (r.bottom < -innerHeight || r.top > 2 * innerHeight) continue;
      vus.add(el);
      let b = boites.get(el);
      if (!b) {
        b = document.createElement("div");
        b.className = "mq-boite";
        b.innerHTML = `<div class="mq-case"></div><div class="mq-badge"></div>`;
        calque.appendChild(b);
        boites.set(el, b);
      }
      if (!el.__mqDesc || el.__mqSrc !== (el.currentSrc || el.src)) {
        el.__mqDesc = decrire(el);
        el.__mqSrc = el.currentSrc || el.src;
      }
      const d = el.__mqDesc;
      Object.assign(b.style, { left: r.left + scrollX + "px", top: r.top + scrollY + "px", width: r.width + "px", height: r.height + "px" });
      const pris = choisis.has(d.cle);
      b.classList.toggle("mq-choisi", pris);
      b.querySelector(".mq-case").textContent = pris ? "✓" : "";
      const badge = b.querySelector(".mq-badge");
      const bd = BADGES[statut(d.cle)];
      badge.textContent = bd ? bd[0] : (d.video ? "▶ vidéo" : "");
      badge.className = "mq-badge " + (bd ? bd[1] : d.video ? "mq-b-gris" : "");
    }
    for (const [el, b] of boites) if (!vus.has(el)) { b.remove(); boites.delete(el); }
  }
  function rafraichir() {
    if (compteur && !envoiEnCours) compteur.textContent = `${choisis.size} visuel${choisis.size > 1 ? "s" : ""}`;
    dessiner();
  }
  function basculerVisuel(el, forcer) {
    const d = el.__mqDesc || (el.__mqDesc = decrire(el));
    const on = forcer !== undefined ? forcer : !choisis.has(d.cle);
    on ? choisis.set(d.cle, { el, d }) : choisis.delete(d.cle);
  }

  // ── souris : clic = cocher, glisser = rectangle ──
  let depart = null, rect = null, autoScroll = null, derniereSouris = null;
  const horsBarre = (e) => !(barre && barre.contains(e.target));
  const bloquer = (e) => { e.preventDefault(); e.stopPropagation(); e.stopImmediatePropagation(); };
  function majRectangle() {
    if (!depart || !derniereSouris || !rect) return;
    const x2 = derniereSouris.clientX + scrollX, y2 = derniereSouris.clientY + scrollY;
    Object.assign(rect.style, { left: Math.min(depart.x, x2) + "px", top: Math.min(depart.y, y2) + "px",
      width: Math.abs(x2 - depart.x) + "px", height: Math.abs(y2 - depart.y) + "px" });
  }
  window.addEventListener("mousedown", (e) => {
    if (!actif || e.button !== 0 || !horsBarre(e)) return;
    bloquer(e);
    depart = { x: e.clientX + scrollX, y: e.clientY + scrollY, cx: e.clientX, cy: e.clientY, alt: e.altKey, glisse: false };
  }, true);
  window.addEventListener("mousemove", (e) => {
    if (!actif) return;
    if (!depart) {               // survol (au plus 20 fois par seconde)
      const t = performance.now();
      if (t - (window.__mqSurvol || 0) < 50) return;
      window.__mqSurvol = t;
      const el = visuelAuPoint(e.clientX, e.clientY);
      for (const [x, b] of boites) b.classList.toggle("mq-survol", x === el);
      return;
    }
    derniereSouris = e;
    if (!depart.glisse && Math.hypot(e.clientX - depart.cx, e.clientY - depart.cy) > 6) {
      depart.glisse = true;
      rect = document.createElement("div");
      rect.id = "monteur-q-rectangle";
      if (depart.alt) rect.classList.add("mq-retrait");
      document.documentElement.appendChild(rect);
      document.documentElement.classList.add("mq-glisse");
      autoScroll = setInterval(() => {
        if (!derniereSouris) return;
        const y = derniereSouris.clientY;
        if (y > innerHeight - 60) scrollBy(0, 18); else if (y < 60) scrollBy(0, -18);
        majRectangle();
      }, 30);
    }
    if (depart.glisse) { bloquer(e); majRectangle(); }
  }, true);
  window.addEventListener("mouseup", (e) => {
    if (!actif || !depart) return;
    if (horsBarre(e) || depart.glisse) bloquer(e);
    if (depart.glisse) {
      const r = rect.getBoundingClientRect();
      for (const el of visuels()) {
        const v = el.getBoundingClientRect();
        if (v.right > r.left && v.left < r.right && v.bottom > r.top && v.top < r.bottom) {
          const d = el.__mqDesc || (el.__mqDesc = decrire(el));
          if (!depart.alt && dejaPris(d.cle)) continue;
          basculerVisuel(el, !depart.alt);
        }
      }
      rect.remove(); rect = null;
      clearInterval(autoScroll);
      document.documentElement.classList.remove("mq-glisse");
    } else if (horsBarre(e)) {
      const el = visuelAuPoint(e.clientX, e.clientY);
      if (el) basculerVisuel(el);
    }
    depart = null; derniereSouris = null;
    rafraichir();
  }, true);
  ["click", "dblclick", "auxclick"].forEach((t) =>
    window.addEventListener(t, (e) => { if (actif && horsBarre(e)) bloquer(e); }, true));
  ["pointerdown", "pointerup", "touchstart"].forEach((t) =>
    window.addEventListener(t, (e) => { if (actif && horsBarre(e)) { e.stopPropagation(); e.stopImmediatePropagation(); } }, true));
  window.addEventListener("dragstart", (e) => { if (actif) bloquer(e); }, true);
  window.addEventListener("scroll", () => actif && tracer(), { passive: true, capture: true });
  window.addEventListener("resize", () => actif && tracer());

  // ── récupération des images et envoi ──
  const pause = (ms) => new Promise((r) => setTimeout(r, ms));
  const message = (m) => chrome.runtime.sendMessage(m).catch(() => null);

  async function capturerElement(el) {
    // l'image ne peut pas être téléchargée : on photographie la zone affichée à l'écran
    el.scrollIntoView({ block: "center", inline: "center" });
    await pause(450);
    document.documentElement.classList.add("mq-capture");
    await pause(60);
    const r = el.getBoundingClientRect();
    const res = await message({ type: "quotes-capturer", rect: { x: r.left, y: r.top, w: r.width, h: r.height }, largeurVue: innerWidth });
    document.documentElement.classList.remove("mq-capture");
    await pause(520);                 // Chrome limite les captures à 2 par seconde
    return res && res.ok ? res.b64 : null;
  }

  async function preparer(el, d) {
    const el2 = { post_url: d.post_url, image_url: d.image_url, video_url: d.video_url, video: d.video };
    for (const url of [d.image_url, d.secours_url]) {
      if (!url || url.startsWith("blob:")) continue;
      const r = await message({ type: "quotes-image", url });
      if (r && r.ok) { el2.image_b64 = r.b64; if (url !== d.image_url) el2.image_url = url; break; }
    }
    const routeServeur = d.post_url && /instagram|tiktok|youtube/.test(d.post_url) || /^https?:/.test(d.video_url);
    // Pour une vidéo, on joint aussi une photo de l'écran : si le téléchargement échoue côté logiciel
    // (Instagram capricieux, vidéo protégée), Monteur lit au moins l'image affichée.
    // Mais seulement si la tuile montre toujours la même chose : les grilles (TikTok, Pinterest…)
    // recyclent leurs éléments en défilant, et on photographierait alors le mauvais visuel.
    const memeVisuel = el && el.isConnected && (!d.src || (el.currentSrc || el.src || "") === d.src);
    if (!el2.image_b64 && memeVisuel && (!routeServeur || d.video)) {
      el2.image_b64 = await capturerElement(el);
    }
    return el2;
  }

  async function envoyer(liste, theme, progression, force) {
    // liste : [[élément, description]]
    let ajoutes = 0, doublons = 0, erreurs = 0, i = 0;
    const repris = [];                      // visuels refusés parce que déjà pris
    for (const [el, d] of liste) {
      i++;
      progression && progression(i, liste.length);
      let pret;
      try { pret = await preparer(el, d); } catch (e) { pret = { post_url: d.post_url, image_url: d.image_url, video: d.video }; }
      const r = await message({ type: "quotes-envoyer", elements: [pret], theme, page_url: location.href, force: !!force });
      if (r && r.ok) {
        ajoutes += r.ajoutes || 0; doublons += r.doublons || 0;
        if (r.cles && r.cles[0]) correspondances.set(d.cle, r.cles[0]);
        if (r.ajoutes) etatVisuels[correspondances.get(d.cle) || d.cle] = "en_attente";
        else repris.push([el, d]);
      } else { erreurs++; if (!r || r.erreur) { return { ajoutes, doublons, erreurs, repris, horsLigne: true }; } }
    }
    return { ajoutes, doublons, erreurs, repris, theme };
  }

  // ── demande de confirmation (deux clics avant de refaire une lecture déjà faite) ──
  function demander(texte, ouiTexte) {
    return new Promise((resolve) => {
      document.querySelectorAll(".monteur-confirme").forEach((e) => e.remove());
      const c = document.createElement("div");
      c.className = "monteur-confirme";
      const p = document.createElement("span");
      p.textContent = texte;
      const oui = document.createElement("button");
      oui.className = "mq-principal";
      oui.textContent = ouiTexte;
      const non = document.createElement("button");
      non.textContent = "Annuler";
      c.append(p, non, oui);
      document.documentElement.appendChild(c);
      setTimeout(() => c.classList.add("monteur-visible"), 10);
      const fin = (v) => { c.remove(); resolve(v); };
      oui.onclick = () => fin(true);
      non.onclick = () => fin(false);
      setTimeout(() => { if (c.isConnected) fin(false); }, 20000);
    });
  }

  async function proposerForcer(r, theme) {
    /** Après un envoi : propose de relire les visuels refusés parce que déjà pris. */
    if (!r || r.horsLigne || !r.repris || !r.repris.length) return r;
    const n = r.repris.length;
    const ok = await demander(
      `${n} visuel(s) déjà pris précédemment. Refaire la lecture quand même ?`, "Oui, relire");
    if (!ok) return r;
    const r2 = await envoyer(r.repris, theme === undefined ? r.theme : theme, null, true);
    return { ajoutes: (r.ajoutes || 0) + (r2.ajoutes || 0), doublons: 0,
             erreurs: (r.erreurs || 0) + (r2.erreurs || 0), horsLigne: r2.horsLigne, force: true };
  }

  function bilan(r) {
    if (r.horsLigne) return toast("Logiciel Monteur injoignable — lance Lancer.command", "erreur");
    const morceaux = [];
    if (r.ajoutes) morceaux.push(`${r.ajoutes} visuel(s) ${r.force ? "relu(s)" : "envoyé(s)"} — extraction en cours`);
    if (r.doublons) morceaux.push(`${r.doublons} déjà pris`);
    toast(morceaux.join(" · ") || "Rien à envoyer", r.ajoutes ? "ok" : "info");
  }

  // ── barre flottante ──
  const esc = (t) => String(t).replace(/[<>&"]/g, "");
  function creerBarre() {
    barre = document.createElement("div");
    barre.id = "monteur-q-barre";
    barre.innerHTML = `
      <span class="mq-logo">💬 Monteur · quotes</span>
      <span class="mq-compteur">0 visuel</span>
      <button data-a="tout" title="Coche tous les visuels chargés et pas encore pris (fais défiler pour en charger plus)">Tout cocher</button>
      <button data-a="vider">Vider</button>
      <label>Thème <select class="mq-theme"></select></label>
      <button data-a="page" title="Prend le post affiché (utile quand la case ne s'affiche pas : reel, vidéo protégée…)">Prendre cette page</button>
      <button data-a="envoyer" class="mq-principal">Extraire les quotes</button>
      <button data-a="quitter" title="Quitter (Échap)">✕</button>
      <span class="mq-aide">Clic = cocher · glisser = sélection rectangle · Alt + glisser = décocher · carrousel / vidéo : tout est lu</span>`;
    document.documentElement.appendChild(barre);
    compteur = barre.querySelector(".mq-compteur");
    selTheme = barre.querySelector(".mq-theme");
    remplirThemes();
    selTheme.onchange = () => chrome.storage.local.set({ themeQuotes: selTheme.value });
    barre.addEventListener("click", async (e) => {
      const act = e.target.dataset && e.target.dataset.a;
      if (!act || envoiEnCours) return;
      if (act === "tout") { visuels().forEach((el) => { const d = el.__mqDesc || (el.__mqDesc = decrire(el)); if (!dejaPris(d.cle)) basculerVisuel(el, true); }); rafraichir(); }
      if (act === "vider") { choisis.clear(); rafraichir(); }
      if (act === "page") {
        // le post affiché, sans passer par une case (reel, vidéo protégée, image non détectée)
        const d = { post_url: normaliser(location.href) || location.href, image_url: "", video_url: "",
                    video: estVideoPost(location.href) };
        d.cle = cleVisuel(d);
        let force = false;
        if (dejaPris(d.cle)) {
          force = await demander("Cette page a déjà été prise. Refaire la lecture ?", "Oui, relire");
          if (!force) return;
        }
        envoiEnCours = true;
        barre.querySelectorAll("button").forEach((b) => (b.disabled = true));
        toast("Lecture de la page…", "info");
        const r = await envoyer([[null, d]], selTheme.value, null, force);
        envoiEnCours = false;
        barre.querySelectorAll("button").forEach((b) => (b.disabled = false));
        bilan(force ? { ...r, force: true } : await proposerForcer(r, selTheme.value));
        rafraichir();
      }
      if (act === "quitter") { memo.ecrire(false); basculer(false); }
      if (act === "envoyer") {
        if (!choisis.size) return toast("Aucun visuel sélectionné", "info");
        envoiEnCours = true;
        barre.querySelectorAll("button").forEach((b) => (b.disabled = true));
        const liste = [...choisis.values()].map(({ el, d }) => [el, d]);
        let r = await envoyer(liste, selTheme.value, (i, n) => (compteur.textContent = `Envoi ${i}/${n}…`));
        r = await proposerForcer(r, selTheme.value);
        envoiEnCours = false;
        barre.querySelectorAll("button").forEach((b) => (b.disabled = false));
        bilan(r);
        if (!r.horsLigne) choisis.clear();
        rafraichir();
      }
    });
  }
  function remplirThemes() {
    if (!selTheme) return;
    const garde = selTheme.value;
    selTheme.innerHTML = `<option value="auto">🤖 Classer automatiquement</option><option value="">📥 À classer</option>` +
      themes.map((t) => `<option value="${esc(t)}">📁 ${esc(t)}</option>`).join("");
    chrome.storage.local.get(["themeQuotes"], (v) => {
      const voulu = garde || v.themeQuotes;
      if (voulu !== undefined && [...selTheme.options].some((o) => o.value === voulu)) selTheme.value = voulu;
    });
  }

  async function chargerEtat() {
    const r = await message({ type: "etat" });
    if (r && r.ok) {
      etatVisuels = r.quotes || {};
      const t = r.themes || [];
      if (t.join("|") !== themes.join("|")) { themes = t; remplirThemes(); }
      return r;
    }
    return null;
  }

  async function basculer(on) {
    if (on === actif) return;
    if (on) {
      const r = await chargerEtat();
      if (!r) return toast("Logiciel Monteur injoignable — lance Lancer.command", "erreur");
      window.dispatchEvent(new CustomEvent("monteur-quotes-actif"));   // coupe la sélection de vidéos
      actif = etatGlobal.actif = true;
      document.documentElement.classList.add("mq-actif");
      calque = document.createElement("div");
      calque.id = "monteur-q-calque";
      document.documentElement.appendChild(calque);
      creerBarre();
      rafraichir();
      observateur = new MutationObserver(() => { clearTimeout(observateur.t); observateur.t = setTimeout(tracer, 200); });
      observateur.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ["src", "srcset"] });
      sondage = setInterval(async () => { await chargerEtat(); dessiner(); }, 4000);
      // sur un post isolé (reel…), la case n'apparaît pas toujours : on oriente vers « Prendre cette page »
      setTimeout(() => {
        if (!actif) return;
        if (!visuels().length) toast("Aucun visuel détecté sur cette page — utilise « Prendre cette page »", "info");
        else toast("Clique sur les visuels dont tu veux la quote (ou glisse pour en prendre plusieurs)", "info");
      }, 900);
    } else {
      actif = etatGlobal.actif = false;
      observateur && observateur.disconnect();
      clearInterval(sondage);
      barre && barre.remove(); barre = null;
      calque && calque.remove(); calque = null;
      boites.clear(); choisis.clear();
      document.documentElement.classList.remove("mq-actif");
    }
  }
  window.addEventListener("monteur-videos-actif", () => basculer(false));

  function toast(texte, niveau = "ok") {
    const t = document.createElement("div");
    t.className = `monteur-toast monteur-${niveau}`;
    t.textContent = texte;
    document.documentElement.appendChild(t);
    setTimeout(() => t.classList.add("monteur-visible"), 10);
    setTimeout(() => { t.classList.remove("monteur-visible"); setTimeout(() => t.remove(), 300); }, 3800);
  }

  // activation automatique : pages ouvertes depuis l'onglet Captions de Monteur
  // Certains sites (Instagram…) rechargent la page et perdent le #monteur-quotes : on retient
  // l'intention dans l'onglet (sessionStorage) pour rallumer la sélection après la redirection.
  const memo = {
    lire: () => { try { return sessionStorage.getItem("monteurQuotes") === "1"; } catch { return false; } },
    ecrire: (v) => { try { v ? sessionStorage.setItem("monteurQuotes", "1") : sessionStorage.removeItem("monteurQuotes"); } catch {} },
  };
  const parLien = () => /monteur-quotes/.test(location.hash);
  if (window.top === window) {
    if (parLien()) memo.ecrire(true);
    setTimeout(() => { if (parLien() || memo.lire()) basculer(true); }, 600);
    setTimeout(() => { if (!actif && (parLien() || memo.lire())) basculer(true); }, 2500);
    window.addEventListener("hashchange", () => { if (parLien()) { memo.ecrire(true); basculer(true); } });
  }

  chrome.runtime.onMessage.addListener((msg, _s, repondre) => {
    if (msg.type === "quotes-mode") { basculer(msg.actif !== false); repondre(true); return; }
    if (msg.type === "quotes-toast") { toast(msg.texte, msg.niveau); repondre(true); return; }
    if (msg.type === "quotes-clic-droit") {
      // menu contextuel : le visuel sous la souris (ou celui que Chrome a repéré)
      (async () => {
        let el = dernierVisuel;
        let d = el ? decrire(el) : null;
        if (!d && msg.srcUrl) d = { post_url: estPost(location.href) ? normaliser(location.href) : "", image_url: msg.srcUrl, video_url: "", video: msg.mediaType === "video", cle: "url:" + msg.srcUrl };
        if (!d && msg.linkUrl && estPost(msg.linkUrl)) d = { post_url: normaliser(msg.linkUrl), image_url: "", video_url: "", video: estVideoPost(msg.linkUrl) };
        if (!d && estPost(location.href)) d = { post_url: normaliser(location.href), image_url: "", video_url: "", video: estVideoPost(location.href) };
        if (!d) { toast("Aucun visuel trouvé ici — fais un clic droit directement sur l'image", "erreur"); return; }
        if (!d.cle) d.cle = cleVisuel(d);
        if (!(await chargerEtat())) { toast("Logiciel Monteur injoignable — lance Lancer.command", "erreur"); return; }
        let force = false;
        if (dejaPris(d.cle)) {
          force = await demander("Ce visuel a déjà été pris. Refaire la lecture ?", "Oui, relire");
          if (!force) { toast("Lecture annulée", "info"); return; }
        }
        toast("Lecture du visuel…", "info");
        const r = await envoyer([[el, d]], msg.theme, null, force);
        bilan(force ? { ...r, force: true } : await proposerForcer(r, msg.theme));
        if (actif) dessiner();
      })();
      repondre(true);
    }
  });
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && actif) { memo.ecrire(false); basculer(false); } });
})();
