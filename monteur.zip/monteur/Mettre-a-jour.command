#!/bin/bash
# Met à jour Monteur à partir du dernier zip téléchargé, sans toucher à tes données.
#  • conserve config/config.yaml, donnees/, bibliotheque/, centre_de_controle/, polices ajoutées
#  • absorbe les dossiers en double créés par le navigateur ("monteur 2", "monteur 3"…)
#  • retire la mise en quarantaine macOS
cd "$(dirname "$0")" || exit 1
INSTALL="$PWD"
# MONTEUR_AUTO=1 : appelé par Lancer.command au démarrage — aucune touche à presser,
# et quoi qu'il arrive on finit par lancer Monteur plutôt que de laisser l'utilisateur devant rien.
pause() { [ -n "$MONTEUR_AUTO" ] && return 0; read -n 1 -s -r -p "$1"; echo ""; }
demarrer() { exec env MONTEUR_SANS_MAJ=1 "$INSTALL/Lancer.command"; }
abandonner() { [ -n "$MONTEUR_AUTO" ] && demarrer; exit "${1:-1}"; }
echo "=== Mise à jour de Monteur ==="
echo "Installation : $INSTALL"

TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
SOURCE=""

# 0) dernière version publiée (adresse indiquée dans les réglages : maj → url)
lire_url() {
  for CFG in "$INSTALL/config/config.yaml" "$INSTALL/config/config.defaut.yaml"; do
    [ -f "$CFG" ] || continue
    U="$("$INSTALL/.venv/bin/python" -c "import sys,yaml;print((yaml.safe_load(open(sys.argv[1])) or {}).get('maj',{}).get('url','') or '')" "$CFG" 2>/dev/null)"
    [ -n "$U" ] && { echo "$U"; return; }
  done
}
URL="$(lire_url)"
if [ -n "$URL" ]; then
  echo "→ Recherche de la dernière version publiée…"
  INFO="$(curl -fsSL --max-time 20 "$URL" 2>/dev/null)"
  ZIPURL="$(printf '%s' "$INFO" | tr ',' '\n' | sed -n 's/.*"zip"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
  VERSION="$(printf '%s' "$INFO" | tr ',' '\n' | sed -n 's/.*"version"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1)"
  if [ -n "$ZIPURL" ] && curl -fsSL --max-time 600 -o "$TMP/monteur.zip" "$ZIPURL"; then
    echo "→ Version $VERSION téléchargée"
    unzip -oq "$TMP/monteur.zip" -d "$TMP/paquet" 2>/dev/null
    SOURCE="$(find "$TMP/paquet" -maxdepth 2 -name app.py -print -quit)"
    SOURCE="${SOURCE%/app.py}"
  else
    echo "⚠ Téléchargement impossible (pas de connexion ?) — on cherche un zip sur cet ordinateur."
  fi
fi

# 1) zip le plus récent dans Téléchargements / Bureau / à côté de l'installation
[ -z "$SOURCE" ] && ZIP="$(ls -t ~/Downloads/monteur*.zip ~/Desktop/monteur*.zip "$(dirname "$INSTALL")"/monteur*.zip 2>/dev/null | head -1)"
# 2) dossier en double déjà décompressé par le navigateur, plus récent que l'installation
DOUBLON="$(ls -td "$(dirname "$INSTALL")"/monteur\ [0-9]*/ 2>/dev/null | head -1)"

if [ -n "$SOURCE" ]; then
  :
elif [ -n "$ZIP" ]; then
  echo "→ Source : $(basename "$ZIP")"
  unzip -oq "$ZIP" -d "$TMP" || { echo "❌ Archive illisible."; pause "Touche pour fermer…"; abandonner 1; }
  SOURCE="$(find "$TMP" -maxdepth 2 -name app.py -print -quit)"
  SOURCE="${SOURCE%/app.py}"
elif [ -n "$DOUBLON" ]; then
  echo "→ Source : $(basename "${DOUBLON%/}")"
  SOURCE="${DOUBLON%/}"
fi

if [ -z "$SOURCE" ] || [ ! -f "$SOURCE/app.py" ]; then
  echo ""
  echo "Aucune mise à jour trouvée."
  echo "Vérifie ta connexion internet, ou place le monteur.zip reçu dans Téléchargements, puis relance ce fichier."
  pause "Touche pour fermer…"; abandonner 1
fi

if [ "$SOURCE" = "$INSTALL" ]; then
  echo "La source et l'installation sont identiques : rien à faire."
  pause "Touche pour fermer…"; abandonner 0
fi

# Sauvegarde légère de la configuration
mkdir -p "$INSTALL/donnees"
[ -f "$INSTALL/config/config.yaml" ] && cp "$INSTALL/config/config.yaml" "$INSTALL/donnees/config.sauvegarde.yaml"

echo "→ Copie des fichiers du programme"
for CHEMIN in "$SOURCE"/*; do
  [ -f "$CHEMIN" ] || continue
  F="$(basename "$CHEMIN")"
  [ "$F" = "Mettre-a-jour.command" ] && continue   # traité juste après
  cp -f "$CHEMIN" "$INSTALL/$F"
done
# ce script est en cours d'exécution : on le remplace d'un bloc (mv) pour ne pas se couper l'herbe sous le pied
if [ -f "$SOURCE/Mettre-a-jour.command" ]; then
  cp -f "$SOURCE/Mettre-a-jour.command" "$INSTALL/.maj.nouveau" && mv -f "$INSTALL/.maj.nouveau" "$INSTALL/Mettre-a-jour.command"
fi
# tous les dossiers du programme (y compris ceux ajoutés plus tard), sauf tes données
PRESERVES=" donnees bibliotheque centre_de_controle config polices audios .venv .git "
for CHEMIN in "$SOURCE"/*/; do
  D="$(basename "$CHEMIN")"
  case "$PRESERVES" in *" $D "*) continue;; esac
  rm -rf "$INSTALL/$D" && cp -R "$CHEMIN" "$INSTALL/$D"
done
# polices : on ajoute celles du zip sans supprimer les tiennes
[ -d "$SOURCE/polices" ] && mkdir -p "$INSTALL/polices" && cp -Rn "$SOURCE/polices/." "$INSTALL/polices/" 2>/dev/null
# audios : la banque de l'utilisateur est conservée telle quelle
mkdir -p "$INSTALL/audios"
mkdir -p "$INSTALL/config"
[ -f "$SOURCE/config/config.defaut.yaml" ] && cp -f "$SOURCE/config/config.defaut.yaml" "$INSTALL/config/config.defaut.yaml"
[ ! -f "$INSTALL/config/config.yaml" ] && [ -f "$INSTALL/config/config.defaut.yaml" ] && \
  cp "$INSTALL/config/config.defaut.yaml" "$INSTALL/config/config.yaml"

find "$INSTALL" -name "__pycache__" -type d -prune -exec rm -rf {} + 2>/dev/null
chmod +x "$INSTALL"/*.command 2>/dev/null
# on vise d'abord les .command (le reste du dossier peut contenir des fichiers non modifiables)
xattr -d com.apple.quarantine "$INSTALL"/*.command 2>/dev/null
xattr -dr com.apple.quarantine "$INSTALL" 2>/dev/null
true

# Ménage : zip et dossiers en double
[ -n "$ZIP" ] && rm -f "$ZIP"
for D in "$(dirname "$INSTALL")"/monteur\ [0-9]*/; do
  [ -d "$D" ] && [ "${D%/}" != "$INSTALL" ] && rm -rf "$D" && echo "→ Dossier en double supprimé : $(basename "${D%/}")"
done

echo ""
echo "✅ Monteur est à jour. Tes comptes, vidéos, captions et réglages sont conservés."
echo "   Pense à cliquer sur ↻ sous l'extension dans chrome://extensions."
echo ""
pause "Appuie sur une touche : Monteur va démarrer…"
demarrer
