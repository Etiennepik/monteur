# 🎬 Monteur v2 — mode d'emploi

```
🎞️ Bibliothèque vidéo  →  ✂️ Post montage  →  📂 Centre de contrôle/<thème>/
 (pages + vidéos par thème)   (+ 💬 Captions)      (vidéos prêtes à publier)
```

## Partager Monteur à plusieurs

- **Même logiciel pour tout le monde** : le code est publié une fois (voir `PUBLIER.md`), et chaque
  personne le met à jour en double-cliquant sur **Mettre-a-jour.command**. Monteur affiche un bandeau
  « Nouvelle version disponible » dès qu'il y en a une.
- **Mêmes contenus** : crée un dossier Google Drive (vide) et partage-le ; chacun le choisit dans
  ⚙️ Réglages → *Dossier synchronisé trouvé sur ce Mac* (Monteur détecte Drive, iCloud et Dropbox tout seul).
  **Monteur remplit ce dossier lui-même** : `bibliotheque/`, `centre_de_controle/`, `polices/`, `audios/` et
  `donnees/` (captions + marques « utilisée »). Rien à y déposer à la main.
  Deviennent communs : vidéos, centre de contrôle, captions, **typos ajoutées**, **audios** et marques « déjà utilisée » —
  personne ne remonte la vidéo ou la quote d'un autre.
  Restent personnels : cookies du navigateur, files d'attente, réglages.
  Évitez de monter la même vidéo au même moment (le dossier se synchronise fichier par fichier).
- **Guide à transmettre** : `Guide-installation.html` (double-clic → s'ouvre dans le navigateur).

## Mettre à jour

1. Ferme la fenêtre Terminal de Monteur.
2. Double-clique sur **Mettre-a-jour.command** dans ton dossier `monteur` : il télécharge la dernière
   version publiée tout seul. (Sans connexion, il prend le `monteur.zip` présent dans Téléchargements.)

Il installe la nouvelle version par-dessus, conserve tes réglages, ta bibliothèque, tes captions, le centre de
contrôle, tes polices et tes audios, supprime le zip et les dossiers en double (« monteur 2 »), lève le blocage de macOS,
puis relance Monteur. Pense ensuite à cliquer sur ↻ sous l'extension dans `chrome://extensions`.

> Pour éviter que Safari crée un dossier « monteur 2 » : Safari → Réglages → Général → décoche
> « Ouvrir automatiquement les fichiers jugés fiables ».

## Lancer

Double-clique sur **Lancer.command**, puis ouvre **http://localhost:8501 dans Chrome** — l'extension de sélection
n'existe que là. Garde la fenêtre Terminal ouverte tant que tu utilises Monteur.

---

## 🎞️ Bibliothèque vidéo

### 📹 Extraire des vidéos depuis des pages internet

En haut de l'onglet, le même fonctionnement que pour les quotes :

1. Colle les liens → **Ajouter** : le lien d'**un post précis** part directement au téléchargement (dossier
   choisi juste au-dessus) ; le lien d'**un compte** s'ajoute à la liste, puis **Ouvrir ↗** l'affiche dans Chrome.
2. La page s'ouvre dans Chrome avec une case sur chaque post : **clic** = cocher, **cliquer-glisser** = rectangle,
   **Alt + glisser** = décocher, **Tout cocher** = tous les posts chargés.
3. Choisis où ranger les vidéos (🤖 automatique, 📥 à classer, ou un dossier thème) → **Envoyer à la bibliothèque**.
4. Le suivi (en attente, téléchargée, échec) est dans le même encadré, à droite, et **se met à jour tout seul** :
   les vidéos apparaissent dans les dossiers sans rien actualiser. **Réessayer** relance les échecs.
5. **Refaire le téléchargement d'un post déjà pris** : sélectionne-le quand même (ou clic droit dessus) ; Monteur
   demande confirmation (*« Ce post a déjà été pris. Le retélécharger ? »* → **Oui, retélécharger**).

Les posts déjà pris portent un badge : ⏳ en cours · ✓ bibliothèque · ★ déjà utilisée · ✖ échec.
Astuce : clic droit sur n'importe quel post → **Monteur → Ajouter ce post**.

> Instagram demande presque toujours d'être connecté : ⚙️ Réglages → *Navigateur où tu es connecté* → **chrome**.
> macOS demande alors l'accès au trousseau **une seule fois** : saisis ton mot de passe Mac et clique sur
> « Toujours autoriser ». Les cookies sont ensuite gardés dans `donnees/cookies.txt` et réutilisés.
> Si les téléchargements échouent après une reconnexion à Instagram : ⚙️ Réglages → **Relire les cookies du navigateur**.

### Les dossiers

- Un **dossier par thème**. **➕ Créer le thème** (colonne de gauche, dans la Bibliothèque **ou** dans les
  Captions) le crée partout d'un coup : dossier de bibliothèque, thème de captions et dossier du centre de
  contrôle. Tu peux aussi créer les dossiers dans le Finder (`bibliotheque/`) : ils apparaissent ici.
- **✏️ Renommer** (même colonne, dans l'un ou l'autre onglet) change le nom partout en même temps : dossier
  de vidéos, captions et centre de contrôle. Si ton Google Sheet garde encore l'ancien nom d'onglet, Monteur
  fait le lien tout seul et ne recrée pas l'ancien thème.
- **📥 À classer** : vidéos sans thème. Bouton **Classer automatiquement** (mots-clés de chaque dossier),
  ou bouton de suggestion sous chaque vidéo, ou **Ranger dans…** une fois la vidéo ouverte.
- Les vidéos s'affichent comme sur un profil Instagram : **toutes au même format 4:5**, trois par ligne.
  **▶ Lire** joue la vidéo dans sa case (et donne accès au post d'origine, au rangement et à la suppression) ;
  **⏹ Fermer** revient à la vignette.
- Coche des vidéos pour les **déplacer**, les **supprimer** ou les remettre en « non utilisée »
  (**↺ Non utilisées**, dans la barre d'actions). **☑️ Tout cocher** devient **⬜ Tout décocher** quand tout
  est coché.
- Badge **✎ Caption à l'image** sur les vidéos qui portent **déjà une phrase incrustée**. Le bouton
  **🔎 Analyser les vidéos** (barre d'actions) lit quelques images de chaque vidéo : il y repère les
  captions incrustées **et** ce que la vidéo montre (utilisé pour assortir les quotes en série) ; sans rien cocher il analyse celles qui ne l'ont jamais été, et sur une sélection il
  refait l'analyse. Le verdict est gardé, et se corrige à la main (**✎ A une caption** / **∅ Pas de
  caption**) en ouvrant la vidéo avec ▶ Lire.
  En ouvrant une vidéo avec ▶ Lire, la ligne **👁 Reconnu à l'image** montre ce que Monteur y a vu.
- Badge **● Non utilisée / ★ Utilisée** sur chaque vidéo, et sous chaque vignette un bouton
  **↺ Marquer non utilisée** / **★ Marquer utilisée** : une vidéo non utilisée revient dans le tirage au
  sort et dans le montage en série ; une vidéo utilisée est mise de côté.
  Bouton **✂️ Monter** → ouvre la vidéo dans Post montage.
- Le **nom du thème choisi** est affiché dans un champ de la colonne de gauche : corrige-le et clique sur
  **✏️ Renommer**, sans rien ouvrir. Les mots-clés du classement automatique et la suppression sont juste
  en dessous, dans ⚙️.

## 💬 Captions

- Les quotes classées par thème (mêmes thèmes que la bibliothèque).
- Ajoute-en en collant une phrase par ligne, modifie-les dans le tableau, puis **Enregistrer**.
- La liste se met à jour **toute seule** : nouvelles phrases du Google Sheet, quotes extraites de visuels,
  modifications faites dans un autre onglet. Pas besoin de cliquer sur *Synchroniser maintenant*
  (le bouton reste là si tu veux forcer une lecture immédiate du Sheet).
- **Supprimer une caption** (sélectionne la ligne puis 🗑) est appliqué immédiatement et définitivement :
  elle ne revient pas à la synchronisation suivante, même si elle est toujours dans le Google Sheet.
- Tout se modifie dans le tableau : le texte, l'**auteur** et le **thème** (changer le thème déplace la quote).
  🆕 = arrivée depuis ta dernière ouverture de Monteur · ⚠️ = lecture incertaine, à relire (décoche « À vérifier »).

### 📸 Extraire des quotes depuis des visuels

1. En haut de l'onglet Captions, colle des liens → **Ajouter** :
   - **lien d'un post précis** (reel, post Instagram, vidéo TikTok, épingle Pinterest, Short) → Monteur lit sa
     quote tout de suite, sans passer par Chrome ni par une case à cocher. Choisis le thème juste au-dessus ;
   - **lien d'une page à explorer** (compte, tableau Pinterest, recherche Google Images, article…) → la page
     s'ajoute à la liste, puis **Ouvrir ↗** l'affiche dans Chrome avec une case sur chaque visuel.
2. La page s'ouvre dans Chrome avec une case sur chaque image et vidéo : **clic** = cocher, **cliquer-glisser** =
   rectangle, **Alt + glisser** = décocher, **Tout cocher** = tous les visuels chargés.
3. Choisis le thème (🤖 automatique, 📥 à classer ou un thème) → **Extraire les quotes**.
4. Monteur lit le texte (reconnaissance de texte du Mac, gratuite et locale), enlève @compte, filigranes et
   éléments d'interface, sépare l'auteur (« — Nom ») et ajoute la quote au thème. Pas de doublon, même avec une
   ponctuation différente.

- **Vidéo** : plusieurs images de la vidéo sont lues, la quote qui revient le plus est gardée. Si rien n'est
  lisible, Monteur recommence avec deux fois plus d'images, agrandies (phrase affichée une seconde, petits
  caractères). En dernier recours, il lit la **photo de l'écran** prise au moment de la sélection — utile
  quand Instagram refuse le téléchargement.
- **Carrousel Instagram** : toutes les images sont lues, une quote par image.
- **Refaire la lecture d'un visuel déjà pris** : sélectionne-le quand même (ou clic droit dessus) ; Monteur
  demande confirmation (*« Ce visuel a déjà été pris. Refaire la lecture ? »* → **Oui, relire**) et le relit.
  Sans cette confirmation, rien n'est relu : les visuels déjà pris restent ignorés.
- **Un reel / un post ouvert tout seul** (pas de case affichée) : bouton **Prendre cette page** dans la barre
  Monteur — il prend le post affiché sans passer par une case. Ou clic droit sur la vidéo.
- **Clic droit** sur n'importe quelle image de n'importe quel site → *Monteur → Extraire la quote de ce visuel*.
  Ou icône 🎬 → *Choisir des visuels pour leurs quotes* sur la page en cours.
- Une image qu'on ne peut pas télécharger est photographiée telle qu'elle s'affiche à l'écran.
- Thème 🤖 automatique : d'après les mots-clés du thème (⚙️ dans la Bibliothèque) et les quotes déjà rangées.
  S'il hésite, la quote va dans **📥 À classer**.
- Le suivi (en cours, ajoutée, déjà présente, pas de texte, échec) est dans le même encadré ; **Réessayer**
  relance les échecs. Sur la page, les visuels déjà pris portent un badge.
- Google Images : les vignettes sont petites ; pour une meilleure lecture, ouvre l'image puis clic droit dessus.
- Colonne **Utilisée** : cochée automatiquement à l'export (avec la date et la vidéo).
- **Remettre des captions en circulation** : coche-les dans la colonne **✓** (première colonne du tableau —
  **☑️ Tout cocher** sous le tableau les coche toutes, et les décoche au second clic),
  puis **↺ Marquer non utilisée(s)**. Elles seront de nouveau proposées par *Importer une quote* et par le
  montage en série. **★ Marquer utilisée(s)** fait l'inverse : il met des captions de côté sans les supprimer.
  Les deux boutons agissent tout de suite, sans passer par *Enregistrer*.
- **Google Drive** : colle le lien de ton Google Sheet (un onglet par thème, partagé « Tous les utilisateurs
  disposant du lien → Lecteur »). Monteur le relit tout seul toutes les 2 minutes et range les nouvelles phrases
  dans le thème qui porte le nom de l'onglet. **Un onglet dont le thème n'existe pas encore crée ce thème**
  (dossiers de bibliothèque et de centre de contrôle compris).
  Les phrases peuvent être dans n'importe quelle colonne ; les lignes vides et un éventuel en-tête sont ignorés.
  Les doublons ne sont jamais réimportés, et cocher « Utilisée » ici n'efface rien dans le Sheet.
  Le Sheet fait référence : **une caption supprimée dans le Sheet est aussi retirée de Monteur**, et un texte
  corrigé est mis à jour. Ce qui est fait dans Monteur est respecté : une phrase du Sheet **réécrite** ou
  **déplacée** dans un autre thème le reste, une phrase **supprimée** dans Monteur n'est pas réimportée, et les
  quotes capturées ou ajoutées à la main ne sont jamais retirées par la synchronisation. Deux garde-fous : les captions déjà utilisées sont conservées (option *Garder les
  captions déjà utilisées*), et un onglet entièrement vidé ne supprime rien, par sécurité.
  Option *Recopier fidèlement le Sheet* à désactiver si tu préfères que Monteur se contente d'ajouter.

## 🎵 Audios

Une banque d'audios commune : des **morceaux entiers** d'un côté, les **extraits** rangés par artiste de l'autre.

### Déposer un morceau

**🎵 Déposer des morceaux** (en haut) : .mp3, .m4a, .aac, .wav, .aiff, .flac, .ogg. Ils arrivent dans
**🎧 Morceaux complets**. Tu peux aussi les glisser dans le dossier `audios/_morceaux` de Monteur.

### Découper un extrait

1. Dans **🎧 Morceaux complets**, bouton **✂️ Découper un extrait** sur le morceau voulu.
2. La **forme d'onde** s'affiche avec une fenêtre de **30 secondes** par défaut : tire la **poignée rouge de
   gauche** pour placer le début, celle de **droite** pour la durée. La partie gardée reste en clair.
3. **▶ Écouter l'extrait** part **toujours de la poignée de gauche** et joue la sélection en boucle — au repos,
   la tête de lecture est posée sur cette poignée.
4. Mets en **pause** où tu veux : la tête de lecture (trait blanc) reste sur place. **⏱ Début ici** amène la
   poignée de gauche dessus, **⏱ Fin ici** fait de même à droite, et **⏮ Revenir au début** replace la tête
   sur la poignée de gauche.
5. Les deux minuteurs **Début (s)** et **Fin (s)** se règlent **au centième de seconde** (flèches ou saisie
   directe) — c'est la façon la plus précise de finir le calage. La durée de l'extrait s'affiche à côté.
6. Donne un **nom** à l'extrait, choisis le **dossier artiste** où le ranger, puis **✂️ Créer l'extrait**.
   *Fondus* (décoché par défaut) ajoute un fondu d'entrée et de sortie dont tu règles la durée juste à côté.
7. Après la création, la fenêtre de découpe **avance toute seule** juste après l'extrait précédent, de la même
   durée : tu peux enchaîner les extraits d'un même morceau sans rien régler.

Les extraits sont encodés en .m4a, le morceau d'origine n'est pas touché.

### Les dossiers artistes

- **➕ Créer le dossier** dans la colonne de gauche : un dossier par artiste, comme les thèmes de la
  bibliothèque mais aux noms des artistes.
- **✏️ Renommer** et **🗑 Supprimer ce dossier** (il doit être vide) juste en dessous.
- Dans un dossier artiste : chaque extrait s'écoute, se **renomme**, se **déplace** vers un autre artiste
  (*Ranger chez…*) ou se supprime.

### S'en servir

Dans **✂️ Post montage** : section *4 · Audio* → **Artiste** puis **Extrait**, pour une vidéo ; et
*Audio de la série* pour poser le même extrait sur tout un montage en série. Tu règles le volume ; par défaut
l'extrait **remplace** le son de la vidéo, l'option *Garder aussi le son d'origine* les mélange. L'extrait se
répète s'il est plus court que la vidéo et se coupe à la fin de la vidéo s'il est plus long, et **l'aperçu le
fait entendre**.

Avec un dossier commun réglé, toute la banque est **partagée** : tout le monde a les mêmes extraits.
Une mise à jour de Monteur ne touche jamais à ta banque.

## ✂️ Post montage

1. Choisis le **thème des vidéos** et le **thème des captions** — deux listes séparées, pour associer
   une vidéo d'un thème à une quote d'un autre quand tu veux. Puis la vidéo : **🖼️ Choisir la vidéo**
   ouvre la galerie de miniatures, **🎲 Vidéo au hasard** en prend une non utilisée.
   C'est le **thème des vidéos** qui décide du sous-dossier d'export ; la quote, elle, est marquée
   « utilisée » dans son propre thème.
2. **📱 Plein écran 9:16** recadre en 1080×1920 ; désactivé, le format d'origine est gardé.
3. **🧽 Enlever le logo / tag** détecte les éléments incrustés fixes et les floute ou les efface
   (zones ajustables à la main).
4. **💬 Importer une quote** prend une caption non utilisée du thème, au hasard. **💬 Choisir la
   caption** ouvre la liste des quotes libres : leur texte, leur visuel d'origine s'il y en a un, et
   une **note d'affinité** avec la vidéo en cours — les mieux assorties sont proposées en premier
   (passe **🔎 Analyser les vidéos** dans la Bibliothèque pour que la note existe). Un champ de
   recherche filtre la liste. Le texte reste modifiable.
   Si la vidéo porte déjà une phrase incrustée, un avertissement **✎** te le rappelle : laisse le texte
   vide pour ne pas en superposer une deuxième.
5. Style : typo (**🔤 Ajouter des typos** pour importer tes .ttf), taille, casse (ABC / abc), alignement,
   **Contour** (Sans / Fin / Moyen / Épais) et **Bandeau** (Sans / Translucide / Plein) — leurs couleurs sont
   les sélecteurs juste au-dessus. Dans le repli : ombre, marge du bandeau, interligne, apparition, largeur
   du bloc.

**L'aperçu est l'éditeur** :

- **glisse la quote** avec la souris pour la placer ; elle suit le curseur et s'aimante au centre,
  avec un repère rouge quand elle est centrée en largeur ou en hauteur ;
- les **repères de sécurité** sont affichés d'office : les zones que TikTok et Reels recouvrent de
  leur interface. Sur un 1080×1920 : **160 px en haut** (nom d'utilisateur, son), **480 px en bas**
  (boutons, légende, appel à l'action — d'autant plus haut que la légende est longue) et **120 px de
  chaque côté** (j'aime, commentaires, partage). Le cadre vert au milieu, **840 × 1280**, est la zone
  où une caption reste lisible pour
  tout le monde — et la quote **ne peut plus en sortir** : elle s'arrête au bord, aussi bien quand tu
  la déplaces qu'à l'export. Le bouton **⌗** en haut à droite masque les repères si tu veux voir
  l'image nue ; ils ne sont de toute façon jamais exportés ;
- le bouton **▶** lit la vidéo (barre d'espace aussi) ; la lecture boucle sur l'extrait choisi ;
- la **frise de vignettes** sous l'image montre toute la vidéo : clique ou glisse dedans pour te déplacer,
  et tire les **poignées rouges** des deux côtés pour ne garder qu'un extrait — l'aperçu suit aussi les
  poignées, tu vois donc exactement sur quelle image commence et finit l'extrait ;
- les **sélecteurs de couleur** (texte, contour, bandeau), dans la colonne de gauche, mettent l'aperçu
  à jour en direct.

L'export est toujours en **9:16**. Une vidéo qui n'est pas déjà à ce format (16:9, 4:5, carrée…) propose
deux cadrages, juste sous *Plein écran 9:16* :

- **Entière, bandes noires** (par défaut) : toute l'image est gardée, entre deux bandes ;
- **Agrandie plein écran** : l'image est agrandie pour remplir le 9:16. Le bouton **✥** en haut de l'aperçu
  passe en mode cadrage : **glisse l'image latéralement** pour choisir la partie visible (le pourcentage
  s'affiche sous l'aperçu). Le bouton **T** revient au déplacement de la quote.

Une vidéo déjà en 9:16 remplit l'écran sans réglage.

6. **🎵 Audio** (section 4) : choisis l'**artiste** puis l'**extrait** dans la banque (onglet **🎵 Audios**),
   et son volume. Par défaut il **remplace** le son de la vidéo ; coche *Garder aussi le son d'origine* pour
   les mélanger. Sans extrait choisi, rien ne change.
   **L'extrait se cale tout seul sur la vidéo** : il démarre à son début, se **répète** s'il est plus court
   que la vidéo, et se **coupe** à la fin de la vidéo s'il est plus long. L'aperçu de droite **le fait
   entendre** : appuie sur ▶, tu as l'image et le son tels qu'ils seront exportés.
7. **📤 Exporter la vidéo** → rangée dans `centre_de_controle/<thème>/`, vidéo et quote marquées « utilisées ».
   **➡️ Vidéo suivante** pour enchaîner.

### ⚡ Monter en série

En bas de l'onglet : plusieurs montages d'un coup, à partir des vidéos **non utilisées** du thème.
Deux choix décident de la forme, tout le reste s'y applique.

**1 · Rythme** — *Pas calé sur le rythme* : les coupes sont régulières (ou la vidéo est gardée
entière). *Calé sur le rythme* : Monteur écoute l'extrait audio choisi plus bas, y trouve le **tempo**
et pose les coupes sur les temps.

**2 · Montage** — *Mélanger les rushs du thème* : chaque export pioche ses plans dans plusieurs vidéos
du thème, dans le désordre. *Remonter vidéo par vidéo* : un export par vidéo.

Ce que donnent les quatre combinaisons :

| | Mélanger les rushs du thème | Remonter vidéo par vidéo |
|---|---|---|
| **Pas calé** | un montage multi-plans, coupes régulières | la vidéo entière + sa caption |
| **Calé sur le rythme** | un montage multi-plans sur les temps | chaque vidéo redécoupée en ses rushs, sur les temps |

Les réglages communs :

- **Nombre de montages** (mélange) ou **Nombre de vidéos** (vidéo par vidéo), et **Logo** (ne pas
  toucher / détecter + flouter / détecter + effacer — seulement quand les vidéos restent entières).
- **Captions : Avec / Sans**. *Sans caption* ne consomme aucune quote du thème.
- **Changer de plan** quand c'est calé : à chaque temps, tous les 2, tous les 4, ou **sur les accents**
  (les attaques réellement entendues). **Plan le plus court / le plus long** encadrent la durée d'un
  plan. Sans rythme : **Durée d'un plan** et **Durée du montage** (cette dernière ignorée si un audio
  est choisi, c'est alors sa durée qui fait loi).
- **Habillage des captions** : un ou plusieurs **styles enregistrés** (couleur, contour, typo, taille)
  croisés avec un ou plusieurs **emplacements** (⬆ Haut · ⬛ Milieu · ⬇ Bas), répartis **au hasard** ou
  **à tour de rôle**. Listes vides = le style réglé au-dessus, à sa position.
- **Assortir la caption à ce que montre la vidéo** (vidéo par vidéo seulement) : au lieu de tirer au
  hasard, Monteur compare les thèmes de chaque quote à ce qu'il reconnaît dans la vidéo — ce que le Mac
  voit à l'image, le texte déjà incrusté, la description du post d'origine. La répartition se fait
  **sur toute la série d'un coup**, en commençant par les meilleures affinités : la quote « océan » va
  à la vidéo qui montre le plus l'océan, pas à la première qui l'effleure. Quand **aucune quote ne
  colle**, tu choisis : *monter sans texte* (par défaut) ou *mettre une quote au hasard*. Le journal
  donne la note de chaque association. C'est un rapprochement par champs de sens, pas une compréhension
  fine : l'ironie et les métaphores lui échappent.
- **Écarter les vidéos qui ont déjà une caption à l'image** (actif par défaut) : elles sont montées
  sans texte par-dessus (vidéo par vidéo) ou laissées de côté (mélange), et aucune quote n'est gaspillée.
- **Format** : tout sort en **9:16 (1080×1920)**. Une vidéo déjà verticale est gardée telle quelle ;
  une vidéo d'un autre format est **centrée en hauteur et en largeur**, et complétée par des bandes
  noires là où il faut. La caption se place dans ce 9:16, bandes comprises.
- **Audio** : le même extrait (artiste → extrait) posé sur tous les montages. Obligatoire pour un
  montage calé sur le rythme ; sa durée devient celle du montage. **✂️ Raccourcir l'extrait** affiche
  sa forme d'onde avec deux poignées : tu ne gardes que le passage voulu, et c'est cette durée-là qui
  fait le montage. Les minuteurs en dessous se règlent au centième de seconde, et le zoom 🔍 fonctionne
  comme dans l'onglet Audios. Rien n'est ajouté à ta banque : l'extrait d'origine n'est pas touché.
- **Marquer les vidéos comme utilisées** (mélange) : décoché par défaut, puisqu'un mélange pioche dans
  toutes les vidéos du thème — sinon le premier montage viderait le stock.

Quand les vidéos sont redécoupées, les plans sont **mélangés** et chacun est pris au hasard : deux
montages d'affilée ne donnent jamais le même résultat. En *vidéo par vidéo*, le montage ne **commence
ni ne finit jamais sur le plan qui ouvre ou ferme la vidéo d'origine** : on ne reconnaît pas le
montage de départ à ses deux bouts. En *vidéo par vidéo*, les **plans séquences**
(aucune coupe à l'intérieur) sont écartés et signalés dans le journal : il n'y a rien à y remonter.
Le son des vidéos n'est pas gardé dans les montages multi-plans — c'est l'audio choisi qu'on entend.
La première fois, Monteur repère les coupes de chaque vidéo : compte quelques secondes par vidéo
(**🔎 Analyser les vidéos** dans la Bibliothèque le fait en avance).

Tout en bas de l'onglet, **📂 Ouvrir le dossier des vidéos exportées** ouvre le centre de contrôle dans le
Finder, avec son sous-dossier par thème.

## 📂 Centre de contrôle

```
centre_de_controle/
  motivation/20261009-163600_TikTok_123.mp4    ← uniquement les vidéos, rangées par thème
  humour/20261009-171200_reel_456.mp4
  _fiches/
    index.json / index.csv                     ← toutes les vidéos prêtes (thème, caption, statut…)
    motivation/20261009-163600_TikTok_123.json ← fiche : caption, vidéo d'origine, statut "pret"
```
Les sous-dossiers de thèmes ne contiennent **que des .mp4** : les fiches et les index sont à part, dans
`_fiches`. Les fiches des versions précédentes y sont rangées toutes seules au premier export (ou en
cliquant sur **📂 Ouvrir le dossier des vidéos exportées** dans Post montage).
Le dossier est réglable dans ⚙️ Réglages (par ex. un dossier Google Drive partagé).

---

## Extension Chrome (une fois)

1. Chrome → `chrome://extensions` → active **Mode développeur**.
2. **Charger l'extension non empaquetée** → dossier `monteur/extension-chrome`.
3. Épingle l'icône 🎬. Après une mise à jour de Monteur : bouton ↻ sous l'extension.

## Droits

Ne republie que des vidéos que tu as le droit d'utiliser (tes contenus ou avec l'accord du créateur).
Retirer le logo d'un créateur tiers pour republier expose à des retraits pour droit d'auteur, et TikTok
limite les comptes qui republient du contenu non original.

## Dépannage

- **Rien ne se télécharge** → Réglages → navigateur connecté ; relance Lancer.command (met yt-dlp à jour).
- **L'extension dit « Logiciel non lancé »** → ouvre Lancer.command.
- **Les cases n'apparaissent pas** → recharge la page du compte, ou icône 🎬 → *Sélectionner des posts*.
- **Polices** : ⚙️ Réglages → *Ajouter des polices*, ou celles installées sur le Mac.
