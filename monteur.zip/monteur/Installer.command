#!/bin/bash
# Installation de Monteur (à lancer une seule fois) — double-clic, ou clic droit > Ouvrir
cd "$(dirname "$0")"
echo "=== Installation de Monteur ==="
if ! command -v brew >/dev/null 2>&1; then
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$($b shellenv)"; done
fi
if ! command -v brew >/dev/null 2>&1; then
  echo "→ Installation de Homebrew (gestionnaire de logiciels pour Mac, ton mot de passe Mac peut être demandé)"
  /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
  for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$($b shellenv)"; done
fi
echo "→ Installation de ffmpeg et Python"
brew install ffmpeg python@3.12
PY="$(brew --prefix)/bin/python3.12"
[ -x "$PY" ] || PY=python3
echo "→ Création de l'environnement Python"
[ -x .venv/bin/python ] || "$PY" -m venv .venv
.venv/bin/python -m pip install --upgrade pip
if ! .venv/bin/python -m pip install -r requirements.txt; then
  echo ""
  echo "❌ L'installation des modules Python a échoué (voir le message ci-dessus)."
  echo "   Envoie une capture de cette fenêtre à Claude."
  read -n 1 -s -r -p "Appuie sur une touche pour fermer…"; exit 1
fi
chmod +x Lancer.command 2>/dev/null
echo ""
echo "✅ Installation terminée. Double-clique sur Lancer.command pour ouvrir Monteur."
echo "   Puis installe l'extension Chrome : voir LISEZMOI.md (section Extension)."
read -n 1 -s -r -p "Appuie sur une touche pour fermer…"
