"""Interface Monteur — lancer avec Lancer.command (ou : streamlit run app.py)."""
from __future__ import annotations

import base64
import datetime as dt
import hashlib
import html as html_lib
import io
import json
import os
import random
import shutil
import subprocess
import sys
import time
import urllib.parse
from pathlib import Path

import pandas as pd
import streamlit as st
from PIL import Image, ImageDraw

from monteur import bibliotheque as B
from monteur import captions as C
from monteur import (acces, assortir, audios, config, maj, ocr, paroles, partage, postmontage,
                     quotes, recepteur, telechargement, zones)
from monteur.logo import detecter
import streamlit.components.v1 as composants_st
from composants.editeur import editeur, editeur_paroles, nuancier, onde, typos

composant_html = composants_st.html
from monteur.rendu import (apercu, dimensions_export, frise, image_texte, mesurer_bloc, meme_format,
                           polices_disponibles, sonder, vider_cache_polices)

st.set_page_config(page_title="Monteur", page_icon="🎬", layout="wide")

st.markdown("""
<style>
  .block-container {padding-top: 3.2rem; max-width: 1400px;}
  .badge {display:inline-block; padding:2px 8px; border-radius:6px; font-size:12px; font-weight:600; color:#fff;}
  .b-libre {background:#138a4b;} .b-utilisee {background:#6d3fd6;} .b-attente {background:#e08a00;}
  .b-erreur {background:#c62828;} .b-gris {background:#6b7280;}
  .petit {font-size:12px; color:#6b7280; line-height:1.3; overflow:hidden; text-overflow:ellipsis; white-space:nowrap;}
  /* pastille « ? » : l'explication se dévoile au survol, elle n'encombre plus la page */
  .aide {display:inline-flex; align-items:center; justify-content:center; width:16px; height:16px;
         border:1px solid #8b8d98; border-radius:50%; color:#8b8d98; font-size:11px; font-weight:700;
         line-height:1; cursor:help; vertical-align:middle; margin-left:6px; user-select:none;}
  .aide:hover {border-color:#ff2d55; color:#ff2d55;}
  /* barres d'actions : le compteur de sélection et le texte d'état */
  .choisies {font-size:15px; font-weight:700; color:#ff2d55; padding:7px 0 0; text-align:right;}
  .etat-barre {font-size:12.5px; color:#8b8d98; padding:9px 0 0; line-height:1.35;}
  /* pastilles d'état : le détail se lit au survol, le bandeau ne mange plus la page */
  .pastille {display:inline-flex; align-items:center; gap:6px; padding:4px 10px; border-radius:999px;
             font-size:12.5px; font-weight:600; cursor:help; border:1px solid transparent;}
  .pastille.ok {color:#2fa968; background:rgba(47,169,104,.12); border-color:rgba(47,169,104,.35);}
  .pastille.souci {color:#e08a00; background:rgba(224,138,0,.12); border-color:rgba(224,138,0,.4);}
  /* étapes de Post montage : un numéro, un titre, et de l'air avant chacune */
  .etape {display:flex; align-items:center; gap:8px; margin:26px 0 8px; font-size:16px; font-weight:700;
          border-top:1px solid rgba(139,141,152,.28); padding-top:16px;}
  .etape .num {display:inline-flex; align-items:center; justify-content:center; width:22px; height:22px;
               flex:0 0 22px; border-radius:50%; background:#ff2d55; color:#fff; font-size:12.5px;}
  /* une seule échelle de titres sur les cinq onglets, et de l'air entre les sections */
  div[data-testid="stMarkdownContainer"] h3 {font-size:1.35rem; margin:.1rem 0 .5rem;}
  div[data-testid="stMarkdownContainer"] h4 {font-size:1.05rem; margin:.9rem 0 .45rem;}
  div[data-testid="stVerticalBlockBorderWrapper"] h4:first-child {margin-top:0;}
  div[data-testid="stImage"] img {border-radius:8px;}
  /* grille façon profil Instagram : toutes les vignettes au même format 4:5 */
  .tuile {width:100%; aspect-ratio:4/5; overflow:hidden; border-radius:8px; background:#15161a;
          display:block; margin-bottom:6px;}
  .tuile img {width:100%; height:100%; object-fit:cover; display:block;}
  /* encadré d'extraction mis en valeur (quotes, vidéos) */
  .vedette {display:none;}
  .st-key-bloc_quotes details, .st-key-bloc_videos details,
  div[data-testid="element-container"]:has(.vedette) + div details {border:2px solid #ff2d55 !important; border-radius:12px;}
  .st-key-bloc_quotes summary, .st-key-bloc_videos summary,
  div[data-testid="element-container"]:has(.vedette) + div summary {background:#ff2d55 !important; border-radius:9px;}
  .st-key-bloc_quotes summary p, .st-key-bloc_videos summary p,
  .st-key-bloc_quotes summary svg, .st-key-bloc_videos summary svg,
  div[data-testid="element-container"]:has(.vedette) + div summary p,
  div[data-testid="element-container"]:has(.vedette) + div summary svg {color:#fff !important; fill:#fff !important;}
  .st-key-bloc_quotes summary p, .st-key-bloc_videos summary p,
  div[data-testid="element-container"]:has(.vedette) + div summary p {font-size:1.05rem; font-weight:700;}
</style>""", unsafe_allow_html=True)


@st.cache_resource
def _recepteur():
    return recepteur.demarrer()  # écoute l'extension Chrome sur 127.0.0.1:8765


@st.cache_resource
def _sync_captions():
    # relit le Google Sheet en arrière-plan et range les nouvelles phrases par thème
    return C.demarrer_sync_auto(config.charger)


@st.cache_resource
def _quotes_en_attente():
    # visuels envoyés pendant que Monteur était fermé : on reprend leur lecture
    return quotes.lancer_en_fond(config.charger)


_recepteur()
_sync_captions()
_quotes_en_attente()

if "cfg" not in st.session_state:
    st.session_state.cfg = config.charger()
cfg = st.session_state.cfg


def _ecran_acces(verdict: dict):
    """Première ouverture (saisie de la clé) ou accès fermé : rien d'autre ne s'affiche."""
    st.markdown("### 🎬 Monteur")
    gauche, _ = st.columns([2, 1])
    with gauche:
        if verdict["etat"] == "sans_cle":
            st.info("**Première ouverture.** Entre la clé d'accès qui t'a été transmise.", icon="🔑")
        else:
            st.error(verdict.get("message") or "Accès fermé.", icon="🔒")
            if verdict["etat"] in ("revoque", "expire", "inconnue"):
                st.caption("Tes fichiers restent sur ton ordinateur. Pour rouvrir l'accès, demande une "
                           "nouvelle clé à la personne qui t'a transmis Monteur.")
        with st.form("form_acces", clear_on_submit=False):
            saisie = st.text_input("Clé d'accès", placeholder="MNT-XXXX-XXXX-XXXX",
                                   help="Les majuscules et les tirets n'ont pas d'importance.")
            if st.form_submit_button("Ouvrir Monteur", type="primary"):
                r = acces.essayer(cfg, saisie)
                if r["autorise"]:
                    st.rerun()
                else:
                    st.error(r.get("message") or "Clé refusée.")
        st.caption("Monteur vérifie la clé sur Internet au lancement. Une connexion est nécessaire la "
                   "première fois.")


acces.verifier_en_fond(cfg)
_acces = acces.etat(cfg)
if not _acces["autorise"]:
    _ecran_acces(_acces)
    st.stop()

partage.appliquer(cfg)        # contenus communs (dossier partagé) avant toute lecture de fichiers
maj.verifier_en_fond(cfg)     # y a-t-il une nouvelle version ? (une fois par lancement, en arrière-plan)
B.synchroniser(cfg)


def sauver(msg="Enregistré"):
    config.sauver(cfg)
    st.toast(msg, icon="💾")


def ouvrir_finder(p: Path):
    p.mkdir(parents=True, exist_ok=True)
    if sys.platform == "darwin":
        subprocess.run(["open", str(p)])
    else:
        st.info(str(p))


def themes() -> list[str]:
    return B.themes(cfg)


P_BIBLIO, P_CAPTIONS, P_AUDIOS, P_MONTAGE, P_REGLAGES = (
    "🎞️ Bibliothèque vidéo", "💬 Captions", "🎵 Audios", "✂️ Post montage", "⚙️ Réglages")
PAGES = [P_BIBLIO, P_CAPTIONS, P_AUDIOS, P_MONTAGE, P_REGLAGES]
if "page" not in st.session_state:
    st.session_state.page = PAGES[0]


def bloc_nouveau_theme(prefixe: str):
    """Créer un thème (dossier bibliothèque + centre de contrôle + captions) depuis n'importe quel onglet."""
    with st.form(f"nouveau_theme_{prefixe}", clear_on_submit=True, border=False):
        nt = st.text_input("Nouveau thème", placeholder="ex. cuisine",
                           help="Le thème est créé partout : Bibliothèque vidéo, Captions et centre de contrôle.")
        if st.form_submit_button("➕ Créer le thème") and nt.strip():
            try:
                st.session_state.theme_choisi = B.creer_theme(cfg, nt)
                st.toast(f"Thème « {nt.strip()} » créé", icon="📁")
                st.rerun()
            except ValueError as e:
                st.error(str(e))


def bloc_renommer_theme(theme: str, prefixe: str):
    """Renommer le thème choisi, régler ses mots-clés, le supprimer. Vit dans « Gérer les dossiers »."""
    with st.form(f"renommer_{prefixe}_{theme}", clear_on_submit=False, border=False):
        nouveau = st.text_input("Renommer « " + theme + " »", value=theme, key=f"ren_{prefixe}_{theme}",
                                help="Le nom change partout : Bibliothèque vidéo, Captions et centre de "
                                     "contrôle.")
        if st.form_submit_button("✏️ Renommer", use_container_width=True):
            n = (nouveau or "").strip()
            if n and n != theme:
                try:
                    n = B.renommer_theme(cfg, theme, n)
                    st.session_state.theme_choisi = n   # appliqué avant les boutons radio, au prochain affichage
                    st.toast(f"Thème renommé en « {n} »", icon="✏️")
                    st.rerun()
                except ValueError as e:
                    st.error(str(e))
    mc = st.text_input("Mots-clés du classement automatique",
                       ", ".join(cfg["themes"].get(theme, {}).get("mots_cles", [])),
                       key=f"mc_{prefixe}_{theme}", placeholder="séparés par des virgules",
                       help="Cherchés dans le titre, la description et les hashtags des posts téléchargés.")
    if st.button("💾 Enregistrer les mots-clés", key=f"svmc_{prefixe}_{theme}", use_container_width=True):
        cfg["themes"].setdefault(theme, {})["mots_cles"] = [m.strip() for m in mc.split(",") if m.strip()]
        sauver()
    with st.popover("🗑 Supprimer ce thème", use_container_width=True):
        st.write(f"Supprimer **{theme}** ? Ses vidéos repassent dans **À classer**, ses captions sont "
                 "conservées.")
        if st.button("Oui, supprimer", key=f"supth_{prefixe}_{theme}", type="primary"):
            B.supprimer_theme(cfg, theme)
            st.session_state.theme_choisi = B.A_CLASSER
            st.rerun()


def bloc_gerer_dossiers(prefixe: str, theme: str, racine: str, a_classer: str):
    """Un seul encadré pour créer, renommer, régler et supprimer les dossiers — la liste respire."""
    with st.expander("⚙️ Gérer les dossiers"):
        bloc_nouveau_theme(prefixe)
        if theme != a_classer:
            st.divider()
            bloc_renommer_theme(theme, prefixe)
        if racine:
            st.divider()
            if st.button("📂 Ouvrir dans le Finder", key=f"finder_{prefixe}", use_container_width=True):
                ouvrir_finder(config.chemin(cfg, racine))


def dossier_polices() -> Path:
    """Les typos vont dans le dossier commun quand il y en a un : tout le monde a les mêmes."""
    d = partage.dossier(cfg)
    if d:
        (d / "polices").mkdir(parents=True, exist_ok=True)
        return d / "polices"
    return config.chemin(cfg, "polices")


def rerun_app():
    """Recharge toute la page (depuis un fragment). `scope` n'existe pas sur les Streamlit anciens."""
    try:
        st.rerun(scope="app")
    except TypeError:
        st.rerun()


def bouton_copier(texte: str, libelle: str = "📋 Copier", hauteur: int = 46):
    """Bouton qui met le texte dans le presse-papiers au clic, sans fenêtre intermédiaire.

    Streamlit ne sait pas écrire dans le presse-papiers : on passe par un petit bouton HTML.
    `navigator.clipboard` d'abord, repli sur execCommand pour les cas où il est refusé.
    """
    charge = json.dumps(texte or "")
    nom = json.dumps(libelle)
    composant_html(f"""
<style>
  html, body {{margin:0; padding:0; background:transparent;}}
  button {{width:100%; height:38px; cursor:pointer; border-radius:.5rem; font-size:14px;
           font-weight:400; font-family:"Source Sans Pro","Segoe UI",system-ui,sans-serif;
           color:#e7e8ec; background:#17181d; border:1px solid rgba(231,232,236,.25);
           transition:border-color .15s, color .15s;}}
  button:hover {{border-color:#ff2d55; color:#ff2d55;}}
  button.ok {{border-color:#2fa968; color:#2fa968;}}
</style>
<button id="b"></button>
<script>
  const t = {charge}, nom = {nom}, b = document.getElementById("b");
  b.textContent = nom;
  b.onclick = async () => {{
    let ok = true;
    try {{ await navigator.clipboard.writeText(t); }}
    catch (e) {{
      const z = document.createElement("textarea");
      z.value = t; z.style.position = "fixed"; z.style.opacity = "0";
      document.body.appendChild(z); z.select();
      try {{ ok = document.execCommand("copy"); }} catch (_) {{ ok = false; }}
      z.remove();
    }}
    b.textContent = ok ? "\u2713 Copié" : "Copie refusée";
    b.classList.toggle("ok", ok);
    setTimeout(() => {{ b.textContent = nom; b.classList.remove("ok"); }}, 1800);
  }};
</script>""", height=hauteur)


def titre_aide(texte: str, aide: str = "", niveau: str = "####"):
    """Titre suivi d'une pastille « ? » : l'explication apparaît au survol, pas sur la page.

    `niveau` : "####" pour un titre de section, "" pour un petit intitulé en gras.
    """
    gras = "" if niveau else "**"
    bulle = (f" <span class='aide' title=\"{html_lib.escape(' '.join(str(aide).split()), quote=True)}\">?</span>"
             if aide else "")
    st.markdown(f"{niveau + ' ' if niveau else ''}{gras}{texte}{gras}{bulle}", unsafe_allow_html=True)


def etape(n: str, titre: str, aide: str = ""):
    """En-tête d'étape : un numéro en pastille, le titre, et l'explication au survol."""
    bulle = (f" <span class='aide' title=\"{html_lib.escape(' '.join(str(aide).split()), quote=True)}\">?</span>"
             if aide else "")
    puce = f"<span class='num'>{n}</span>" if n else ""
    st.markdown(f"<div class='etape'>{puce}<span>{titre}</span>{bulle}</div>", unsafe_allow_html=True)


def pastille(texte: str, ok: bool, aide: str):
    """État en une ligne : vert quand tout va bien, orange sinon. Le détail est au survol."""
    bulle = html_lib.escape(" ".join(str(aide).split()), quote=True)
    classe = "pastille ok" if ok else "pastille souci"
    st.markdown(f"<div class='{classe}' title=\"{bulle}\">{'●' if ok else '▲'} {texte}</div>",
                unsafe_allow_html=True)


def expander_vedette(titre: str, expanded: bool, cle: str):
    """Encadré mis en valeur. `key` n'existe que sur les Streamlit récents : repli sur un marqueur CSS."""
    st.markdown("<span class='vedette'></span>", unsafe_allow_html=True)
    try:
        return st.expander(f"**{titre}**", expanded=expanded, key=cle)
    except TypeError:
        return st.expander(f"**{titre}**", expanded=expanded)


def aller(page: str, **etat):
    """À utiliser en on_click : change d'onglet et prépare l'état de la page cible."""
    st.session_state.page = page
    for k, v in etat.items():
        st.session_state[k] = v


st.markdown(f"### 🎬 Monteur <span style='font-size:13px;color:#8b8d98'>v{maj.version_installee()}</span>",
            unsafe_allow_html=True)
if partage.souci():
    s1, s2 = st.columns([5, 1])
    s1.warning(partage.souci(), icon="☁️")
    if s2.button("Se détacher", use_container_width=True,
                 help="Revenir aux contenus de cet ordinateur et oublier le dossier commun"):
        cfg.setdefault("partage", {})["dossier"] = ""
        config.sauver(cfg)
        st.rerun()
_nouveau = maj.nouveaute(cfg)
if _nouveau and not st.session_state.get("maj_masquee"):
    b1, b2 = st.columns([5, 1])
    b1.info(f"**Nouvelle version disponible : {_nouveau['version']}** "
            f"(tu as la {maj.version_installee()}) — ferme la fenêtre Terminal de Monteur et double-clique sur "
            f"**Mettre-a-jour.command**." + (f"  \n{_nouveau['notes']}" if _nouveau.get("notes") else ""),
            icon="⬆️")
    if b2.button("Plus tard", use_container_width=True):
        st.session_state.maj_masquee = True
        st.rerun()
st.segmented_control("Navigation", PAGES, key="page", label_visibility="collapsed")
page = st.session_state.page or PAGES[0]
st.write("")


# ════════════════════════════════════════════ PAGES À EXPLORER ════════════════════════════════════════════

def nom_compte(url: str) -> str:
    seg = [s for s in url.split("?")[0].split("/") if s]
    return seg[-1] if len(seg) >= 3 else url


@st.fragment(run_every=4)
def _veille_videos():
    """Fait apparaître toutes seules les vidéos qui arrivent (téléchargements en cours)."""
    pr = telechargement.progression()
    file = telechargement.lire_file()
    attente = [x for x in file if x.get("statut") == "en_attente"]
    if pr["en_cours"] or attente:
        st.caption(f"⏳ Téléchargement en cours… {pr['fait']}/{pr['total'] or len(attente)} · "
                   f"{len(attente)} post(s) en attente")
    sig = telechargement.signature()
    if "vid_sig" in st.session_state and sig != st.session_state.vid_sig:
        st.session_state.vid_sig = sig
        rerun_app()


def bloc_pages_videos():
    """Pages à explorer pour les vidéos + suivi des téléchargements."""
    file = telechargement.lire_file()
    attente = [x for x in file if x.get("statut") == "en_attente"]
    erreurs = [x for x in file if x.get("statut") == "erreur"]
    titre = "📹 Extraire des vidéos depuis des pages internet"
    if attente:
        titre += f" — ⏳ {len(attente)} en cours"
    with st.container(border=True):
        titre_aide(titre, "Un post précis (reel, vidéo TikTok, Short…) part directement au téléchargement. "
                          "Une page de compte s'ajoute à la liste : Ouvrir l'affiche dans Chrome avec une case "
                          "sur chaque post — clic = cocher, cliquer-glisser = rectangle.")
        g, d = st.columns([1.15, 1], gap="large")
        with g:
            th_direct = "auto"       # classement par mots-clés, puis « À classer » si rien ne correspond
            with st.form("ajout_comptes", clear_on_submit=True):
                liens = st.text_area("Liens (un par ligne)", height=90,
                                     placeholder="https://www.instagram.com/reels/XXXXXXXX/\n"
                                                 "https://www.instagram.com/nom_du_compte/")
                if st.form_submit_button("➕ Ajouter", type="primary"):
                    connus = {c["url"].rstrip("/").lower() for c in cfg["comptes"]}
                    n, posts = 0, []
                    for l in liens.splitlines():
                        l = l.strip()
                        if not l.startswith("http"):
                            continue
                        if quotes.est_post(l):
                            posts.append(l)
                        elif l.rstrip("/").lower() not in connus:
                            cfg["comptes"].append({"nom": nom_compte(l), "url": l,
                                                   "plateforme": telechargement.plateforme(l)})
                            connus.add(l.rstrip("/").lower())
                            n += 1
                    if posts:
                        ajoutes = telechargement.ajouter_a_la_file(posts, th_direct)
                        if ajoutes:
                            st.toast(f"{ajoutes} vidéo(s) en téléchargement…", icon="⬇")
                        if ajoutes < len(posts):
                            st.session_state.videos_a_forcer = posts
                            st.session_state.videos_theme_forcer = th_direct
                    if n:
                        sauver(f"{n} page(s) ajoutée(s)")
                    if n or posts:
                        st.rerun()
            if st.session_state.get("videos_a_forcer"):
                f1, f2 = st.columns([2.2, 1])
                f1.warning(f"{len(st.session_state.videos_a_forcer)} post(s) déjà pris précédemment.", icon="↩︎")
                if f2.button("Reprendre quand même", use_container_width=True):
                    telechargement.ajouter_a_la_file(st.session_state.videos_a_forcer,
                                                     st.session_state.get("videos_theme_forcer", "auto"), force=True)
                    st.session_state.videos_a_forcer = []
                    st.rerun()
                if f2.button("Ignorer", use_container_width=True, key="ign_forcer_vid"):
                    st.session_state.videos_a_forcer = []
                    st.rerun()
            if cfg["comptes"]:
                icones = {"instagram": "📸", "tiktok": "🎵", "youtube": "▶️", "autre": "🌐"}
                with st.expander(f"📄 Pages suivies ({len(cfg['comptes'])})"):
                    for i, c in enumerate(cfg["comptes"]):
                        cle = c["url"].rstrip("/").lower()
                        pris = [x for x in file
                                if cle and (x.get("compte") or "").rstrip("/").lower().startswith(cle)]
                        ok = sum(1 for x in pris if x.get("statut") == "telecharge")
                        a, b, c3 = st.columns([3.2, 1.3, 0.5])
                        a.markdown(
                            f"{icones.get(c.get('plateforme') or telechargement.plateforme(c['url']), '🌐')} "
                            f"**{c.get('nom') or nom_compte(c['url'])}**"
                            f"<div class='petit'>{c['url']} · {ok} vidéo(s) récupérée(s)</div>",
                            unsafe_allow_html=True)
                        sep = "&" if "#" in c["url"] else "#"
                        b.link_button("Ouvrir ↗", c["url"] + f"{sep}monteur", use_container_width=True)
                        if c3.button("🗑", key=f"del_compte_{i}", help="Retirer cette page de la liste"):
                            cfg["comptes"].pop(i)
                            sauver("Page retirée")
                            st.rerun()
        with d:
            # deux pastilles d'état plutôt que deux bandeaux qui occupent le haut de la page
            nav_ok = bool((cfg["telechargement"].get("cookies_navigateur") or "").strip())
            vu = recepteur.derniere_visite_extension()
            ext_ok = bool(vu and time.time() - vu < 600)
            p1, p2, _ = st.columns([1, 1, 1.1])
            with p1:
                pastille("🔑 Navigateur", nav_ok,
                         "Connecté : les téléchargements Instagram et TikTok passent."
                         if nav_ok else
                         "Aucun navigateur choisi dans Réglages : Instagram et TikTok refuseront les "
                         "téléchargements. Va dans ⚙️ Réglages → Téléchargement.")
            with p2:
                pastille("🧩 Extension", ext_ok,
                         "Extension Chrome connectée : les cases apparaissent sur les posts."
                         if ext_ok else
                         "Extension Chrome pas encore détectée. Installe-la depuis ⚙️ Réglages, puis ouvre "
                         "les pages dans Chrome.")
            _veille_videos()
            if attente and st.button(f"⬇ Télécharger maintenant ({len(attente)})", use_container_width=True,
                                     type="primary"):
                lignes, zone = [], st.empty()

                def log(m):
                    lignes.append(m)
                    zone.code("\n".join(lignes[-30:]), language=None)
                with st.spinner("Téléchargement…"):
                    telechargement.telecharger_file(cfg, log)
                st.rerun()
            if file and not attente and not erreurs:
                st.caption(f"{sum(1 for x in file if x.get('statut') == 'telecharge')} vidéo(s) téléchargée(s) · "
                           "elles sont dans les dossiers ci-dessous.")
            if file:
                # un seul bouton : échecs, historique et ménage sont derrière
                libelle = "📜 Suivi des téléchargements" + (f"  ·  ⚠ {len(erreurs)}" if erreurs else "")
                with st.popover(libelle, use_container_width=True):
                    if erreurs:
                        if st.button(f"↻ Réessayer les {len(erreurs)} échecs", use_container_width=True):
                            telechargement.modifier_file(
                                lambda it: [{**x, "statut": "en_attente"} if x.get("statut") == "erreur" else x
                                            for x in it])
                            st.rerun()
                        for x in erreurs[:20]:
                            st.markdown(f"<div class='petit'>{(x.get('message') or 'échec')[:120]}<br>"
                                        f"<a href='{x.get('url') or ''}'>post ↗</a></div>",
                                        unsafe_allow_html=True)
                        st.divider()
                    df = pd.DataFrame(file[::-1])
                    for col in ("statut", "theme", "range_dans", "url", "message", "ajoute_le"):
                        if col not in df:
                            df[col] = ""
                    df["statut"] = df["statut"].map({"en_attente": "⏳ en attente", "telecharge": "✅ téléchargé",
                                                     "erreur": "✖ échec"}).fillna(df["statut"])
                    df["theme"] = df["theme"].map(lambda t: {"auto": "🤖 auto", "": "📥 à classer"}.get(t, t))
                    df["range_dans"] = df["range_dans"].fillna("").map(lambda t: B.nom_affiche(t) if t else "")
                    st.dataframe(df[["statut", "theme", "range_dans", "url", "message", "ajoute_le"]].head(300),
                                 hide_index=True, use_container_width=True,
                                 column_config={"url": st.column_config.LinkColumn("Post"), "theme": "Demandé",
                                                "range_dans": "Rangé dans", "ajoute_le": "Ajouté le"})
                    if st.button("🧹 Vider l'historique", use_container_width=True):
                        telechargement.modifier_file(lambda it: [x for x in it
                                                                 if x.get("statut") == "en_attente"])
                        st.rerun()


# ════════════════════════════════════════════ BIBLIOTHÈQUE VIDÉO ════════════════════════════════════════════

DOSSIER_VIGNETTES = config.RACINE / "static" / "vignettes"


@st.cache_data(show_spinner=False, max_entries=400)
def vignette_url(chemin_v: str, mtime: float) -> str:
    """URL d'affichage de la vignette (dossier static de Streamlit, sinon image embarquée)."""
    m = B.miniature_45(Path(chemin_v))
    if not m:
        return ""
    try:
        DOSSIER_VIGNETTES.mkdir(parents=True, exist_ok=True)
        cible = DOSSIER_VIGNETTES / m.name
        if not cible.exists() or cible.stat().st_mtime < m.stat().st_mtime:
            cible.unlink(missing_ok=True)
            try:
                os.link(m, cible)                     # lien matériel : aucune copie
            except OSError:
                shutil.copy2(m, cible)
        return "/app/static/vignettes/" + urllib.parse.quote(cible.name)
    except Exception:  # noqa: BLE001
        return _b64(m.read_bytes(), "jpeg")


def badge_video(v: dict) -> str:
    if v["utilisee"]:
        le = (v.get("utilisee_le") or "")[:10]
        b = f"<span class='badge b-utilisee'>★ Utilisée {le}</span>"
    else:
        b = "<span class='badge b-libre'>● Non utilisée</span>"
    if v.get("caption_incrustee"):
        b += " <span class='badge b-attente'>✎ Caption à l'image</span>"
    return b


def page_bibliotheque():
    st.session_state.vid_sig = telechargement.signature()
    bloc_pages_videos()
    comptes = B.comptes_par_theme(cfg)
    dossiers = [B.A_CLASSER, *themes()]
    choisi = st.session_state.pop("theme_choisi", None)      # thème qui vient d'être créé ou renommé
    if choisi in dossiers:
        st.session_state.bib_theme = choisi
    if st.session_state.get("bib_theme") not in dossiers:
        st.session_state.bib_theme = B.A_CLASSER if comptes.get(B.A_CLASSER, {}).get("total") else \
            (themes()[0] if themes() else B.A_CLASSER)

    gauche, droite = st.columns([1, 3.2], gap="large")
    with gauche:
        titre_aide("Dossiers thèmes",
                   "Un thème créé ici apparaît aussi dans les Captions. Tu peux aussi créer les dossiers "
                   "directement dans le Finder : ils apparaissent ici.", niveau="")

        def libelle(t):
            c = comptes.get(t, {"total": 0, "utilisees": 0})
            if t == B.A_CLASSER:
                return f"📥 À classer ({c['total']})"
            return f"📁 {t}  ·  {c['total'] - c['utilisees']} libres / {c['total']}"
        st.radio("Dossier", dossiers, key="bib_theme", format_func=libelle, label_visibility="collapsed")
        bloc_gerer_dossiers("bib", st.session_state.bib_theme, "bibliotheque", B.A_CLASSER)

    theme = st.session_state.bib_theme
    with droite:
        t1, t2 = st.columns([3, 2])
        with t1:
            if theme == B.A_CLASSER:
                titre_aide(B.nom_affiche(theme),
                           "Les vidéos arrivées sans thème, ou que le classement automatique n'a pas su "
                           "ranger. Choisis un dossier pour chacune, ou lance le classement automatique.",
                           niveau="###")
            else:
                st.markdown(f"### {B.nom_affiche(theme)}")
        filtre = t2.segmented_control("Afficher", ["Toutes", "Non utilisées", "Utilisées"], default="Toutes",
                                      key=f"filtre_{theme}", label_visibility="collapsed")
        vids = B.videos(cfg, theme)
        if filtre == "Non utilisées":
            vids = [v for v in vids if not v["utilisee"]]
        elif filtre == "Utilisées":
            vids = [v for v in vids if v["utilisee"]]

        if theme == B.A_CLASSER:
            if vids and st.button("🤖 Classer automatiquement (mots-clés)", type="primary"):
                ok, reste = B.classer_a_classer(cfg)
                st.toast(f"{ok} vidéo(s) classée(s), {reste} restent à classer")
                st.rerun()

        with st.expander("⬆️ Importer des vidéos depuis l'ordinateur dans ce dossier"):
            up = st.file_uploader("Vidéos", type=["mp4", "mov", "m4v", "webm"], accept_multiple_files=True,
                                  key=f"up_{theme}", label_visibility="collapsed")
            if up and st.button(f"Importer {len(up)} fichier(s)", key=f"upb_{theme}"):
                B.importer_fichiers(cfg, [(f.name, f.getvalue()) for f in up], theme)
                st.rerun()

        if not vids:
            st.info("Aucune vidéo ici.")
            return

        # ── actions groupées : la rangée d'actions n'apparaît qu'une fois des vidéos cochées ──
        cles_sel = [f"sel_{v['nom']}" for v in vids]
        sel = [v for v in vids if st.session_state.get(f"sel_{v['nom']}")]
        tout_coche = bool(cles_sel) and all(st.session_state.get(k) for k in cles_sel)
        a_voir = [v for v in vids if v.get("caption_incrustee") is None]
        with st.container(border=True):
            b1, b2, b3 = st.columns([1.3, 1.6, 3])
            cle_tout = f"bib_tout_{theme}"

            def _bascule_tout():
                for k in cles_sel:
                    st.session_state[k] = st.session_state[cle_tout]
            # la case reflète l'état réel : décochée tant que tout n'est pas coché
            st.session_state[cle_tout] = tout_coche
            b1.checkbox("Tout cocher", key=cle_tout, on_change=_bascule_tout,
                        help="Coche toutes les vidéos affichées : les actions apparaissent en dessous.")
            if b2.button(f"🔎 Analyser les vidéos ({len(sel) or len(a_voir)})",
                         disabled=not (sel or a_voir), use_container_width=True,
                         help="Lit quelques images de chaque vidéo : repère les captions déjà incrustées, "
                              "et retient ce que la vidéo montre pour pouvoir y assortir une caption."):
                cibles = sel or a_voir
                barre = st.progress(0.0, "Lecture…")
                trouves = 0
                for i, v in enumerate(cibles):
                    barre.progress((i + 1) / len(cibles), f"{v['nom'][:40]}…")
                    trouves += bool(B.analyser(cfg, v, forcer=bool(sel)).get("presente"))
                barre.empty()
                st.toast(f"{trouves} vidéo(s) ont déjà une caption sur {len(cibles)} analysée(s)", icon="🔎")
                st.rerun()
            deja = sum(1 for v in vids if v.get("caption_incrustee"))
            b3.markdown(f"<div class='etat-barre'>✎ {deja} portent déjà une caption · "
                        f"{len(a_voir)} pas encore analysée(s)</div>", unsafe_allow_html=True)
            if sel:
                a0, a1, a2, a3, a4, a5 = st.columns([0.6, 1.3, 1.15, 1.25, 1.5, 1.05])
                a0.markdown(f"<div class='choisies'>✓ {len(sel)}</div>", unsafe_allow_html=True)
                if a1.button("↺ Non utilisée(s)", use_container_width=True, key="bib_non_util",
                             help="Retire l'indication « utilisée » : les vidéos cochées repartent dans le circuit"):
                    for v in sel:
                        B.marquer(v["nom"], False)
                    st.toast(f"{len(sel)} vidéo(s) marquée(s) non utilisée(s)", icon="🔄")
                    st.rerun()
                if a2.button("★ Utilisée(s)", use_container_width=True, key="bib_util",
                             help="Met de côté les vidéos cochées : elles ne seront plus proposées au montage"):
                    for v in sel:
                        B.marquer(v["nom"], True)
                    st.toast(f"{len(sel)} vidéo(s) marquée(s) utilisée(s)", icon="⭐")
                    st.rerun()
                with a3.popover("🗑 Supprimer", use_container_width=True):
                    st.write(f"Supprimer définitivement **{len(sel)} vidéo(s)** de la bibliothèque ?")
                    if st.button("Oui, supprimer", type="primary", key="sup_groupe"):
                        for v in sel:
                            B.supprimer(cfg, v["nom"])
                            st.session_state.pop(f"sel_{v['nom']}", None)
                        st.rerun()
                dest = a4.selectbox("Déplacer vers", [t for t in themes() if t != theme], index=None,
                                    placeholder="Déplacer vers…", label_visibility="collapsed")
                if a5.button("📁 Déplacer", disabled=not dest, use_container_width=True):
                    for v in sel:
                        B.deplacer(cfg, v["nom"], dest)
                        st.session_state.pop(f"sel_{v['nom']}", None)
                    st.toast(f"{len(sel)} vidéo(s) déplacée(s) vers {dest}")
                    st.rerun()

        # ── grille façon profil Instagram : toutes les vignettes au même format 4:5 ──
        cols = st.columns(3)
        for i, v in enumerate(vids[:120]):
            ouverte = st.session_state.get("bib_lecture") == v["nom"]
            with cols[i % 3].container(border=True):
                if ouverte:
                    st.video(str(v["chemin"]))
                else:
                    u = vignette_url(str(v["chemin"]), v["chemin"].stat().st_mtime)
                    st.markdown(f"<div class='tuile'><img src='{u}'></div>" if u else
                                "<div class='tuile'></div>", unsafe_allow_html=True)
                st.markdown(badge_video(v), unsafe_allow_html=True)
                titre = (v.get("titre") or v["nom"]).replace("<", "")
                st.markdown(f"<div class='petit' title='{titre}'>{titre}</div>"
                            f"<div class='petit'>{v.get('compte') or ''}</div>", unsafe_allow_html=True)
                c1, c2 = st.columns([1, 1])
                c1.checkbox("Choisir", key=f"sel_{v['nom']}")
                if c2.button("⏹ Fermer" if ouverte else "▶ Lire", key=f"lec_{v['nom']}",
                             use_container_width=True, help="Lire la vidéo ici"):
                    st.session_state.bib_lecture = None if ouverte else v["nom"]
                    st.rerun()
                if st.button("↺ Marquer non utilisée" if v["utilisee"] else "★ Marquer utilisée",
                             key=f"us_{v['nom']}", use_container_width=True,
                             help="Une vidéo non utilisée est reprise par le tirage au sort et le montage "
                                  "en série ; une vidéo utilisée est mise de côté."):
                    B.marquer(v["nom"], not v["utilisee"])
                    st.rerun()
                if ouverte:
                    if v.get("url"):
                        st.markdown(f"<div class='petit'><a href='{v['url']}'>Post d'origine ↗</a></div>",
                                    unsafe_allow_html=True)
                    if v["exports"]:
                        st.caption("Exports : " + ", ".join(e["fichier"] for e in v["exports"]))
                    d = st.selectbox("Ranger dans", [t for t in themes() if t != theme], index=None,
                                     key=f"mv_{v['nom']}", placeholder="Ranger dans…", label_visibility="collapsed")
                    if d and st.button("📁 Déplacer", key=f"mvb_{v['nom']}", use_container_width=True):
                        B.deplacer(cfg, v["nom"], d)
                        st.session_state.bib_lecture = None
                        st.rerun()
                    pl = v.get("plans") or []
                    st.caption("✂️ Découpage : "
                               + (f"{len(pl)} plans" if len(pl) > 1 else
                                  "plan séquence (aucune coupe)" if len(pl) == 1 else "pas encore analysée"))
                    if v.get("etiquettes"):
                        st.caption("👁 Reconnu à l'image : "
                                   + ", ".join(f"{n}" for n, _c in v["etiquettes"][:8]))
                    etat_c = v.get("caption_incrustee")
                    st.caption("✎ Caption à l'image : "
                               + ("oui — " + (v.get("caption_texte") or "texte lu")[:60] if etat_c
                                  else "non" if etat_c is False else "pas encore analysée"))
                    k1, k2 = st.columns(2)
                    if k1.button("✎ A une caption", key=f"capo_{v['nom']}", use_container_width=True,
                                 disabled=bool(etat_c)):
                        B.noter_caption(v["nom"], True)
                        st.rerun()
                    if k2.button("∅ Pas de caption", key=f"capn_{v['nom']}", use_container_width=True,
                                 disabled=etat_c is False):
                        B.noter_caption(v["nom"], False)
                        st.rerun()
                    with st.popover("🗑 Supprimer cette vidéo", use_container_width=True):
                        st.write("Supprimer définitivement cette vidéo ?")
                        if st.button("Oui, supprimer", key=f"sup_{v['nom']}", type="primary"):
                            B.supprimer(cfg, v["nom"])
                            st.session_state.bib_lecture = None
                            st.rerun()
                if theme != B.A_CLASSER:
                    st.button("✂️ Monter", key=f"mon_{v['nom']}", use_container_width=True,
                              type="secondary" if v["utilisee"] else "primary",
                              on_click=aller, args=(P_MONTAGE,), kwargs={"pm_theme": theme, "pm_video": v["nom"]})
                else:
                    sug = B.deviner_theme(cfg, v["chemin"])
                    if sug:
                        st.button(f"→ {sug}", key=f"sug_{v['nom']}", use_container_width=True,
                                  help="Thème suggéré par les mots-clés",
                                  on_click=lambda n=v["nom"], s=sug: B.deplacer(cfg, n, s))
        if len(vids) > 120:
            st.caption(f"… et {len(vids) - 120} autres (filtre « Non utilisées » pour réduire la liste).")


# ════════════════════════════════════════════ CAPTIONS ════════════════════════════════════════════

STATUTS_QUOTES = {"en_attente": "⏳ en attente", "en_cours": "⏳ lecture…", "ok": "✅ ajoutée",
                  "doublon": "↩︎ déjà présente", "vide": "∅ pas de texte", "erreur": "✖ échec"}
VU_CAPTIONS = config.DOSSIER_DONNEES / "captions_vu.json"


@st.cache_data(max_entries=3000, show_spinner=False)
def vignette_data_uri(nom: str, mtime: float) -> str:
    import base64
    p = quotes.MINIATURES / nom
    return "data:image/jpeg;base64," + base64.b64encode(p.read_bytes()).decode() if p.exists() else ""


def vignette(nom: str | None) -> str:
    p = quotes.MINIATURES / nom if nom else None
    return vignette_data_uri(nom, p.stat().st_mtime) if p and p.exists() else ""


@st.fragment(run_every=3)
def _suivi_quotes():
    """Tant que des visuels restent à lire, on rafraîchit la page pour voir les quotes arriver."""
    file_q = quotes.lire_file()
    reste = [j for j in file_q if j.get("statut") in ("en_attente", "en_cours")]
    if reste or quotes.en_cours():
        st.caption(f"⏳ Lecture en cours… {len(reste)} visuel(s) restant(s)")
    elif st.session_state.get("quotes_en_travail"):
        st.session_state.quotes_en_travail = False
        st.rerun()                      # dernier visuel traité : on recharge toute la page
    st.session_state.quotes_en_travail = bool(reste)


def bloc_extraire_quotes():
    """Pages à explorer pour les quotes + suivi des extractions."""
    file_q = quotes.lire_file()
    en_cours = [j for j in file_q if j.get("statut") in ("en_attente", "en_cours")]
    echecs = [j for j in file_q if j.get("statut") in ("erreur", "vide")]
    titre = "📸 Extraire des captions depuis des visuels"
    if en_cours:
        titre += f" — ⏳ {len(en_cours)} en cours"
    with st.container(border=True):
        titre_aide(titre, "Un post précis (reel, post Instagram, vidéo TikTok, épingle Pinterest, Short) : "
                          "Monteur lit sa caption tout de suite, sans passer par Chrome. Une page à explorer "
                          "(compte, tableau, recherche d'images) s'ajoute à la liste : Ouvrir l'affiche dans "
                          "Chrome avec une case sur chaque visuel.")
        g, d = st.columns([1.15, 1], gap="large")
        with g:
            th_direct = "auto"       # classement par mots-clés, puis « À classer » si rien ne correspond
            with st.form("ajout_pages_quotes", clear_on_submit=True):
                liens = st.text_area("Liens (un par ligne)", height=90,
                                     placeholder="https://www.instagram.com/reels/XXXXXXXX/\n"
                                                 "https://www.instagram.com/compte_de_quotes/")
                if st.form_submit_button("➕ Ajouter", type="primary"):
                    connus = {p["url"].rstrip("/").lower() for p in cfg["pages_quotes"]}
                    n, posts = 0, []
                    for l in liens.splitlines():
                        l = l.strip()
                        if not l.startswith("http"):
                            continue
                        if quotes.est_post(l):
                            posts.append({"post_url": l, "video": True})
                        elif l.rstrip("/").lower() not in connus:
                            cfg["pages_quotes"].append({"nom": nom_compte(l), "url": l})
                            connus.add(l.rstrip("/").lower())
                            n += 1
                    if posts:
                        r = quotes.ajouter(posts, th_direct)
                        quotes.lancer_en_fond(config.charger)
                        if r["ajoutes"]:
                            st.toast(f"{r['ajoutes']} post(s) en lecture…", icon="📸")
                        if r["doublons"]:
                            st.session_state.quotes_a_forcer = [p["post_url"] for p in posts]
                            st.session_state.quotes_theme_forcer = th_direct
                    if n:
                        sauver(f"{n} page(s) ajoutée(s)")
                    if n or posts:
                        st.rerun()
            if st.session_state.get("quotes_a_forcer"):
                f1, f2 = st.columns([2.2, 1])
                f1.warning(f"{len(st.session_state.quotes_a_forcer)} post(s) déjà pris précédemment.", icon="↩︎")
                if f2.button("Relire quand même", use_container_width=True):
                    quotes.ajouter([{"post_url": u, "video": True} for u in st.session_state.quotes_a_forcer],
                                   st.session_state.get("quotes_theme_forcer", "auto"), force=True)
                    quotes.lancer_en_fond(config.charger)
                    st.session_state.quotes_a_forcer = []
                    st.rerun()
                if f2.button("Ignorer", use_container_width=True, key="ign_forcer"):
                    st.session_state.quotes_a_forcer = []
                    st.rerun()
            if cfg["pages_quotes"]:
                icones = {"instagram": "📸", "tiktok": "🎵", "youtube": "▶️", "pinterest": "📌", "web": "🌐"}
                with st.expander(f"📄 Pages suivies ({len(cfg['pages_quotes'])})"):
                    for i, pg in enumerate(cfg["pages_quotes"]):
                        a, b, c = st.columns([3.2, 1.3, 0.5])
                        a.markdown(f"{icones.get(quotes.plateforme(pg['url']), '🌐')} "
                                   f"**{pg.get('nom') or pg['url']}**"
                                   f"<div class='petit'>{pg['url']}</div>", unsafe_allow_html=True)
                        sep = "&" if "#" in pg["url"] else "#"
                        b.link_button("Ouvrir ↗", pg["url"] + f"{sep}monteur-quotes", use_container_width=True)
                        if c.button("🗑", key=f"del_pq_{i}", help="Retirer cette page de la liste"):
                            cfg["pages_quotes"].pop(i)
                            sauver("Page retirée")
                            st.rerun()
        with d:
            m = ocr.moteur()
            pastille("👁 Lecture du texte", m == "vision", ocr.explication())
            _suivi_quotes()
            if file_q and not en_cours and not echecs:
                st.caption(f"{sum(1 for j in file_q if j.get('statut') == 'ok')} visuel(s) lus.")
            derniers = [(r, j) for j in reversed(file_q) for r in (j.get("resultats") or []) if r.get("nouvelle")]
            if file_q:
                # un seul bouton : échecs, dernières captions arrivées et ménage sont derrière
                libelle = "📜 Suivi des visuels" + (f"  ·  ⚠ {len(echecs)}" if echecs else "")
                with st.popover(libelle, use_container_width=True):
                    if echecs:
                        if st.button(f"↻ Réessayer les {len(echecs)} échecs", use_container_width=True,
                                     help="Relance la lecture des visuels en échec ou sans texte"):
                            quotes.relancer()
                            quotes.lancer_en_fond(config.charger)
                            st.rerun()
                        for j in echecs[:20]:
                            st.markdown(
                                f"<div class='petit'>{(j.get('message') or 'échec')[:120]}<br>"
                                f"<a href='{j.get('post_url') or j.get('image_url') or ''}'>source ↗</a></div>",
                                unsafe_allow_html=True)
                        st.divider()
                    if derniers:
                        # où sont parties les dernières captions (le thème automatique surprend souvent)
                        lignes = []
                        for r, _j in derniers[:6]:
                            th = C_nom(r.get("theme") or C.A_CLASSER)
                            lignes.append(f"**{th}** · {(r.get('texte') or '')[:70]}")
                        st.markdown("Dernières captions ajoutées :\n\n" + "\n\n".join(lignes))
                    if st.button("🧹 Vider l'historique des visuels", use_container_width=True,
                                 help="Les captions déjà rangées dans les thèmes ne sont pas touchées"):
                        quotes.oublier([j["id"] for j in file_q
                                        if j.get("statut") not in ("en_attente", "en_cours")])
                        st.rerun()


def C_nom(theme: str) -> str:
    return "📥 À classer" if theme == C.A_CLASSER else theme


def _cle_tableau(theme: str) -> str:
    return f"ed_cap_{theme}_{st.session_state.get('cap_jeton', 0)}"


def _modifs_en_attente(theme: str) -> bool:
    """Des changements saisis dans le tableau et pas encore enregistrés ?"""
    e = st.session_state.get(_cle_tableau(theme)) or {}
    # une simple coche dans la colonne ✓ n'est pas une modification à enregistrer
    editees = {r: {k: v for k, v in (ch or {}).items() if k != "sel"}
               for r, ch in (e.get("edited_rows") or {}).items()}
    return bool(any(editees.values()) or e.get("added_rows") or e.get("deleted_rows"))


def _age_sync() -> float:
    e = C.etat_sync()
    if not e.get("le"):
        return 1e9
    try:
        return (dt.datetime.now() - dt.datetime.fromisoformat(e["le"])).total_seconds()
    except ValueError:
        return 1e9


@st.fragment(run_every=5)
def _veille_captions():
    """Fait apparaître toutes seules les quotes qui arrivent (Google Sheet, extraction, autre onglet)."""
    p = cfg.get("phrases_drive", {}) or {}
    if p.get("mode") == "google_sheet" and p.get("google_sheet_url") and p.get("auto", True):
        if _age_sync() > max(60, int(p.get("intervalle_s") or 120)):
            try:
                C.synchroniser_sheet(config.charger())   # filet de sécurité si le fil de fond s'est arrêté
            except Exception:  # noqa: BLE001
                pass
    sig = C.signature()
    if "cap_sig" in st.session_state and sig != st.session_state.cap_sig:
        if _modifs_en_attente(st.session_state.get("cap_theme", "")):
            st.info("Nouvelles captions reçues — enregistre tes modifications pour les afficher.", icon="☁️")
            return
        st.session_state.cap_sig = sig
        rerun_app()


def page_captions():
    global cfg
    pd_cfg = cfg.get("phrases_drive", {}) or {}
    if pd_cfg.get("mode") == "google_sheet" and pd_cfg.get("google_sheet_url") and pd_cfg.get("auto", True):
        # jamais pendant une saisie : de nouvelles lignes changeraient les données du tableau et
        # Streamlit effacerait la modification en cours
        if _age_sync() > 60 and not _modifs_en_attente(st.session_state.get("cap_theme", "")):
            with st.spinner("Lecture du Google Sheet…"):
                C.synchroniser_sheet(cfg)
            cfg = st.session_state.cfg = config.charger()   # des thèmes ont pu être créés
    st.session_state.cap_sig = C.signature()
    _veille_captions()
    # « nouvelle » = arrivée depuis la dernière visite de l'onglet (ouverture précédente de Monteur)
    if "cap_vu_avant" not in st.session_state:
        st.session_state.cap_vu_avant = (stockage_lire(VU_CAPTIONS) or {}).get("le") or ""
        config.DOSSIER_DONNEES.mkdir(parents=True, exist_ok=True)
        VU_CAPTIONS.write_text(json.dumps({"le": dt.datetime.now().isoformat(timespec="seconds")}), encoding="utf-8")
    vu_avant = st.session_state.cap_vu_avant

    bloc_extraire_quotes()

    ths = themes()
    a_classer = C.liste(C.A_CLASSER)
    liste_th = ([C.A_CLASSER] if a_classer else []) + ths
    if not liste_th:
        st.info("Aucun thème pour l'instant — crée-en un ci-dessous. Il apparaîtra aussi dans la Bibliothèque vidéo.")
        bloc_nouveau_theme("cap")
        return
    choisi = st.session_state.pop("theme_choisi", None)      # thème qui vient d'être créé ou renommé
    if choisi in liste_th:
        st.session_state.cap_theme = choisi
    if st.session_state.get("cap_theme") not in liste_th:
        st.session_state.cap_theme = C.A_CLASSER if a_classer else ths[0]

    tout_cap = C.tout()

    def nb_nouvelles(t):
        return sum(1 for i in tout_cap.get(t, []) if vu_avant and (i.get("ajoute_le") or "") > vu_avant)

    gauche, droite = st.columns([1, 3.2], gap="large")
    with gauche:
        titre_aide("Thèmes",
                   "Les mêmes thèmes que dans la Bibliothèque vidéo : en créer un ici le crée aussi là-bas.",
                   niveau="")

        def libelle(t):
            total, util = C.stats(t)
            n = nb_nouvelles(t)
            nouv = f"  · 🆕 {n}" if n else ""
            if t == C.A_CLASSER:
                return f"📥 À classer ({total}){nouv}"
            return f"💬 {t}  ·  {total - util} libres / {total}{nouv}"
        st.radio("Thème", liste_th, key="cap_theme", format_func=libelle, label_visibility="collapsed")
        bloc_gerer_dossiers("cap", st.session_state.cap_theme, "", C.A_CLASSER)
        with st.expander("☁️ Google Drive", expanded=False):
            p = cfg["phrases_drive"]
            p["mode"] = st.radio("Source", ["google_sheet", "dossier"], horizontal=True,
                                 index=0 if p.get("mode", "google_sheet") == "google_sheet" else 1,
                                 format_func=lambda m: "Google Sheet" if m == "google_sheet" else "Dossier Drive")
            if p["mode"] == "google_sheet":
                p["google_sheet_url"] = st.text_input("Lien du Google Sheet", p.get("google_sheet_url", ""),
                                                      help="Un onglet par thème. Partage : « Tous les utilisateurs "
                                                           "disposant du lien → Lecteur ». Les phrases peuvent être "
                                                           "dans n'importe quelle colonne.")
                p["auto"] = st.toggle("Synchroniser automatiquement", bool(p.get("auto", True)),
                                      help="Monteur relit le Sheet tout seul et range les nouvelles phrases "
                                           "dans le thème portant le nom de l'onglet.")
                p["miroir"] = st.toggle("Recopier fidèlement le Sheet", bool(p.get("miroir", True)),
                                        help="Une phrase supprimée dans le Sheet est aussi retirée de Monteur. "
                                             "Les captions capturées, ajoutées ou réécrites dans Monteur ne sont "
                                             "jamais touchées. Désactivé : Monteur ne fait qu'ajouter.")
                if p["miroir"]:
                    p["garder_utilisees"] = st.toggle("Garder les captions déjà utilisées",
                                                      bool(p.get("garder_utilisees", True)),
                                                      help="Elles restent dans Monteur même si tu les supprimes du "
                                                           "Sheet, pour ne pas les réutiliser par erreur.")
                minutes = st.select_slider("Toutes les", [1, 2, 5, 10, 30, 60],
                                           value=max(1, int(p.get("intervalle_s", 120)) // 60),
                                           format_func=lambda m: f"{m} min")
                p["intervalle_s"] = int(minutes) * 60
            else:
                p["dossier"] = st.text_input("Dossier (Drive synchronisé sur le Mac)", p.get("dossier", ""),
                                             help="Un fichier .txt ou .csv par thème, une phrase par ligne.")
            if st.button("💾 Enregistrer", use_container_width=True, key="sv_drive"):
                sauver()
                st.rerun()

        if cfg["phrases_drive"].get("mode") == "google_sheet":
            e = C.etat_sync()
            quand = (e.get("le") or "")[11:16]
            if e.get("ok"):
                st.caption(f"☁️ Synchronisé à {quand} — {e.get('message', '')}")
            elif e.get("ok") is False:
                st.warning(f"Synchronisation impossible : {e.get('message')}", icon="☁️")
            else:
                st.caption("☁️ Première synchronisation en attente…")
        if st.button("🔄 Synchroniser maintenant", use_container_width=True):
            with st.spinner("Lecture du Google Sheet…"):
                if cfg["phrases_drive"].get("mode") == "google_sheet":
                    r = C.synchroniser_sheet(cfg)
                    (st.success if r["ok"] else st.error)(r["message"])
                else:
                    try:
                        res = C.importer_drive(cfg, ths)
                        st.success(" · ".join(f"{t} +{n}" for t, n in res.items()) or "Aucun fichier correspondant.")
                    except Exception as ex:  # noqa: BLE001
                        st.error(str(ex))
            st.rerun()

    theme = st.session_state.cap_theme
    with droite:
        total, util = C.stats(theme)
        if theme == C.A_CLASSER:
            titre_aide("📥 À classer",
                       "Captions capturées que le classement automatique n'a pas su ranger. Choisis leur thème "
                       "dans la colonne Thème, puis enregistre.", niveau="###")
        else:
            titre_aide("💬 " + theme,
                       "Une caption utilisée dans un export est cochée automatiquement.", niveau="###")
            st.caption(f"{total - util} caption(s) non utilisée(s) · {util} déjà utilisée(s).")
            with st.form(f"ajout_cap_{theme}", clear_on_submit=True):
                txt = st.text_area("Ajouter des captions (une par ligne)", height=90,
                                   placeholder="Personne ne viendra le faire à ta place.\nLa discipline bat la motivation.")
                if st.form_submit_button("➕ Ajouter", type="primary"):
                    n = C.ajouter(theme, txt.splitlines())
                    st.toast(f"{n} caption(s) ajoutée(s)")
                    st.rerun()

        items = C.liste(theme)
        nouvelles = {i["id"] for i in items if vu_avant and (i.get("ajoute_le") or "") > vu_avant}
        # non utilisées d'abord ; parmi elles : nouvelles, puis à vérifier, puis les plus récentes
        items = sorted(items, key=lambda i: i.get("ajoute_le") or "", reverse=True)
        items.sort(key=lambda i: (bool(i.get("utilisee")), i["id"] not in nouvelles, not i.get("a_verifier")))
        noms_th = [C_nom(t) for t in ths] + [C_nom(C.A_CLASSER)]
        tout_sel = bool(st.session_state.get(f"cap_sel_tout_{theme}"))
        lignes = [{
            "id": i["id"],
            "sel": tout_sel,
            "image": vignette(i.get("miniature")),
            "etat": ("🆕 " if i["id"] in nouvelles else "") + ("⚠️" if i.get("a_verifier") else ""),
            "texte": i["texte"],
            "auteur": i.get("auteur") or "",
            "theme": C_nom(theme),
            "a_verifier": bool(i.get("a_verifier")),
            "utilisee": bool(i.get("utilisee")),
            "utilisee_le": (i.get("utilisee_le") or "")[:16].replace("T", " "),
            "source": i.get("source") or "",
            "video": i.get("video") or "",
        } for i in items]
        df = pd.DataFrame(lignes, columns=["id", "sel", "image", "etat", "texte", "auteur", "theme", "a_verifier",
                                           "utilisee", "utilisee_le", "source", "video"])
        avec_images = any(l["image"] for l in lignes)
        hauteur_ligne = 64 if avec_images else 35

        # ── actions groupées, au-dessus du tableau (même ordre que la Bibliothèque vidéo) ──
        # les cases ✓ sont lues dans l'état du tableau du passage précédent : la barre peut donc
        # être affichée avant lui.
        etat_ed = st.session_state.get(_cle_tableau(theme)) or {}
        idx = ({i for i, ch in (etat_ed.get("edited_rows") or {}).items() if (ch or {}).get("sel")}
               if not tout_sel else set(range(len(lignes))))
        coches = [lignes[int(i)] for i in idx if int(i) < len(lignes)]
        with st.container(border=True):

            def _apres(msg, icone):
                st.session_state.cap_jeton = st.session_state.get("cap_jeton", 0) + 1
                st.session_state.cap_sig = C.signature()
                st.session_state[f"cap_sel_tout_{theme}"] = False
                st.toast(msg, icon=icone)
                st.rerun()
            n1, n2 = st.columns([1.3, 4.6])
            cle_tout_c = f"cap_tout_{theme}"

            def _bascule_tout_c():
                st.session_state[f"cap_sel_tout_{theme}"] = st.session_state[cle_tout_c]
                st.session_state.cap_jeton = st.session_state.get("cap_jeton", 0) + 1
            st.session_state[cle_tout_c] = tout_sel
            n1.checkbox("Tout cocher", key=cle_tout_c, on_change=_bascule_tout_c,
                        help="Coche la colonne ✓ de toutes les captions affichées : les actions "
                             "apparaissent en dessous.")
            n2.markdown("<div class='etat-barre'>Coche des lignes dans la colonne ✓ du tableau pour les "
                        "copier, les marquer, les déplacer ou les supprimer</div>" if not coches else
                        f"<div class='etat-barre'>Les actions portent sur les <b>{len(coches)}</b> "
                        "caption(s) cochée(s)</div>", unsafe_allow_html=True)
            if coches:
                m0, m1, m2, m3, m4, m5 = st.columns([1.15, 1.3, 1.15, 1.25, 1.5, 1.05])
                with m0:
                    bouton_copier("\n".join((r["texte"] or "") for r in coches))
                if m1.button("↺ Non utilisée(s)", use_container_width=True, key=f"capnu_{theme}",
                             help="Les captions cochées repartent dans le circuit : elles seront reprises par "
                                  "« Choisir la caption » et par le montage en série."):
                    k = C.marquer_ids(theme, [r["id"] for r in coches], False)
                    _apres(f"{k} caption(s) marquée(s) non utilisée(s)", "🔄")
                if m2.button("★ Utilisée(s)", use_container_width=True, key=f"capu_{theme}",
                             help="Met de côté les captions cochées : elles ne seront plus proposées."):
                    k = C.marquer_ids(theme, [r["id"] for r in coches], True)
                    _apres(f"{k} caption(s) marquée(s) utilisée(s)", "⭐")
                with m3.popover("🗑 Supprimer", use_container_width=True):
                    st.write(f"Supprimer définitivement **{len(coches)} caption(s)** ? Même venues du Google "
                             "Sheet, elles ne reviendront pas.")
                    if st.button("Oui, supprimer", type="primary", key=f"supcap_{theme}"):
                        k = C.supprimer_ids(theme, [r["id"] for r in coches])
                        _apres(f"{k} caption(s) supprimée(s)", "🗑")
                dest_c = m4.selectbox("Déplacer vers", [t for t in ths + [C.A_CLASSER] if t != theme], index=None,
                                      format_func=C_nom, key=f"capdest_{theme}",
                                      placeholder="Déplacer vers…", label_visibility="collapsed")
                if m5.button("📁 Déplacer", disabled=not dest_c, use_container_width=True):
                    k = C.deplacer_ids(theme, [r["id"] for r in coches], dest_c)
                    _apres(f"{k} caption(s) déplacée(s) vers {C_nom(dest_c)}", "📁")

        edit = st.data_editor(
            df, key=_cle_tableau(theme), num_rows="dynamic", use_container_width=True, hide_index=True,
            height=min(720, 40 + hauteur_ligne * (len(df) + 1)), row_height=hauteur_ligne,
            column_order=["sel"] + (["image"] if avec_images else []) + ["etat", "texte", "auteur", "theme",
                                                                         "a_verifier", "utilisee", "utilisee_le",
                                                                         "source", "video"],
            column_config={
                "sel": st.column_config.CheckboxColumn("✓", width=44, default=False,
                                                       help="Coche des lignes puis utilise les boutons "
                                                            "au-dessus du tableau"),
                "image": st.column_config.ImageColumn("Visuel", width="small"),
                "etat": st.column_config.TextColumn("", disabled=True, width=48,
                                                    help="🆕 arrivée depuis ta dernière visite · ⚠️ lecture incertaine"),
                "texte": st.column_config.TextColumn("Caption", width="large", required=True),
                "auteur": st.column_config.TextColumn("Auteur", width="small"),
                "theme": st.column_config.SelectboxColumn("Thème", options=noms_th, required=True, width="small",
                                                          default=C_nom(theme),
                                                          help="Change le thème pour déplacer la caption"),
                "a_verifier": st.column_config.CheckboxColumn("À vérifier", width="small", default=False,
                                                              help="Décoche après relecture"),
                "utilisee": st.column_config.CheckboxColumn("Utilisée", width="small", default=False),
                "utilisee_le": st.column_config.TextColumn("Le", disabled=True, width="small"),
                "source": st.column_config.LinkColumn("Source", disabled=True, display_text="ouvrir ↗", width="small"),
                "video": st.column_config.TextColumn("Vidéo", disabled=True, width="small"),
            })
        st.caption("Modifie un texte, l'auteur ou le **thème** (la caption change d'onglet) : c'est enregistré tout de suite. "
                   "La colonne **✓** sert aux boutons au-dessus du tableau, qui agissent tout de suite. "
                   "Une caption supprimée l'est définitivement : même venue du Google Sheet, elle ne reviendra pas.")

        def enregistrer():
            par_nom = {C_nom(t): t for t in ths + [C.A_CLASSER]}
            lignes_ed = []
            for r in edit.to_dict("records"):
                r = {k: (None if (isinstance(v, float) and pd.isna(v)) else v) for k, v in r.items()}
                r["theme"] = par_nom.get(r.get("theme") or "", theme)
                lignes_ed.append(r)
            C.remplacer(theme, lignes_ed)
            st.session_state.cap_jeton = st.session_state.get("cap_jeton", 0) + 1   # tableau remis à neuf
            st.session_state.cap_sig = C.signature()

        # toute modification est enregistrée tout de suite : laissée en attente, elle était perdue au
        # moindre changement des données du tableau (synchronisation du Sheet, quotes qui arrivent…),
        # Streamlit remettant alors le tableau à zéro.
        etat_tab = st.session_state.get(_cle_tableau(theme)) or {}
        supprimees = etat_tab.get("deleted_rows") or []
        modifiees = [r for r, ch in (etat_tab.get("edited_rows") or {}).items()
                     if any(k != "sel" for k in (ch or {}))]
        ajoutees = [r for r in (etat_tab.get("added_rows") or []) if str((r or {}).get("texte") or "").strip()]
        if supprimees or modifiees or ajoutees:
            enregistrer()
            if supprimees:
                st.toast(f"{len(supprimees)} caption(s) supprimée(s)", icon="🗑")
            else:
                st.toast("Modification enregistrée", icon="💾")
            st.rerun()


def stockage_lire(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None


# ════════════════════════════════════════════ POST MONTAGE ════════════════════════════════════════════

CHAMPS_STYLE = list(config.STYLE_DEFAUT.keys())


def charger_style(nom: str | None = None):
    nom = nom or st.session_state.get("sty_preset")
    _poser_style(cfg["styles"].get(nom) or config.STYLE_DEFAUT)


def _poser_style(stl: dict):
    """Recopie un style dans les réglages affichés (clés `sty_*`)."""
    flottants = {"fond_opacite", "interligne", "debut_s", "fin_s"}
    entiers = {"taille", "contour_epaisseur", "fond_marge", "position_x", "position_y", "largeur_max"}
    for k in CHAMPS_STYLE:
        val = stl.get(k, config.STYLE_DEFAUT[k])
        if k in flottants:
            val = float(val or 0)
        elif k in entiers:
            val = int(round(float(val or 0)))
        elif k in ("ombre", "majuscules"):
            val = bool(val)
        st.session_state[f"sty_{k}"] = val
    casse = stl.get("casse") or ("MAJUSCULES" if stl.get("majuscules") else "minuscules")
    st.session_state.sty_casse = casse if casse in ("MAJUSCULES", "minuscules") else "minuscules"
    st.session_state.sty_casse_ui = "MAJ" if st.session_state.sty_casse == "MAJUSCULES" else "min"
    e = int(st.session_state.sty_contour_epaisseur or 0)
    st.session_state.sty_contour_ui = "aucun" if e <= 0 else "fin" if e <= 4 else "moyen" if e <= 9 else "epais"
    o = float(st.session_state.sty_fond_opacite or 0)
    st.session_state.sty_bandeau_ui = "aucun" if o <= 0.01 else "leger" if o < 0.85 else "plein"


def _rapport(info: dict) -> str:
    """Format d'une vidéo en clair : 9:16, 4:5, 1:1, 16:9…"""
    from math import gcd
    l, h = int(info["largeur"]), int(info["hauteur"])
    for (a, b, nom) in ((9, 16, "9:16"), (4, 5, "4:5"), (1, 1, "1:1"), (16, 9, "16:9"), (3, 4, "3:4")):
        if abs(l / h - a / b) < 0.02:
            return nom
    g = gcd(l, h) or 1
    return f"{l // g}:{h // g}"


def _sty(champ: str):
    """Valeur actuelle d'un réglage de style, pour la passer en `value=` aux widgets.

    Sans cela, un état de widget perdu (Streamlit nettoie ceux qui n'ont pas été affichés) fait
    retomber le réglage sur le minimum de l'échelle : texte à 20 % de large, contour 0, bandeau 0.
    """
    return st.session_state.get(f"sty_{champ}", config.STYLE_DEFAUT[champ])


def style_courant() -> dict:
    return {k: st.session_state.get(f"sty_{k}", config.STYLE_DEFAUT[k]) for k in CHAMPS_STYLE}


# Les captions et les paroles ont chacune leur habillage. Les mêmes réglages (clés `sty_*`) servent
# à éditer l'un ou l'autre : l'habillage qu'on n'édite pas attend dans `hab_<quoi>`.
def hab_edite() -> str:
    return st.session_state.get("hab_cible") or "captions"


def style_de(quoi: str) -> dict:
    """Habillage des « captions » ou des « paroles ». Paroles jamais réglées = celui des captions."""
    if hab_edite() == quoi:
        return style_courant()
    garde = st.session_state.get(f"hab_{quoi}")
    if garde:
        return dict(garde)
    return style_de("captions") if quoi == "paroles" else style_courant()


def _basculer_habillage():
    """Rappel du sélecteur Captions / Paroles : range l'habillage édité, sort l'autre."""
    ancien = st.session_state.get("hab_prec") or "captions"
    nouveau = st.session_state.get("hab_cible") or "captions"
    if nouveau == ancien:
        return
    st.session_state[f"hab_{ancien}"] = style_courant()
    _poser_style(st.session_state.get(f"hab_{nouveau}") or style_courant())
    st.session_state.hab_prec = nouveau


@st.cache_data(show_spinner=False, max_entries=32)
def info_video(chemin_v: str, mtime: float) -> dict:
    return sonder(Path(chemin_v))


@st.cache_data(show_spinner=False, max_entries=32)
def detection(chemin_v: str, mtime: float, duree: float) -> dict:
    return detecter(Path(chemin_v), duree)


def _b64(donnees: bytes, genre: str) -> str:
    return f"data:image/{genre};base64," + base64.b64encode(donnees).decode()


@st.cache_data(show_spinner=False, max_entries=64)
def mesure_bloc(texte: str, style_json: str, W: int, H: int) -> tuple[float, float]:
    """Taille du bloc de texte en % de l'image : sert à empêcher la caption d'entrer dans les zones
    occupées par l'interface de TikTok / Reels."""
    return mesurer_bloc(cfg, texte, json.loads(style_json), W, H)


def rendu_zone() -> dict:
    from monteur.rendu import ZONE_SURE
    return dict(ZONE_SURE)


def _calque_png(cfg, texte: str, style: dict, W: int, H: int) -> bytes:
    """Calque du texte rendu AU CENTRE : l'éditeur le déplace, l'export applique la vraie position."""
    img = image_texte(cfg, texte, {**style, "position_x": 50, "position_y": 50}, W, H, recadrer=False)
    largeur = 420
    img = img.resize((largeur, max(1, round(H * largeur / W))))
    b = io.BytesIO()
    img.save(b, "PNG", optimize=True)
    return b.getvalue()


DOSSIER_STATIC = config.RACINE / "static" / "apercu"


def video_servie(chemin_v: Path) -> str:
    """Rend la vidéo lisible par le navigateur. Renvoie son URL.

    On passe par le récepteur local quand il tourne : le dossier `static` de Streamlit renvoie les
    médias en « text/plain » et compressés, ce que le lecteur du navigateur n'ouvre pas toujours.
    """
    directe = recepteur.publier(chemin_v)
    if directe:
        return directe
    try:
        DOSSIER_STATIC.mkdir(parents=True, exist_ok=True)
        cible = DOSSIER_STATIC / chemin_v.name
        if not cible.exists() or cible.stat().st_mtime < chemin_v.stat().st_mtime:
            for vieux in DOSSIER_STATIC.glob("*.mp4"):       # on n'en garde qu'une poignée
                if vieux != cible and vieux.stat().st_mtime < time.time() - 3600:
                    vieux.unlink(missing_ok=True)
            try:
                os.link(chemin_v, cible)                     # lien matériel : aucune copie
            except OSError:
                shutil.copy2(chemin_v, cible)
        return "/app/static/apercu/" + urllib.parse.quote(cible.name)
    except Exception:  # noqa: BLE001
        return ""


@st.cache_data(show_spinner=False, max_entries=8)
def frise_video(chemin_v: str, mtime: float, duree: float) -> list[bytes]:
    return frise(Path(chemin_v), duree)


@st.cache_data(show_spinner=False, max_entries=48)
def image_fond(chemin_v: str, mtime: float, t: float, logo_json: str, W: int, H: int, cadrage: str,
               decalage: float = 50.0) -> bytes:
    img = apercu(Path(chemin_v), t, json.loads(logo_json), W, H, cadrage, info_video(chemin_v, mtime), decalage)
    b = io.BytesIO()
    img.convert("RGB").save(b, "JPEG", quality=88)
    return b.getvalue()


def zones_video(nom: str) -> list[dict]:
    n = st.session_state.get(f"nz_{nom}", 0)
    out = []
    for k in range(n):
        z = {c: float(st.session_state.get(f"z_{nom}_{k}_{c}", 0)) for c in ("x", "y", "largeur", "hauteur")}
        if z["largeur"] > 0 and z["hauteur"] > 0:
            out.append(z)
    return out


def poser_zones(nom: str, zones: list[dict]):
    st.session_state[f"nz_{nom}"] = len(zones)
    for k, z in enumerate(zones):
        for c in ("x", "y", "largeur", "hauteur"):
            st.session_state[f"z_{nom}_{k}_{c}"] = float(round(z[c], 1))


def page_postmontage():
    ths = themes()
    if not ths:
        st.info("Crée d'abord un dossier thème dans la Bibliothèque vidéo.")
        return
    if st.session_state.get("pm_theme") not in ths:
        st.session_state.pm_theme = ths[0]
    if "sty_preset" not in st.session_state or st.session_state.sty_preset not in cfg["styles"]:
        st.session_state.sty_preset = "classique" if "classique" in cfg["styles"] else next(iter(cfg["styles"]))
        charger_style()
    if "sty_police" not in st.session_state:
        charger_style()

    # ── choix de la vidéo : miniatures ou tirage au sort ──
    c1, c2, c3 = st.columns([1.3, 1.3, 1.6])
    c1.selectbox("Thème des vidéos", ths, key="pm_theme",
                 help="Les vidéos proposées, et le dossier du centre de contrôle où l'export sera rangé.")
    theme = st.session_state.pm_theme
    if st.session_state.get("pm_theme_cap") not in ths:
        st.session_state.pm_theme_cap = theme
    c2.selectbox("Thème des captions", ths, key="pm_theme_cap",
                 help="Les captions proposées. Tu peux en prendre d'un thème différent de celui "
                      "des vidéos.")
    theme_cap = st.session_state.pm_theme_cap
    voir_util = c3.toggle("Montrer les vidéos déjà utilisées", key="pm_voir_util")
    courant = st.session_state.get("pm_video")
    vids = [v for v in B.videos(cfg, theme) if voir_util or not v["utilisee"] or v["nom"] == courant]
    if not vids:
        st.info(f"Aucune vidéo {'' if voir_util else 'non utilisée '}dans « {theme} ». "
                "Ajoute-en depuis l'onglet Bibliothèque vidéo.")
        return
    par_nom = {v["nom"]: v for v in vids}
    if courant not in par_nom:
        st.session_state.pm_video = vids[0]["nom"]

    def choisir_video(nom):
        st.session_state.pm_video = nom
        st.session_state.pop("pm_export", None)

    libres = [x for x in vids if not x["utilisee"]] or vids
    v = par_nom[st.session_state.pm_video]
    with st.expander("🖼️ Choisir la vidéo", expanded=False):
        cols = st.columns(8)
        for i, x in enumerate(vids[:48]):
            with cols[i % 8]:
                m = B.miniature(x["chemin"])
                if m:
                    st.image(str(m), use_container_width=True)
                st.button("✓ en cours" if x["nom"] == st.session_state.pm_video
                          else ("★ utilisée" if x["utilisee"] else "Choisir"),
                          key=f"pick_{x['nom']}", use_container_width=True,
                          type="primary" if x["nom"] == st.session_state.pm_video else "secondary",
                          on_click=choisir_video, args=(x["nom"],))
    st.button("🎲 Vidéo au hasard", use_container_width=False, type="secondary",
              on_click=lambda: choisir_video(random.choice(libres)["nom"]))

    nom = v["nom"]
    mtime = v["chemin"].stat().st_mtime
    info = info_video(str(v["chemin"]), mtime)
    duree_src = max(0.2, round(info["duree"], 2))

    # état propre à cette vidéo (coupe + instant d'aperçu)
    if st.session_state.get("pm_video_etat") != nom:
        st.session_state.pm_video_etat = nom
        st.session_state.pm_debut, st.session_state.pm_fin = 0.0, duree_src
        st.session_state.pm_t = min(1.0, duree_src / 2)
        st.session_state.pm_decalage = 50
        st.session_state.pop(f"logo_msg_{nom}", None)

    gauche, droite = st.columns([1, 1.25], gap="large")

    with gauche:
        if v["utilisee"]:
            st.warning(f"Cette vidéo a déjà été utilisée le {(v.get('utilisee_le') or '')[:10]}.", icon="⭐")
        if v.get("caption_incrustee"):
            st.warning("Cette vidéo porte **déjà une caption à l'image**"
                       + (f" : « {v['caption_texte'][:70]} »" if v.get("caption_texte") else "")
                       + ". Laisse le texte vide pour ne pas en superposer une deuxième.", icon="✎")

        etape("1", "La vidéo",
              "Le format de l'export et, si besoin, l'effacement d'un logo ou d'un @compte incrusté.")
        b1, b2 = st.columns(2)
        plein = b1.toggle("📱 Plein écran 9:16", value=True, key=f"plein_{nom}",
                          help="Met la vidéo au format vertical 1080×1920.")
        ex = cfg.get("export", {})
        au_format = meme_format(info, int(ex.get("largeur", 1080)), int(ex.get("hauteur", 1920)))
        cadrage_paysage = "remplir" if au_format else "bandes"
        if plein:
            choix = st.segmented_control(
                f"Vidéo d'origine {info['largeur']}×{info['hauteur']} ({_rapport(info)})"
                + (" — déjà au format 9:16" if au_format else " — export en 9:16"),
                ["bandes", "remplir"], default=st.session_state.get(f"cadp_{nom}", cadrage_paysage),
                key=f"cadp_{nom}",
                format_func=lambda m: "Entière, bandes noires" if m == "bandes" else "Agrandie plein écran",
                help="Agrandie : la vidéo occupe tout l'écran et tu choisis la partie visible en la faisant "
                     "glisser sur l'aperçu (outil ✥).")
            cadrage_paysage = choix or cadrage_paysage

        def activer_logo():
            if st.session_state.get(f"logo_{nom}") and not st.session_state.get(f"nz_{nom}"):
                d = detection(str(v["chemin"]), mtime, info["duree"])
                poser_zones(nom, d.get("zones", []))
                st.session_state[f"logo_msg_{nom}"] = d["message"]
        logo_on = b2.toggle("🧽 Enlever le logo / tag", key=f"logo_{nom}", on_change=activer_logo,
                            help="Détecte les éléments incrustés fixes (logo, @compte) et les efface.")
        logo = None
        if logo_on:
            msg = st.session_state.get(f"logo_msg_{nom}")
            if msg:
                st.caption(("🔍 " if zones_video(nom) else "⚠️ ") + msg)
            mode = st.radio("Méthode", ["flou", "masque"], horizontal=True, key="pm_logo_mode",
                            format_func=lambda m: "Flouter" if m == "flou" else "Effacer (reconstitution)")
            with st.expander(f"Ajuster les zones ({len(zones_video(nom))})", expanded=not zones_video(nom)):
                fond_z = Image.open(io.BytesIO(image_fond(str(v["chemin"]), mtime,
                                                          min(1.0, info["duree"] / 2), "null",
                                                          info["largeur"], info["hauteur"],
                                                          "remplir"))).convert("RGB")
                dr = ImageDraw.Draw(fond_z, "RGBA")
                for z in zones_video(nom):
                    W0, H0 = fond_z.size
                    dr.rectangle([W0 * z["x"] / 100, H0 * z["y"] / 100, W0 * (z["x"] + z["largeur"]) / 100,
                                  H0 * (z["y"] + z["hauteur"]) / 100], outline=(255, 0, 80, 255),
                                 fill=(255, 0, 80, 70), width=max(3, W0 // 150))
                zc1, zc2 = st.columns([1, 1.4])
                zc1.image(fond_z, use_container_width=True, caption="Zones effacées en rouge")
                with zc2:
                    for k in range(st.session_state.get(f"nz_{nom}", 0)):
                        st.markdown(f"**Zone {k + 1}**")
                        a, b = st.columns(2)
                        a.slider("X %", 0.0, 100.0, key=f"z_{nom}_{k}_x", step=0.5)
                        b.slider("Y %", 0.0, 100.0, key=f"z_{nom}_{k}_y", step=0.5)
                        a.slider("Largeur %", 0.0, 100.0, key=f"z_{nom}_{k}_largeur", step=0.5)
                        b.slider("Hauteur %", 0.0, 100.0, key=f"z_{nom}_{k}_hauteur", step=0.5)
                    a, b, c = st.columns(3)
                    if a.button("➕ Zone", key=f"addz_{nom}"):
                        poser_zones(nom, zones_video(nom) + [{"x": 70.0, "y": 85.0,
                                                              "largeur": 25.0, "hauteur": 6.0}])
                        st.rerun()
                    if b.button("➖ Zone", key=f"rmz_{nom}", disabled=not st.session_state.get(f"nz_{nom}")):
                        poser_zones(nom, zones_video(nom)[:-1])
                        st.rerun()
                    if c.button("🔍 Re-détecter", key=f"redet_{nom}"):
                        d = detection(str(v["chemin"]), mtime, info["duree"])
                        poser_zones(nom, d.get("zones", []))
                        st.session_state[f"logo_msg_{nom}"] = d["message"]
                        st.rerun()
            logo = {"mode": mode, "zones": zones_video(nom)}

        # ── 2 · caption ──
        etape("2", "La caption",
              "Le texte posé sur la vidéo. Choisis-en une dans la banque, laisse Monteur l'assortir au "
              "contenu de la vidéo, ou écris la tienne. Vide = pas de texte.")
        cle_q = f"quote_{nom}"

        def importer_quote():
            ex = {st.session_state.get(f"qid_{nom}")} if st.session_state.get(f"qid_{nom}") else None
            q = C.tirer(theme_cap, ex)
            if q:
                st.session_state[cle_q] = q["texte"]
                st.session_state[f"qid_{nom}"] = q["id"]
            else:
                st.session_state[f"qvide_{nom}"] = True
        total_c, utilisees_c = C.stats(theme_cap)
        libres_c = total_c - utilisees_c
        q1, q2 = st.columns([1.3, 1])
        q1.button(f"💬 Prendre une caption ({libres_c} dispo.)", on_click=importer_quote,
                  type="primary" if not st.session_state.get(cle_q) else "secondary",
                  use_container_width=True, disabled=libres_c == 0)
        def poser_quote(texte, ident=None):
            st.session_state[cle_q] = texte
            if ident:
                st.session_state[f"qid_{nom}"] = ident
        q2.button("💬 Choisir la caption", use_container_width=True,
                  on_click=lambda: st.session_state.update({f"choix_cap_{nom}": True}),
                  help="Parcourir les captions libres du thème, les mieux assorties à cette vidéo d'abord.")
        if st.session_state.get(f"choix_cap_{nom}"):
            with st.container(border=True):
                libres_l = [i for i in C.liste(theme_cap) if not i.get("utilisee")]
                sac = B.sac_video(cfg, v, analyser_si_besoin=False)
                notes = {i["id"]: assortir.score(sac, i["texte"]) for i in libres_l}
                analysee = bool(sac.get("champs"))
                g1, g2 = st.columns([2, 1.2])
                cherche = g1.text_input("Chercher", key=f"qcher_{nom}", placeholder="Chercher un mot…",
                                        label_visibility="collapsed")
                tri = g2.segmented_control("Trier", ["assorties", "recentes"],
                                           default="assorties" if analysee else "recentes",
                                           key=f"qtri_{nom}",
                                           format_func=lambda m: "Les mieux assorties" if m == "assorties"
                                           else "Les plus récentes") or "recentes"
                liste_q = [i for i in libres_l
                           if not cherche.strip() or cherche.strip().lower() in i["texte"].lower()]
                if tri == "assorties" and analysee:
                    liste_q.sort(key=lambda i: notes.get(i["id"], 0), reverse=True)
                if not analysee:
                    st.caption("Cette vidéo n'a pas encore été analysée : passe **🔎 Analyser les vidéos** "
                               "dans la Bibliothèque pour trier les captions par affinité.")
                st.caption(f"{len(liste_q)} caption(s) libre(s) dans « {theme_cap} ».")
                cols_q = st.columns(3)
                for i_q, it in enumerate(liste_q[:60]):
                    with cols_q[i_q % 3].container(border=True):
                        u = vignette(it.get("miniature"))
                        if u:
                            st.markdown(f"<div class='tuile' style='aspect-ratio:1/1'><img src='{u}'></div>",
                                        unsafe_allow_html=True)
                        n_q = notes.get(it["id"], 0)
                        if analysee:
                            st.markdown(f"<span class='badge {'b-libre' if n_q >= 0.6 else 'b-gris'}'>"
                                        f"affinité {n_q:.2f}</span>", unsafe_allow_html=True)
                        st.write(it["texte"])
                        if it.get("auteur"):
                            st.caption(f"— {it['auteur']}")
                        st.button("Choisir", key=f"pickq_{nom}_{it['id']}", use_container_width=True,
                                  type="primary" if st.session_state.get(cle_q) == it["texte"] else "secondary",
                                  on_click=poser_quote, args=(it["texte"], it["id"]))
                if st.button("✕ Fermer la liste", key=f"fermeq_{nom}"):
                    st.session_state[f"choix_cap_{nom}"] = False
                    st.rerun()
        if st.session_state.pop(f"qvide_{nom}", False) or libres_c == 0:
            st.caption(f"⚠️ Plus de caption libre dans « {theme_cap} » : ajoute-en dans l'onglet 💬 Captions.")
        elif theme_cap != theme:
            st.caption(f"💬 Captions prises dans « {theme_cap} », vidéos dans « {theme} ».")
        st.text_area("Texte (modifiable)", key=cle_q, height=80)

        # ── 3 · habillage et audio ──
        etape("3", "Habillage des captions et des paroles",
              "La typo, la couleur, le contour et le bandeau. Les captions et les paroles ont chacune "
              "le leur : choisis ci-dessous lequel tu règles. La position de la caption se règle "
              "directement sur l'aperçu, à droite ; celle des paroles à l'étape 4.")
        st.session_state.setdefault("hab_cible", "captions")
        st.session_state.setdefault("hab_prec", st.session_state.hab_cible)
        st.segmented_control("Régler l'habillage de", ["captions", "paroles"], key="hab_cible",
                             on_change=_basculer_habillage,
                             format_func=lambda m: "💬 Captions" if m == "captions" else "📝 Paroles",
                             help="Les réglages ci-dessous s'appliquent à ce que tu choisis ici. "
                                  "Tant que tu n'as pas touché aux paroles, elles reprennent "
                                  "l'habillage des captions.")
        if not st.session_state.get("hab_cible"):       # un clic sur l'option déjà choisie la vide
            st.session_state.hab_cible = st.session_state.get("hab_prec") or "captions"
        polices = list(polices_disponibles(cfg).keys())
        if st.session_state.sty_police not in polices:
            polices = [st.session_state.sty_police, *polices]
        titre_aide("Typo", "Clique une typo pour la choisir — elle porte alors un ✓. Autre façon : "
                           "survole la liste puis défile avec les flèches ↑ ↓, l'aperçu se met à jour "
                           "à chaque cran. Le champ de recherche filtre la liste.", niveau="")
        retour_t = st.session_state.get("comp_typos")
        if isinstance(retour_t, dict) and retour_t.get("nonce") != st.session_state.get("typos_vu"):
            st.session_state.typos_vu = retour_t["nonce"]
            if retour_t.get("nom") in polices:
                st.session_state.sty_police = retour_t["nom"]
        typos(polices, st.session_state.sty_police, key="comp_typos")
        with st.expander("🔤 Ajouter des typos  (ou glisse tes .ttf dans le dossier « polices »)"):
            up_t = st.file_uploader("Fichiers .ttf / .otf", type=["ttf", "otf", "ttc"],
                                    accept_multiple_files=True, key="up_typo", label_visibility="collapsed")
            if up_t:
                dp = dossier_polices()
                dp.mkdir(parents=True, exist_ok=True)
                for f in up_t:
                    (dp / f.name).write_bytes(f.getbuffer())
                vider_cache_polices()
                st.session_state.sty_police = up_t[-1].name
                st.success(f"{len(up_t)} typo(s) ajoutée(s) — « {up_t[-1].name} » sélectionnée.")
                st.rerun()

        a, b, c = st.columns([2, 1.4, 1.6])
        a.slider("Taille", 20, 200, value=_sty("taille"), key="sty_taille")
        b.segmented_control("Casse", ["MAJ", "min"], default=st.session_state.get("sty_casse_ui", "min"),
                            key="sty_casse_ui",
                            format_func=lambda m: "ABC" if m == "MAJ" else "abc",
                            help="Écrire la caption en majuscules ou en minuscules.")
        st.session_state.sty_casse = "MAJUSCULES" if st.session_state.get("sty_casse_ui") == "MAJ" else "minuscules"
        c.segmented_control("Alignement", ["gauche", "centre", "droite"],
                            default=_sty("alignement"), key="sty_alignement",
                            format_func=lambda m: {"gauche": "⬅", "centre": "↔", "droite": "➡"}[m],
                            help="Alignement des lignes du texte")
        retour_c = nuancier(st.session_state.sty_couleur, st.session_state.sty_contour_couleur,
                            st.session_state.sty_fond_couleur, key="nuancier")
        if retour_c and retour_c.get("nonce") != st.session_state.get("nuancier_vu"):
            # pas de st.rerun() ici : il interromprait le script avant les réglages ci-dessous,
            # dont Streamlit oublierait alors l'état. La suite de la page lit déjà les nouvelles couleurs.
            st.session_state.nuancier_vu = retour_c["nonce"]
            st.session_state.sty_couleur = retour_c["couleur"]
            st.session_state.sty_contour_couleur = retour_c["contour"]
            st.session_state.sty_fond_couleur = retour_c["bandeau"]
        CONTOURS = {"aucun": 0, "fin": 3, "moyen": 6, "epais": 12}
        BANDEAUX = {"aucun": 0.0, "leger": 0.55, "plein": 1.0}
        a, b = st.columns(2)
        a.segmented_control("Contour", list(CONTOURS),
                            default=st.session_state.get("sty_contour_ui", "moyen"), key="sty_contour_ui",
                            format_func=lambda m: {"aucun": "Sans", "fin": "Fin", "moyen": "Moyen",
                                                   "epais": "Épais"}[m],
                            help="Liseré autour des lettres, dans la couleur « Contour ».")
        b.segmented_control("Bandeau", list(BANDEAUX),
                            default=st.session_state.get("sty_bandeau_ui", "aucun"), key="sty_bandeau_ui",
                            format_func=lambda m: {"aucun": "Sans", "leger": "Translucide",
                                                   "plein": "Plein"}[m],
                            help="Rectangle derrière le texte, dans la couleur « Bandeau ».")
        st.session_state.sty_contour_epaisseur = CONTOURS.get(st.session_state.get("sty_contour_ui"), 6)
        st.session_state.sty_fond_opacite = BANDEAUX.get(st.session_state.get("sty_bandeau_ui"), 0.0)
        with st.expander("Ombre, marge du bandeau, interligne, apparition"):
            a, b = st.columns(2)
            a.toggle("Ombre portée", value=bool(_sty("ombre")), key="sty_ombre")
            b.slider("Marge du bandeau", 0, 80, value=_sty("fond_marge"), key="sty_fond_marge")
            a, b, c = st.columns(3)
            a.slider("Interligne", 0.8, 2.0, value=float(_sty("interligne")), key="sty_interligne", step=0.05)
            b.number_input("Apparaît à (s)", 0.0, 600.0, value=float(_sty("debut_s")), key="sty_debut_s", step=0.5)
            c.number_input("Disparaît à (s, 0 = fin)", 0.0, 600.0, value=float(_sty("fin_s")), key="sty_fin_s", step=0.5)
            st.slider("Largeur max du bloc %", 20, 100, value=_sty("largeur_max"), key="sty_largeur_max",
                      help="Au-delà de 78 %, le texte dépasse de la zone sûre de TikTok : il est alors "
                           "centré dessus, mais les bords risquent d'être masqués par l'interface.")
        with st.popover("💾 Enregistrer comme style"):
            nn = st.text_input("Nom du style", value=st.session_state.sty_preset)
            if st.button("Enregistrer", type="primary") and nn.strip():
                cfg["styles"][nn.strip()] = style_courant()
                sauver(f"Style « {nn.strip()} » enregistré")

        # ── 4 · audio ──
        etape("4", "L'audio",
              "L'extrait posé sur la vidéo. Plus court que la vidéo, il est prolongé jusqu'à la fin ; "
              "plus long, il est coupé. Les extraits viennent de l'onglet Audios.")
        duree_choisie = max(0.1, float(st.session_state.get("pm_fin") or duree_src)
                            - float(st.session_state.get("pm_debut") or 0))
        audio_pm = bloc_audio("pm", duree_video=duree_choisie)
        paroles_pm = bloc_paroles("pm", audio_pm, duree_choisie)

    # ── éditeur visuel ──
    with droite:
        W, H, cadrage = dimensions_export(info, plein, cfg, cadrage_paysage)
        decalage = int(st.session_state.get("pm_decalage", 50))
        debut = float(st.session_state.pm_debut)
        fin = float(st.session_state.pm_fin or duree_src)
        t = float(min(max(st.session_state.pm_t, debut), fin))
        stl = style_courant()
        texte = st.session_state.get(cle_q, "")
        if hab_edite() == "paroles":
            lp = (paroles_pm or {}).get("lignes") or []
            texte = (str(lp[0]["texte"]) if lp else "Les paroles s'écrivent ici")
            stl = {**stl, "position_y": postmontage.BANDES_PAROLES.get(
                (paroles_pm or {}).get("position") or "bas", 78), "debut_s": 0, "fin_s": 0}
        bloc_pct = mesure_bloc(texte, json.dumps(stl, sort_keys=True), W, H)
        try:
            fond_b64 = _b64(image_fond(str(v["chemin"]), mtime, t, json.dumps(logo), W, H, cadrage, decalage),
                            "jpeg")
            # le calque est rendu centré : l'éditeur le déplace, l'export utilise la position finale
            visible = stl["debut_s"] <= (t - debut) and (not stl["fin_s"] or (t - debut) <= stl["fin_s"])
            calque_b64 = ""
            if texte.strip() and visible:
                calque_b64 = _b64(_calque_png(cfg, texte, stl, W, H), "png")
            vignettes = [_b64(x, "jpeg") for x in frise_video(str(v["chemin"]), mtime, duree_src)]
            retour = editeur(video=video_servie(v["chemin"]), fond=fond_b64, calque=calque_b64,
                             frise=vignettes, duree=duree_src,
                             x=int(stl["position_x"]), y=int(stl["position_y"]), debut=debut, fin=fin, t=t,
                             cadrage=cadrage, logo=logo, largeur=W, hauteur=H, decalage=decalage,
                             cadrable=(cadrage == "remplir"), src_largeur=int(info["largeur"]),
                             src_hauteur=int(info["hauteur"]),
                             bloc_l=bloc_pct[0], bloc_h=bloc_pct[1], zone=rendu_zone(),
                             son=son_servi(Path(audio_pm["chemin"])) if audio_pm else "",
                             son_volume=float(audio_pm["volume"]) if audio_pm else 1.0,
                             son_garder=bool(audio_pm["garder_son"]) if audio_pm else False,
                             key=f"ed_{nom}")
        except Exception as e:  # noqa: BLE001
            st.error(f"Aperçu impossible : {e}")
            retour = None

        if retour and retour.get("nonce") != st.session_state.get(f"ed_vu_{nom}"):
            st.session_state[f"ed_vu_{nom}"] = retour["nonce"]
            if hab_edite() == "captions":       # la hauteur des paroles se choisit à l'étape 4
                st.session_state.sty_position_x = int(retour["x"])
                st.session_state.sty_position_y = int(retour["y"])
            st.session_state.pm_debut = round(float(retour["debut"]), 2)
            st.session_state.pm_fin = round(float(retour["fin"]), 2)
            st.session_state.pm_t = round(float(retour["t"]), 2)
            st.session_state.pm_decalage = int(retour.get("decalage", 50))
            st.rerun()

        coupe = (debut, fin) if (debut > 0.01 or fin < duree_src - 0.01) else None
        st.caption(f"Export {W}×{H} · {fin - debut:.1f} s"
                   + (f" (extrait de {duree_src:.1f} s)" if coupe else "")
                   + f" · caption à {stl['position_x']} % / {stl['position_y']} %")

        etape("", "Export")
        dest_theme = st.selectbox("Ranger dans le dossier du centre de contrôle", ths, index=ths.index(theme),
                                  key=f"dest_{nom}_{theme}",
                                  help="Par défaut le thème des vidéos. C'est lui qui décide du sous-dossier.")
        if not st.session_state.get(cle_q, "").strip():
            st.caption("💡 Pas de caption : la vidéo sera exportée sans caption.")
        if audio_pm:
            st.caption(f"🎵 Audio : **{audio_pm['nom']}**"
                       + (" (mélangé au son d'origine)" if audio_pm["garder_son"] else " (remplace le son)"))
        if st.button("📤 Exporter la vidéo", type="primary", use_container_width=True):
            with st.spinner("Export en cours…"):
                try:
                    par_pm = {**paroles_pm, "habillage": style_de("paroles")} if paroles_pm else None
                    dest = postmontage.exporter(cfg, v, dest_theme, st.session_state.get(cle_q, ""),
                                                style_de("captions"), plein, logo,
                                                coupe, cadrage_paysage, decalage, audio_pm,
                                                theme_caption=theme_cap, paroles=par_pm)
                    st.session_state.pm_export = str(dest)
                except Exception as e:  # noqa: BLE001
                    st.error(f"Échec de l'export : {e}")
            st.rerun()
        if st.session_state.get("pm_export") and Path(st.session_state.pm_export).exists():
            p = Path(st.session_state.pm_export)
            st.success(f"Exportée dans **{p.parent.name}/{p.name}** — vidéo et caption marquées « utilisées ».")
            st.video(str(p))
            n1, n2 = st.columns(2)
            suivantes = [x["nom"] for x in B.videos(cfg, theme) if not x["utilisee"]]

            def suivante():
                st.session_state.pm_export = None
                if suivantes:
                    choisir_video(suivantes[0])
            n1.button("➡️ Vidéo suivante", on_click=suivante, disabled=not suivantes, use_container_width=True)
            if n2.button("📂 Ouvrir le dossier", use_container_width=True):
                ouvrir_finder(p.parent)

    st.divider()
    with expander_vedette("⚡ Monter en série", expanded=False, cle="bloc_serie"):
        # ── les deux choix qui décident de la forme du montage ──
        c_a, c_b = st.columns(2)
        cale_ui = c_a.segmented_control(
            "1 · Rythme", ["libre", "cale"], default="libre", key="ser_cale",
            format_func=lambda m: "Pas calé sur le rythme" if m == "libre" else "Calé sur le rythme",
            help="Calé : Monteur trouve le tempo de l'audio choisi plus bas et change de plan sur les "
                 "temps.") or "libre"
        cale = cale_ui == "cale"
        struct_ui = c_b.segmented_control(
            "2 · Montage", ["melange", "par_video"], default="par_video", key="ser_struct",
            format_func=lambda m: "Mélanger les rushs du thème" if m == "melange"
            else "Remonter vidéo par vidéo",
            help="Mélanger : chaque export pioche des plans dans plusieurs vidéos du thème. "
                 "Vidéo par vidéo : un export par vidéo.") or "par_video"
        melange = struct_ui == "melange"
        remonte = melange or cale          # dès qu'on recoupe les vidéos en plans

        themes_ser = st.multiselect(
            "Thèmes des vidéos", ths, default=[theme], key="ser_themes_v",
            help="Un ou plusieurs thèmes : ils se relaient d'un export à l'autre. Chaque export est "
                 "rangé dans le dossier du thème de sa vidéo.") or [theme]
        libres_v = sum(len([x for x in B.videos(cfg, t) if not x["utilisee"]]) for t in themes_ser)
        noms_ser = ", ".join(f"« {t} »" for t in themes_ser)
        st.caption(
            (f"Chaque export mélange des plans pris dans les vidéos non utilisées d'un thème — "
             f"{noms_ser} ({libres_v}). " if melange else
             f"Un export par vidéo non utilisée de {noms_ser} ({libres_v}). ")
            + ("Les coupes tombent sur les temps de l'audio choisi plus bas." if cale
               else ("Les coupes sont régulières." if melange else
                     "Les vidéos sont gardées entières (la découpe de l'aperçu ne s'applique pas).")))

        a, b, c = st.columns(3)
        n = a.number_input("Nombre de montages" if melange else "Nombre de vidéos",
                           1, 50 if melange else max(1, libres_v),
                           min(5, 50 if melange else max(1, libres_v)))
        lg = b.selectbox("Logo", ["aucun", "flou", "masque"], disabled=remonte,
                         format_func=lambda m: {"aucun": "Ne pas toucher", "flou": "Détecter + flouter",
                                                "masque": "Détecter + effacer"}[m])
        avec_cap = c.segmented_control("Captions", ["avec", "sans"], default="avec", key="ser_captions",
                                       format_func=lambda m: "Avec captions" if m == "avec" else "Sans caption",
                                       help="Sans caption : aucune caption du thème n'est consommée.") or "avec"
        sans_caption = avec_cap == "sans"

        # ── réglage des coupes, quand les vidéos sont recoupées ──
        ry_opts = {}
        if remonte:
            if cale:
                y1, y2, y3 = st.columns([1.6, 1, 1])
                cad_s = y1.segmented_control("Changer de plan", ["1", "2", "4", "accents"], default="2",
                                             key="ser_ry_pas",
                                             format_func=lambda m: {"1": "À chaque temps",
                                                                    "2": "Tous les 2 temps",
                                                                    "4": "Tous les 4 temps",
                                                                    "accents": "Sur les accents"}[m]) or "2"
                ry_opts = {"cale": True, "pas": int(cad_s) if cad_s.isdigit() else 2,
                           "sur_accents": cad_s == "accents",
                           "mini": float(y2.number_input("Plan le plus court (s)", 0.2, 5.0, 0.7,
                                                         step=0.1, format="%.1f", key="ser_ry_mini")),
                           "maxi": float(y3.number_input("Plan le plus long (s)", 0.5, 15.0, 3.0,
                                                         step=0.5, format="%.1f", key="ser_ry_maxi"))}
            else:
                y1, y2 = st.columns(2)
                ry_opts = {"cale": False,
                           "duree_plan": float(y1.number_input("Durée d'un plan (s)", 0.3, 10.0, 1.5,
                                                               step=0.1, format="%.1f", key="ser_dp")),
                           "duree_cible": float(y2.number_input(
                               "Durée du montage (s) — sans audio", 3.0, 120.0, 15.0, step=1.0,
                               format="%.0f", key="ser_dc",
                               help="Ignoré si un audio est choisi : c'est alors sa durée qui fait loi."))}
            # tout sort en 9:16 : une vidéo déjà verticale est gardée telle quelle, une autre est
            # centrée et complétée par des bandes noires là où il faut.
            ry_opts["format_origine"] = False
            ry_opts["cadrage_paysage"] = "bandes"
            if melange:
                ry_opts["marquer"] = st.toggle(
                    "Marquer les vidéos comme utilisées", value=False, key="ser_marquer_v",
                    help="Décoché : les vidéos restent disponibles pour les montages suivants — un "
                         "mélange pioche dans toutes les vidéos du thème.")
            if not melange:
                st.caption("Chaque vidéo est redécoupée en ses propres rushs, mélangés — et le montage ne "
                           "commence ni ne finit jamais sur le plan qui ouvre ou ferme la vidéo d'origine. "
                           "Les **plans "
                           "séquences** (aucune coupe à l'intérieur) sont écartés et signalés. "
                           "Première fois : compte quelques secondes par vidéo pour repérer les coupes.")

        # ── habillage des captions ──
        if not sans_caption:
            titre_aide("Habillage des captions",
                       "Choisis un ou plusieurs styles enregistrés et un ou plusieurs emplacements : "
                       "Monteur les répartit sur la série, pour varier la façon d'utiliser les captions. "
                       "Les styles viennent de « Enregistrer comme style », plus haut.", niveau="")
            opts_c = [postmontage.MEME_THEME] + ths
            themes_cap_ser = st.multiselect(
                "Thèmes des captions", opts_c,
                default=[postmontage.MEME_THEME if theme_cap == theme else theme_cap], key="ser_themes_c",
                format_func=lambda t: "↺ Le thème de chaque vidéo" if t == postmontage.MEME_THEME else t,
                help="Où piocher les captions. Plusieurs thèmes : la série les répartit (au hasard ou à "
                     "tour de rôle) ; un thème épuisé laisse la place aux autres. Les exports sont rangés "
                     "dans un sous-dossier par thème de caption.") or [postmontage.MEME_THEME]
            s1, s2, s3 = st.columns([2, 1.6, 1.4])
            noms_st = list(cfg["styles"].keys())
            choisis = s1.multiselect("Styles (couleur, contour, typo…)", noms_st,
                                     default=[x for x in [st.session_state.get("sty_preset")] if x in noms_st],
                                     key="ser_styles",
                                     help="Vide = le style réglé au-dessus. Les styles s'enregistrent avec "
                                          "« 💾 Enregistrer comme style ».")
            pos = s2.multiselect("Emplacements", list(postmontage.POSITIONS), default=[], key="ser_positions",
                                 format_func=lambda p: {"haut": "⬆ Haut", "milieu": "⬛ Milieu",
                                                        "bas": "⬇ Bas"}[p],
                                 help="Vide = la position enregistrée dans chaque style.")
            rep = s3.segmented_control("Répartition", ["hasard", "tour"], default="hasard",
                                       key="ser_repartition",
                                       format_func=lambda m: "Au hasard" if m == "hasard" else "À tour de rôle",
                                       help="À tour de rôle : les combinaisons défilent dans l'ordre.") or "hasard"
            styles_serie = [cfg["styles"][x] for x in choisis] or [style_de("captions")]
            st.caption(f"{len(postmontage.variantes(styles_serie, pos))} habillage(s) différent(s) "
                       "pour cette série.")
            assort = st.toggle("Assortir la caption à ce que montre la vidéo", value=False,
                               key="ser_assortir", disabled=melange,
                               help="Monteur compare les thèmes de chaque caption à ce qu'il reconnaît dans "
                                    "la vidéo. Indisponible quand un montage mélange plusieurs vidéos.")
            si_rien = "sans"
            if assort and not melange:
                si_rien = st.segmented_control("Quand aucune caption ne colle", ["sans", "hasard"],
                                               default="sans", key="ser_sirien",
                                               format_func=lambda m: "Monter sans texte" if m == "sans"
                                               else "Mettre une caption au hasard") or "sans"
            eviter = st.toggle("Écarter les vidéos qui ont déjà une caption à l'image", value=True,
                               key="ser_eviter",
                               help="Elles sont montées sans texte (vidéo par vidéo), ou laissées de côté "
                                    "(mélange).")
        else:
            styles_serie, pos, rep, assort, si_rien, eviter = ([style_de("captions")], [], "hasard", False,
                                                                "sans", True)
            themes_cap_ser = [postmontage.MEME_THEME]

        titre_aide("Audio" + (" (obligatoire)" if cale else ""),
                   "Un extrait, ou plusieurs que Monteur répartit sur la série (au hasard ou à tour "
                   "de rôle, comme les habillages)."
                   + (" Obligatoire en montage calé : c'est lui qui donne le tempo." if cale else ""),
                   niveau="")
        audio_serie = bloc_audio("serie")
        audios_serie = [audio_serie] if audio_serie else []
        if audio_serie:
            tous_ex = [x for art in audios.artistes(cfg) for x in audios.liste(cfg, art)
                       if str(x["chemin"]) != audio_serie.get("source")]
            par_cle = {f"{x['artiste']}/{x['fichier']}": x for x in tous_ex}
            autres = st.multiselect(
                "➕ Autres extraits pour cette série", list(par_cle), key="ser_autres_audios",
                format_func=lambda k: f"{audios.nom_affiche(par_cle[k]['artiste'])} · {par_cle[k]['nom']}",
                placeholder="Aucun : le même extrait partout",
                help="Chaque extrait ajouté peut être raccourci juste en dessous ; il prend le volume "
                     "réglé ci-dessus. Chaque vidéo de la série reçoit l'un des extraits.")
            for n_x, k in enumerate(autres):
                x = par_cle[k]
                with st.container(border=True):
                    st.markdown(f"🎵 **{x['nom']}** · {audios.nom_affiche(x['artiste'])}")
                    ch_x, d_x, f_x = raccourcir_extrait(f"serie_x_{k}", x)
                audios_serie.append({"chemin": str(ch_x), "nom": x["nom"], "artiste": x["artiste"],
                                     "debut_s": 0.0, "duree": round(f_x - d_x, 2),
                                     "volume": audio_serie["volume"], "garder_son": audio_serie["garder_son"],
                                     "muet": False, "source": str(x["chemin"]),
                                     "coupe": [round(d_x, 2), round(f_x, 2)]})
            if len(audios_serie) > 1:
                st.caption(f"🎵 {len(audios_serie)} extraits répartis sur la série "
                           f"({'au hasard' if rep == 'hasard' else 'à tour de rôle'}).")
        muet_serie = st.toggle("🔇 Exporter sans le son", key="ser_muet",
                               help="Les vidéos de la série sortent sans aucune piste son. L'extrait "
                                    "choisi sert quand même à caler les coupes et à écrire les paroles.")
        paroles_serie = bloc_paroles("serie", audios_serie,
                                     float((ry_opts or {}).get("duree_cible") or 0) or None)
        for a_s in audios_serie:
            lig = ((paroles_serie or {}).get("par_source") or {}).get(a_s["source"]) or []
            a_s["paroles"] = {"lignes": lig, "position": paroles_serie["position"]} if lig else None
        styles_par_serie = []
        if paroles_serie:
            noms_st_p = list(cfg["styles"].keys())
            choisis_p = st.multiselect(
                "Habillages des paroles", noms_st_p, default=[], key="ser_styles_paroles",
                help="Vide = l'habillage des paroles réglé à l'étape 3. Plusieurs : la série les "
                     "répartit, comme pour les captions.")
            styles_par_serie = [cfg["styles"][x] for x in choisis_p] or [style_de("paroles")]
        textes_serie = ["captions"]
        if paroles_serie:
            textes_serie = st.multiselect(
                "Ce qui s'écrit sur les vidéos", ["captions", "paroles", "deux", "rien"],
                default=["deux"], key="ser_textes",
                format_func=lambda m: {"captions": "Caption seule", "paroles": "Paroles seules",
                                       "deux": "Caption + paroles", "rien": "Sans texte"}[m],
                help="Coche plusieurs cases et la série alterne : une vidéo avec la caption seule, "
                     "la suivante avec les paroles, etc. La caption et les paroles ne se chevauchent "
                     "jamais ; trop serrées, la caption est abandonnée.") or ["deux"]

        pret_s = (libres_v > 0) and (bool(audio_serie) or not cale)
        if st.button("⚡ Lancer la série", type="primary", disabled=not pret_s, use_container_width=True):
            lignes, zone = [], st.empty()

            def log(m):
                lignes.append(m)
                zone.code("\n".join(lignes[-30:]), language=None)
            with st.spinner("Montage en série…"):
                k = postmontage.serie(cfg, themes_ser, int(n), style_courant(), plein, lg, log,
                                      styles=styles_serie, positions=pos, repartition=rep,
                                      sans_caption=sans_caption, audio=audio_serie,
                                      theme_caption=themes_cap_ser, eviter_doublon=bool(eviter),
                                      assortir_sens=bool(assort), sans_si_rien=(si_rien == "sans"),
                                      rythme_audio=audio_serie if cale else None,
                                      rythme_opts=ry_opts, structure=struct_ui,
                                      textes=textes_serie, audios=audios_serie,
                                      styles_paroles=styles_par_serie, muet=bool(muet_serie))
            st.success(f"{k} vidéo(s) exportée(s).")
        elif cale and not audio_serie:
            st.caption("👉 Choisis un extrait audio ci-dessus pour un montage calé sur le rythme.")

    st.divider()
    f1, f2 = st.columns([1.4, 3])
    if f1.button("📂 Ouvrir le dossier des vidéos exportées", use_container_width=True,
                 help="Le centre de contrôle : un sous-dossier par thème, celui des vidéos."):
        try:
            B.exporter_index(cfg)        # au passage, les fiches .json des anciennes versions sont rangées
        except OSError:
            pass
        ouvrir_finder(config.chemin(cfg, "centre_controle"))
    f2.caption(f"Les exports sont rangés dans **{config.chemin(cfg, 'centre_controle')}**, un dossier "
               "par thème de vidéos, puis **captions**, **paroles** ou **paroles + captions** selon ce "
               "qui est écrit dessus ; dans **captions** et **paroles + captions**, un sous-dossier "
               "par thème de caption. Sans aucun texte : directement dans le thème. Le nom de "
               "l'extrait audio figure dans le nom du fichier. Les fiches et l'index sont à part, "
               "dans **_fiches**.")


# ════════════════════════════════════════════ AUDIOS ════════════════════════════════════════════

DOSSIER_SON = config.RACINE / "static" / "son"
DOSSIER_ONDES = config.RACINE / "static" / "ondes"


def mm_ss(s: float) -> str:
    s = max(0.0, float(s or 0))
    return f"{int(s) // 60}:{int(s) % 60:02d}"


def duree_precise(s: float) -> str:
    return f"{float(s or 0):.2f}".replace(".", ",")


def son_servi(chemin_a: Path) -> str:
    """Rend l'audio lisible par le navigateur (dossier static de Streamlit). Renvoie son URL.

    Passer par le dossier static évite le lecteur de Streamlit, qui recharge le fichier à chaque
    affichage de la page : c'est lui qui faisait attendre une seconde ou deux avant le premier son.
    """
    directe = recepteur.publier(chemin_a)
    if directe:
        return directe
    try:
        DOSSIER_SON.mkdir(parents=True, exist_ok=True)
        # le nom porte une empreinte du chemin : deux « Extrait 1.m4a » de dossiers différents ne
        # se remplacent plus l'un l'autre (on entendait alors un autre son que l'onde affichée)
        empreinte = hashlib.md5(str(chemin_a).encode("utf-8", "replace")).hexdigest()[:8]
        cible = DOSSIER_SON / f"{empreinte}_{chemin_a.name}"
        if not cible.exists() or cible.stat().st_mtime < chemin_a.stat().st_mtime:
            fichiers = [f for f in DOSSIER_SON.iterdir() if f.is_file() and f.suffix.lower() != ".gitkeep"]
            if len(fichiers) > 60:                      # ménage : on garde les plus récents
                for vieux in sorted(fichiers, key=lambda f: f.stat().st_mtime)[:20]:
                    if vieux != cible:
                        vieux.unlink(missing_ok=True)
            try:
                os.link(chemin_a, cible)                # lien matériel : aucune copie
            except OSError:
                shutil.copy2(chemin_a, cible)
        return "/app/static/son/" + urllib.parse.quote(cible.name)
    except Exception:  # noqa: BLE001
        return ""


def lecteur_audio(chemin_a: Path) -> None:
    """Lecteur audio du navigateur, servi en direct : il démarre sans attente.

    On passe par un petit cadre HTML plutôt que par `st.audio`, qui réinscrit le fichier dans le
    gestionnaire de médias de Streamlit à chaque affichage de la page — c'est lui qui faisait
    attendre une à deux secondes avant le premier son.
    """
    u = son_servi(chemin_a)
    if not u:
        try:
            st.audio(str(chemin_a))
        except Exception as e:  # noqa: BLE001
            st.caption(f"Lecture impossible : {e}")
        return
    composant_html(
        f"<body style='margin:0;background:transparent'>"
        f"<audio controls preload='auto' src='{u}' style='width:100%;height:40px'></audio></body>",
        height=46)


@st.cache_data(show_spinner=False, max_entries=64)
def onde_url(chemin_a: str, mtime: float, vue0: float = 0.0, vued: float = 0.0) -> str:
    """Forme d'onde servie en fichier (et non en base64) : rien à retransmettre à chaque affichage.

    `vue0` / `vued` dessinent seulement le passage affiché : c'est ce qui donne le zoom.
    """
    img = audios.forme_onde(Path(chemin_a), debut=vue0, longueur=vued or None)
    if not img:
        return ""
    try:
        DOSSIER_ONDES.mkdir(parents=True, exist_ok=True)
        cible = DOSSIER_ONDES / img.name
        if not cible.exists():
            try:
                os.link(img, cible)
            except OSError:
                shutil.copy2(img, cible)
        return "/app/static/ondes/" + urllib.parse.quote(cible.name)
    except Exception:  # noqa: BLE001
        return ""


def bloc_nouvel_artiste(prefixe: str):
    with st.form(f"nouvel_artiste_{prefixe}", clear_on_submit=True, border=False):
        na = st.text_input("Nouveau dossier artiste", placeholder="ex. Daft Punk")
        if st.form_submit_button("➕ Créer le dossier") and na.strip():
            try:
                st.session_state.au_artiste = audios.creer_artiste(cfg, na)
                st.toast(f"Dossier « {na.strip()} » créé", icon="📁")
                st.rerun()
            except ValueError as e:
                st.error(str(e))


def bloc_decoupe(m: dict):
    """Découpe d'un extrait dans un morceau entier : forme d'onde, poignées, minuteurs à la décimale."""
    st.markdown(f"#### ✂️ Découper dans « {m['nom']} »")
    duree_m = max(0.1, float(m["duree"]))
    # le jeton change après chaque extrait créé : les champs repartent à neuf (on ne peut pas
    # réécrire la valeur d'un widget déjà affiché, mais on peut préparer celle d'un nouveau)
    jeton = st.session_state.get("dec_jeton", 0)
    cle = f"dec_{m['fichier']}_{jeton}"
    # à refaire à CHAQUE passage : Streamlit oublie l'état d'un widget qui n'a pas été affiché
    # (panneau refermé, changement d'onglet), et le champ retomberait alors sur le minimum de
    # son échelle — la fenêtre de découpe se réduisait à 0,05 s, les deux poignées empilées.
    st.session_state.setdefault(f"{cle}_debut", 0.0)
    st.session_state.setdefault(f"{cle}_fin", round(min(duree_m, 30.0), 2))

    # ce que la forme d'onde a renvoyé au passage précédent est lu AVANT de la réafficher : sinon on
    # lui renverrait les anciennes bornes dans le même cycle et le glissement serait annulé.
    vu, cle_comp = f"onde_vu_{m['fichier']}", f"onde_{m['fichier']}"
    envoi = st.session_state.get(cle_comp)
    if isinstance(envoi, dict) and envoi.get("nonce") != st.session_state.get(vu):
        st.session_state[vu] = envoi["nonce"]
        st.session_state[f"{cle}_debut"] = round(float(envoi.get("debut") or 0), 2)
        st.session_state[f"{cle}_fin"] = round(float(envoi.get("fin") or 0), 2)
        st.session_state[f"{cle}_vue0"] = round(float(envoi.get("vue0") or 0), 2)
        st.session_state[f"{cle}_vued"] = round(float(envoi.get("vued") or 0), 2)
    debut = float(st.session_state.get(f"{cle}_debut", 0.0))
    fin = float(st.session_state.get(f"{cle}_fin", min(duree_m, 30.0)))
    if fin <= debut + 0.04:                                   # fenêtre dégénérée : on la rouvre
        fin = round(min(duree_m, debut + 30.0), 2)
        st.session_state[f"{cle}_fin"] = fin
    vued = float(st.session_state.get(f"{cle}_vued") or 0) or duree_m      # fenêtre affichée (zoom)
    vued = max(0.3, min(vued, duree_m))
    vue0 = max(0.0, min(float(st.session_state.get(f"{cle}_vue0") or 0), max(0.0, duree_m - vued)))
    onde(source=son_servi(m["chemin"]),
         onde_img=onde_url(str(m["chemin"]), m["chemin"].stat().st_mtime,
                           round(vue0, 2), round(vued, 2) if vued < duree_m - 0.01 else 0.0),
         duree=duree_m, debut=debut, fin=fin, vue0=vue0, vued=vued, key=cle_comp)
    titre_aide("Choisir le passage",
               "Tire les deux poignées rouges pour choisir le passage (30 s par défaut). 🔍+ / 🔍− zooment "
               "autour de la tête de lecture, ⤢ Tout revient au morceau entier. ▶ Écouter l'extrait part "
               "toujours de la poignée gauche ; mets en pause où tu veux, puis ⏱ Début ici amène la poignée "
               "gauche sur la tête de lecture (⏱ Fin ici fait de même à droite). Les minuteurs ci-dessous "
               "se règlent au centième de seconde.", niveau="")

    c1, c2, c3 = st.columns([1, 1, 1.2])
    d2 = c1.number_input("Début (s)", 0.0, max(0.0, duree_m - 0.05), step=0.01, format="%.2f",
                         key=f"{cle}_debut")
    f2 = c2.number_input("Fin (s)", 0.05, duree_m, step=0.01, format="%.2f", key=f"{cle}_fin")
    if f2 <= d2:                                   # garde-fou : une fenêtre vide n'a pas de sens
        f2 = min(duree_m, d2 + 0.05)
    if f2 <= d2 + 0.04:
        c3.warning("La fin doit être après le début.", icon="⏱")
    else:
        c3.markdown(f"<div style='padding-top:30px'>Durée de l'extrait : "
                    f"<b>{duree_precise(f2 - d2)} s</b></div>", unsafe_allow_html=True)

    st.write("")
    g1, g2, g3 = st.columns([1.5, 1.2, 1])
    nom_ex = g1.text_input("Nom de l'extrait", key=f"{cle}_nom", placeholder="ex. refrain, intro, drop…")
    arts = audios.artistes(cfg)
    dest = g2.selectbox("Ranger chez l'artiste", arts, index=None, key=f"{cle}_artiste",
                        placeholder="Choisis un dossier artiste…" if arts else "Crée d'abord un dossier artiste")
    fondu = g3.toggle("Fondus", value=False, key=f"{cle}_fondu",
                      help="Fondu d'entrée et de sortie, pour éviter les claquements.")
    duree_fondu = 0.0
    if fondu:
        duree_fondu = g3.number_input("Durée du fondu (s)", 0.02, 5.0,
                                      value=float(st.session_state.get(f"{cle}_dfondu", 0.15)),
                                      step=0.05, format="%.2f", key=f"{cle}_dfondu",
                                      label_visibility="collapsed")
    pret = bool(nom_ex.strip()) and bool(dest) and f2 > d2 + 0.04
    if st.button("✂️ Créer l'extrait", type="primary", disabled=not pret, use_container_width=True):
        try:
            p = audios.extraire(cfg, m["chemin"], d2, f2, dest, nom_ex, duree_fondu)
            # on reste sur le morceau : l'extrait suivant commence là où celui-ci s'arrête
            suite = f"dec_{m['fichier']}_{jeton + 1}"
            st.session_state[f"{suite}_debut"] = round(min(f2, duree_m - 0.05), 2)
            st.session_state[f"{suite}_fin"] = round(min(duree_m, f2 + (f2 - d2)), 2)
            st.session_state[f"{suite}_artiste"] = dest
            st.session_state.dec_jeton = jeton + 1
            st.toast(f"Extrait « {p.stem} » rangé chez {dest}", icon="🎵")
            st.rerun()
        except (ValueError, RuntimeError, OSError) as e:
            st.error(f"Découpe impossible : {e}")
    if not arts:
        st.caption("👉 Crée d'abord un **dossier artiste** dans la colonne de gauche.")
    elif not nom_ex.strip():
        st.caption("👉 Donne un nom à l'extrait pour pouvoir le créer.")


def fiche_audio(a: dict, avec_decoupe: bool = False):
    """Une ligne de la banque : écoute, renommage, rangement, suppression."""
    with st.container(border=True):
        g, d = st.columns([2.4, 1])
        with g:
            st.markdown(f"**{a['nom']}**  ·  <span class='petit'>{mm_ss(a['duree'])} "
                        f"({duree_precise(a['duree'])} s) · {a['fichier']}</span>", unsafe_allow_html=True)
            lecteur_audio(a["chemin"])
        with d:
            with st.form(f"ren_audio_{a['artiste']}_{a['fichier']}", border=False):
                nn = st.text_input("Nom", value=a["nom"], key=f"na_{a['artiste']}_{a['fichier']}",
                                   label_visibility="collapsed")
                if st.form_submit_button("✏️ Renommer", use_container_width=True):
                    try:
                        audios.renommer(cfg, a["artiste"], a["fichier"], nn)
                        st.toast("Audio renommé", icon="✏️")
                        st.rerun()
                    except (ValueError, OSError) as e:
                        st.error(str(e))
            try:
                st.download_button("⬇️ Télécharger", a["chemin"].read_bytes(), file_name=a["fichier"],
                                   key=f"dl_{a['artiste']}_{a['fichier']}", use_container_width=True,
                                   help="Enregistre le fichier audio dans les Téléchargements de ton "
                                        "ordinateur.")
            except OSError as e:
                st.caption(f"Téléchargement impossible : {e.strerror or e}")
            if avec_decoupe and st.button("✂️ Découper un extrait", key=f"dec_{a['fichier']}",
                                          type="primary", use_container_width=True):
                st.session_state.au_morceau = a["fichier"]
                st.rerun()
            # le rangement vaut aussi pour les morceaux entiers : un morceau déjà à la bonne
            # longueur n'a rien à faire dans « Morceaux complets », il se range chez l'artiste
            ailleurs = [x for x in (audios.artistes(cfg) + [audios.MORCEAUX]) if x != a["artiste"]]
            v = st.selectbox("Ranger chez", ailleurs, index=None,
                             key=f"mv_{a['artiste']}_{a['fichier']}", format_func=audios.nom_affiche,
                             placeholder="Ranger chez…", label_visibility="collapsed")
            if v and st.button("📁 Déplacer", key=f"mvb_{a['artiste']}_{a['fichier']}",
                               use_container_width=True):
                try:
                    audios.deplacer(cfg, a["artiste"], a["fichier"], v)
                    st.session_state.au_artiste = v
                    st.toast(f"« {a['nom']} » rangé dans {audios.nom_affiche(v)}", icon="📁")
                    st.rerun()
                except OSError as e:
                    st.error(f"Déplacement impossible : {e.strerror or e}")
            with st.popover("🗑 Supprimer", use_container_width=True):
                st.write(f"Supprimer définitivement **{a['nom']}** ?")
                if st.button("Oui, supprimer", key=f"supa_{a['artiste']}_{a['fichier']}", type="primary"):
                    audios.supprimer(cfg, a["artiste"], a["fichier"])
                    st.rerun()
        bloc_ecrire_paroles(a)
        bloc_zones_sans_coupe(a)


def bloc_deposer_extraits(art: str):
    """Déposer dans ce dossier des extraits déjà prêts, sans passer par la découpe."""
    with st.expander(f"⬆️ Déposer des extraits dans « {audios.nom_affiche(art)} »"):
        st.caption("Pour des extraits déjà coupés ailleurs. Ils arrivent directement ici, prêts à "
                   "servir dans Post montage. Un format que le navigateur ne lit pas (wav, aiff, "
                   "flac…) est converti en m4a au passage.")
        # le numéro dans la clé vide la zone de dépôt après coup : sans lui, les fichiers y
        # restent affichés et un deuxième clic déposerait les mêmes extraits une seconde fois
        tour = st.session_state.get(f"up_ext_tour_{art}", 0)
        up = st.file_uploader("Fichiers audio", type=["mp3", "m4a", "aac", "wav", "aiff", "flac", "ogg"],
                              accept_multiple_files=True, key=f"up_ext_{art}_{tour}",
                              label_visibility="collapsed")
        if up and st.button(f"⬆️ Déposer {len(up)} extrait(s) ici", key=f"up_ext_ok_{art}",
                            type="primary", use_container_width=True):
            with st.spinner("Dépôt des extraits…"):
                poses = audios.importer(cfg, [(f.name, f.getvalue()) for f in up], art)
            rates = len(up) - len(poses)
            if poses:
                st.toast(f"{len(poses)} extrait(s) déposé(s) dans « {audios.nom_affiche(art)} »",
                         icon="🎵")
            if rates:
                st.error(f"{rates} fichier(s) n'ont pas pu être déposés : format illisible ou "
                         "fichier abîmé.")
            if poses:
                st.session_state[f"up_ext_tour_{art}"] = tour + 1
                st.session_state.au_artiste = art
                st.rerun()


def page_audios():
    with st.container(border=True):
        titre_aide("🎵 Déposer des morceaux",
                   "Dépose un morceau entier, découpe-le en extraits, range-les dans un dossier au nom de "
                   "l'artiste : tu les retrouves dans Post montage, sur une vidéo ou sur toute une série. "
                   "Les morceaux entiers vont dans « Morceaux complets » ; c'est là qu'on les découpe. Tu "
                   "peux aussi glisser tes fichiers dans le dossier « audios/_morceaux » de Monteur. "
                   + ("Les audios sont communs : tout le monde a les mêmes." if partage.actif(cfg)
                      else "Règle un dossier commun dans Réglages pour les partager."))
        d_haut, d_bas = st.columns([3, 1], gap="large")
        with d_haut:
            tour_m = st.session_state.get("up_audio_tour", 0)
            up = st.file_uploader("Fichiers audio", type=["mp3", "m4a", "aac", "wav", "aiff", "flac", "ogg"],
                                  accept_multiple_files=True, key=f"up_audio_{tour_m}",
                                  label_visibility="collapsed")
            if up and st.button(f"➕ Déposer {len(up)} morceau(x)", type="primary"):
                with st.spinner("Dépôt des morceaux…"):
                    n = audios.importer_morceaux(cfg, [(f.name, f.getvalue()) for f in up])
                if n < len(up):
                    st.error(f"{len(up) - n} fichier(s) n'ont pas pu être déposés : format "
                             "illisible ou fichier abîmé.")
                st.session_state.up_audio_tour = tour_m + 1    # vide la zone : pas de double dépôt
                st.session_state.au_artiste = audios.MORCEAUX
                st.toast(f"{n} morceau(x) déposé(s)", icon="🎵")
                st.rerun()
        with d_bas:
            if st.button("📂 Ouvrir le dossier des audios", use_container_width=True):
                ouvrir_finder(audios.dossier(cfg))

    arts = audios.artistes(cfg)
    dossiers = [audios.MORCEAUX, *arts]
    choisi = st.session_state.pop("au_artiste", None)
    if choisi in dossiers:
        st.session_state.au_dossier = choisi
    if st.session_state.get("au_dossier") not in dossiers:
        st.session_state.au_dossier = audios.MORCEAUX

    gauche, droite = st.columns([1, 3.2], gap="large")
    with gauche:
        titre_aide("Dossiers artistes",
                   "Un dossier par artiste. Les extraits s'y rangent, et on les retrouve dans Post montage "
                   "par artiste.", niveau="")
        compte = {a: len(audios.liste(cfg, a)) for a in arts}
        compte[audios.MORCEAUX] = len(audios.morceaux(cfg))

        def libelle(a):
            n = compte.get(a, 0)
            return f"🎧 Morceaux complets ({n})" if a == audios.MORCEAUX else f"🎤 {a} · {n} extrait(s)"
        st.radio("Dossier", dossiers, key="au_dossier", format_func=libelle, label_visibility="collapsed")
        art = st.session_state.au_dossier
        with st.expander("⚙️ Gérer les dossiers"):
            bloc_nouvel_artiste("au")
            if art != audios.MORCEAUX:
                st.divider()
                with st.form(f"ren_artiste_{art}", border=False):
                    nv = st.text_input(f"Renommer « {art} »", value=art, key=f"rena_{art}")
                    if st.form_submit_button("✏️ Renommer", use_container_width=True):
                        try:
                            st.session_state.au_artiste = audios.renommer_artiste(cfg, art, nv)
                            st.rerun()
                        except (ValueError, OSError) as e:
                            st.error(str(e))
                with st.popover("🗑 Supprimer ce dossier", use_container_width=True):
                    st.write(f"Supprimer le dossier **{art}** ? Il doit être vide.")
                    if st.button("Oui, supprimer", key=f"supart_{art}", type="primary"):
                        try:
                            audios.supprimer_artiste(cfg, art)
                            st.session_state.au_artiste = audios.MORCEAUX
                            st.rerun()
                        except ValueError as e:
                            st.error(str(e))

    art = st.session_state.au_dossier
    with droite:
        if art == audios.MORCEAUX:
            ms = audios.morceaux(cfg)
            par_fichier = {x["fichier"]: x for x in ms}
            en_cours = st.session_state.get("au_morceau")
            if en_cours in par_fichier:
                with st.container(border=True):
                    bloc_decoupe(par_fichier[en_cours])
                    if st.button("✕ Fermer la découpe", key="fermer_decoupe"):
                        st.session_state.au_morceau = None
                        st.rerun()
                st.write("")
            st.markdown("### 🎧 Morceaux complets")
            if not ms:
                st.info("Aucun morceau déposé. Utilise **🎵 Déposer des morceaux** en haut.")
            for m in ms:
                fiche_audio(m, avec_decoupe=True)
        else:
            exs = audios.liste(cfg, art)
            titre_aide(f"🎤 {art}",
                       "Deux façons de remplir ce dossier : déposer un extrait déjà prêt avec le bouton "
                       "ci-dessous, ou découper un morceau entier depuis « Morceaux complets ».",
                       niveau="###")
            bloc_deposer_extraits(art)
            st.caption(f"{len(exs)} extrait(s).")
            if not exs:
                st.info("Aucun extrait dans ce dossier.")
            for a in exs:
                fiche_audio(a)


def raccourcir_extrait(prefixe: str, a: dict) -> tuple:
    """Interrupteur « Raccourcir » + poignées sur la forme d'onde. Renvoie (chemin, début, fin)."""
    duree_a = max(0.2, float(a["duree"] or 0))
    chemin_a, debut_a, fin_a = a["chemin"], 0.0, duree_a
    if st.toggle("✂️ Raccourcir l'extrait", key=f"au_coupe_{prefixe}",
                 help="Tire les poignées pour ne garder qu'une partie de l'extrait, sans créer un "
                      "nouveau fichier dans la banque."):
        cle_c = f"coupe_{prefixe}_{a['fichier']}"
        vu_c, comp_c = f"{cle_c}_vu", f"onde_{cle_c}"
        envoi_c = st.session_state.get(comp_c)
        if isinstance(envoi_c, dict) and envoi_c.get("nonce") != st.session_state.get(vu_c):
            st.session_state[vu_c] = envoi_c["nonce"]
            st.session_state[f"{cle_c}_debut"] = round(float(envoi_c.get("debut") or 0), 2)
            st.session_state[f"{cle_c}_fin"] = round(float(envoi_c.get("fin") or 0), 2)
            st.session_state[f"{cle_c}_vue0"] = round(float(envoi_c.get("vue0") or 0), 2)
            st.session_state[f"{cle_c}_vued"] = round(float(envoi_c.get("vued") or 0), 2)
        st.session_state.setdefault(f"{cle_c}_debut", 0.0)
        st.session_state.setdefault(f"{cle_c}_fin", round(duree_a, 2))
        debut_a = max(0.0, min(float(st.session_state[f"{cle_c}_debut"]), duree_a - 0.2))
        fin_a = float(st.session_state[f"{cle_c}_fin"])
        if fin_a <= debut_a + 0.2 or fin_a > duree_a:
            fin_a = duree_a
            st.session_state[f"{cle_c}_fin"] = round(fin_a, 2)
        vued_c = float(st.session_state.get(f"{cle_c}_vued") or 0) or duree_a
        vued_c = max(0.3, min(vued_c, duree_a))
        vue0_c = max(0.0, min(float(st.session_state.get(f"{cle_c}_vue0") or 0),
                              max(0.0, duree_a - vued_c)))
        onde(source=son_servi(a["chemin"]),
             onde_img=onde_url(str(a["chemin"]), a["chemin"].stat().st_mtime, round(vue0_c, 2),
                               round(vued_c, 2) if vued_c < duree_a - 0.01 else 0.0),
             duree=duree_a, debut=debut_a, fin=fin_a, vue0=vue0_c, vued=vued_c, key=comp_c)
        k1, k2, k3 = st.columns([1, 1, 1.2])
        debut_a = k1.number_input("Début (s)", 0.0, max(0.0, duree_a - 0.2), step=0.01, format="%.2f",
                                  key=f"{cle_c}_debut")
        fin_a = k2.number_input("Fin (s)", 0.2, duree_a, step=0.01, format="%.2f", key=f"{cle_c}_fin")
        if fin_a <= debut_a + 0.1:
            fin_a = min(duree_a, debut_a + 0.2)
        k3.markdown(f"<div style='padding-top:30px'>Extrait utilisé : "
                    f"<b>{duree_precise(fin_a - debut_a)} s</b></div>", unsafe_allow_html=True)
        chemin_a = audios.rogner(a["chemin"], debut_a, fin_a)
    else:
        lecteur_audio(a["chemin"])
    return chemin_a, debut_a, fin_a


def bloc_audio(prefixe: str, duree_video: float | None = None,
               muet_possible: bool = False) -> dict | None:
    """Choix d'un extrait (artiste → extrait) + départ et volume. Renvoie le réglage pour l'export.

    `muet_possible` : propose de n'utiliser l'audio que pour caler les coupes, sans le poser sur
    l'export (montage en rythme d'une vidéo destinée à être publiée muette ou sonorisée ailleurs).
    """
    arts = audios.artistes(cfg)
    dossiers = arts + ([audios.MORCEAUX] if audios.morceaux(cfg) else [])
    if not dossiers:
        st.caption("🎵 Aucun audio dans la banque — dépose un morceau et découpe un extrait dans l'onglet "
                   "**🎵 Audios**.")
        return None
    c0, c1 = st.columns(2)
    art = c0.selectbox("Artiste", dossiers, index=None, key=f"au_art_{prefixe}",
                       format_func=audios.nom_affiche, placeholder="Aucun audio…")
    if not art:
        return None
    exs = audios.liste(cfg, art) if art != audios.MORCEAUX else audios.morceaux(cfg)
    if not exs:
        c1.caption("Aucun extrait dans ce dossier.")
        return None
    noms = [x["nom"] for x in exs]
    nom_a = c1.selectbox("Extrait", noms, index=None, key=f"au_nom_{prefixe}_{art}",
                         placeholder="Choisis un extrait…")
    if not nom_a:
        return None
    a = next(x for x in exs if x["nom"] == nom_a)
    duree_a = max(0.2, float(a["duree"] or 0))
    chemin_a, debut_a, fin_a = a["chemin"], 0.0, duree_a

    chemin_a, debut_a, fin_a = raccourcir_extrait(prefixe, a)
    muet = False
    if muet_possible:
        muet = st.toggle("🔇 Exporter sans le son", key=f"au_muet_{prefixe}",
                         help="L'audio sert uniquement à caler les coupes sur le rythme : la vidéo "
                              "exportée n'a aucune piste son.")
    if muet:
        vol, garder = 1.0, False
        st.caption("Les coupes suivront le rythme de l'extrait, mais la vidéo exportée sera muette.")
    else:
        d1, d2 = st.columns([1.2, 1])
        vol = d1.slider("Volume", 0.0, 2.0, value=float(st.session_state.get(f"au_vol_{prefixe}", 1.0)),
                        step=0.05, key=f"au_vol_{prefixe}")
        garder = d2.toggle("Garder aussi le son d'origine", key=f"au_mix_{prefixe}",
                           help="Désactivé : l'audio remplace le son de la vidéo.")
    da = round(fin_a - debut_a, 2)
    if duree_video and da:
        if da < duree_video - 0.05:
            st.caption(f"L'extrait ({duree_precise(da)} s) est plus court que la vidéo "
                       f"({duree_precise(duree_video)} s) : il se **répète** jusqu'à la fin.")
        elif da > duree_video + 0.05:
            st.caption(f"L'extrait ({duree_precise(da)} s) est plus long que la vidéo "
                       f"({duree_precise(duree_video)} s) : il démarre au début et se **coupe** à la fin "
                       "de la vidéo.")
    protegees = zones.pour_extrait({"source": str(a["chemin"]), "coupe": [debut_a, fin_a]})
    if protegees:
        st.caption(f"🔒 **{len(protegees)} zone(s) sans coupe** sur cet extrait : le montage calé "
                   "sur le rythme ne changera pas de plan dedans. Elles se tracent dans l'onglet "
                   "🎵 Audios.")
    return {"chemin": str(chemin_a), "nom": a["nom"], "artiste": art, "debut_s": 0.0,
            "duree": da, "volume": float(vol), "garder_son": bool(garder), "muet": bool(muet),
            "source": str(a["chemin"]), "coupe": [round(debut_a, 2), round(fin_a, 2)]}


def bloc_ecrire_paroles(a: dict):
    """Atelier des paroles d'un audio : transcrire, corriger, caler chaque ligne sur la forme d'onde."""
    source = a["chemin"]
    fiche = paroles.lire(source)
    mots = fiche.get("mots") or []
    lignes = fiche.get("lignes") or []
    mode = fiche.get("mode") or "ligne"
    # libellé volontairement figé : s'il changeait (le nombre de lignes), Streamlit verrait un
    # nouvel élément à chaque ajout ou suppression et refermerait l'encadré sous le nez.
    with st.expander("📝 Paroles"):
        st.caption(("**" + str(len(lignes)) + " ligne(s).** " if lignes else "")
                   + "Monteur écoute le morceau sur cet ordinateur et en sort les mots avec leur "
                   "minutage. Sur du chant, rien n'est parfait : corrige le texte, glisse les "
                   "repères numérotés pour caler chaque ligne, vide une ligne pour la supprimer. "
                   "Une ligne reste à l'écran jusqu'à la suivante ; le bouton ⏹ lui pose une fin, "
                   "pour que le texte disparaisse quand le chant s'arrête. "
                   "Les paroles se posent ensuite sur les vidéos depuis Post montage.")
        if not paroles.moteur_pret():
            st.warning(paroles.explication(), icon="⬇️")
            if st.button("⬇️ Installer la transcription", key=f"parinst_{a['fichier']}",
                         use_container_width=True):
                zone, jl = st.empty(), []

                def log_i(m):
                    jl.append(str(m))
                    zone.code("\n".join(jl[-12:]), language=None)
                with st.spinner("Installation…"):
                    ok = paroles.installer(log_i)
                (st.success if ok else st.error)(
                    "Installée — ferme le Terminal et relance Monteur." if ok else
                    "Installation impossible. Vérifie ta connexion internet.")
            return

        c1, c2, c3 = st.columns([1.4, 2.2, 1])

        def transcrire():
            zone, jl = st.empty(), []

            def log_t(m):
                jl.append(str(m))
                zone.code("\n".join(jl[-10:]), language=None)
            try:
                with st.spinner("Écoute du morceau… (la première fois, le modèle se télécharge)"):
                    nouveaux = paroles.transcrire(source, log=log_t)
                paroles.ecrire(source, {"mots": nouveaux, "mode": mode,
                                        "lignes": paroles.grouper(nouveaux, mode)})
                zone.empty()
                st.rerun()
            except Exception as e:  # noqa: BLE001
                st.error(f"Transcription impossible : {e}")

        if lignes:
            # une nouvelle transcription écrase les corrections : jamais sans confirmation
            with c1.popover("✍️ Refaire la transcription", use_container_width=True):
                st.write(f"Refaire la transcription **efface les {len(lignes)} ligne(s)** déjà "
                         "écrites, tes corrections et tes calages compris.")
                if st.button("Oui, tout refaire", key=f"partr_ok_{a['fichier']}", type="primary"):
                    transcrire()
        elif c1.button("✍️ Transcrire le chant", key=f"partr_{a['fichier']}", type="primary",
                       use_container_width=True):
            transcrire()
        if mots:
            nouveau_mode = c2.segmented_control(
                "Découpage", list(paroles.MODES), default=mode, key=f"parmode_{a['fichier']}",
                format_func=lambda m: {"ligne": "Ligne par ligne", "groupe": "Par petits groupes",
                                       "mot": "Mot par mot"}[m],
                help="Repart des mots reconnus : les corrections faites à la main sont effacées.")
            if nouveau_mode and nouveau_mode != mode:
                paroles.ecrire(source, {**fiche, "mode": nouveau_mode,
                                        "lignes": paroles.grouper(mots, nouveau_mode)})
                st.rerun()
        if lignes and c3.button("🗑 Tout effacer", key=f"pardel_{a['fichier']}",
                                use_container_width=True):
            paroles.oublier(source)
            st.rerun()
        if not lignes:
            st.info("Aucune parole pour cet audio. Clique sur **Transcrire le chant**, ou ajoute "
                    "les lignes à la main après une première transcription.")
            return

        duree_a = max(0.5, float(audios.duree(source)))
        cle_comp = f"comp_par_{a['artiste']}_{a['fichier']}"
        retour = st.session_state.get(cle_comp)
        if isinstance(retour, dict) and retour.get("nonce") != st.session_state.get(f"{cle_comp}_vu"):
            st.session_state[f"{cle_comp}_vu"] = retour["nonce"]
            st.session_state[f"{cle_comp}_vue0"] = round(float(retour.get("vue0") or 0), 2)
            st.session_state[f"{cle_comp}_vued"] = round(float(retour.get("vued") or 0), 2)
            propres = paroles.nettoyer(retour.get("lignes") or [], duree_a)
            if propres != lignes:
                paroles.ecrire(source, {**fiche, "lignes": propres})
                # surtout pas de st.rerun() ici : un composant non redessiné dans le passage
                # perd son état, l'iframe est reconstruit et la frappe en cours est effacée.
                lignes = propres
        vued_p = float(st.session_state.get(f"{cle_comp}_vued") or 0) or duree_a
        vued_p = max(0.5, min(vued_p, duree_a))
        vue0_p = max(0.0, min(float(st.session_state.get(f"{cle_comp}_vue0") or 0),
                              max(0.0, duree_a - vued_p)))
        editeur_paroles(source=son_servi(source),
                        onde_img=onde_url(str(source), source.stat().st_mtime, round(vue0_p, 2),
                                          round(vued_p, 2) if vued_p < duree_a - 0.01 else 0.0),
                        duree=duree_a, lignes=lignes, vue0=vue0_p, vued=vued_p, key=cle_comp)


def bloc_zones_sans_coupe(a: dict):
    """Passages de l'extrait que le montage en rythme ne doit pas couper."""
    source = a["chemin"]
    # libellé figé : s'il portait le nombre de zones, Streamlit refermerait l'encadré à chaque ajout
    with st.expander("🔒 Zones sans coupe"):
        posees = zones.lire(source)
        duree_a = max(0.5, float(audios.duree(source)))
        cochees = [z for z in posees if z["active"]]
        st.caption((f"**{len(cochees)} zone(s) cochée(s) sur {len(posees)}.** " if posees else "")
                   + "Un montage calé sur le rythme change de plan à chaque temps. Cale ici les "
                     "passages où il ne doit pas couper — une phrase qu'on laisse filer, une montée "
                     "qu'une coupe casserait : le plan en cours tient jusqu'au bout de la zone. "
                     "Les poignées, l'écoute et le zoom marchent comme pour découper un extrait.")

        cle = f"zon_{a['artiste']}_{a['fichier']}"
        comp = f"onde_{cle}"
        envoi = st.session_state.get(comp)
        if isinstance(envoi, dict) and envoi.get("nonce") != st.session_state.get(f"{cle}_vu"):
            st.session_state[f"{cle}_vu"] = envoi["nonce"]
            st.session_state[f"{cle}_debut"] = round(float(envoi.get("debut") or 0), 2)
            st.session_state[f"{cle}_fin"] = round(float(envoi.get("fin") or 0), 2)
            st.session_state[f"{cle}_vue0"] = round(float(envoi.get("vue0") or 0), 2)
            st.session_state[f"{cle}_vued"] = round(float(envoi.get("vued") or 0), 2)
        st.session_state.setdefault(f"{cle}_debut", 0.0)
        st.session_state.setdefault(f"{cle}_fin", round(min(2.0, duree_a), 2))
        z_debut = max(0.0, min(float(st.session_state[f"{cle}_debut"]), duree_a - 0.2))
        z_fin = float(st.session_state[f"{cle}_fin"])
        if z_fin <= z_debut + 0.2 or z_fin > duree_a:
            z_fin = min(duree_a, z_debut + max(0.2, zones.MINI))
            st.session_state[f"{cle}_fin"] = round(z_fin, 2)
        vued_z = float(st.session_state.get(f"{cle}_vued") or 0) or duree_a
        vued_z = max(0.3, min(vued_z, duree_a))
        vue0_z = max(0.0, min(float(st.session_state.get(f"{cle}_vue0") or 0),
                              max(0.0, duree_a - vued_z)))
        onde(source=son_servi(source),
             onde_img=onde_url(str(source), source.stat().st_mtime, round(vue0_z, 2),
                               round(vued_z, 2) if vued_z < duree_a - 0.01 else 0.0),
             duree=duree_a, debut=z_debut, fin=z_fin, vue0=vue0_z, vued=vued_z,
             zones=posees, key=comp)
        k1, k2, k3 = st.columns([1, 1, 1.6])
        z_debut = k1.number_input("Début (s)", 0.0, max(0.0, duree_a - 0.2), step=0.01,
                                  format="%.2f", key=f"{cle}_debut")
        z_fin = k2.number_input("Fin (s)", 0.2, duree_a, step=0.01, format="%.2f",
                                key=f"{cle}_fin")
        assez = z_fin - z_debut >= zones.MINI
        with k3:
            st.markdown("<div style='height:28px'></div>", unsafe_allow_html=True)
            if st.button(f"✅ Valider cette zone ({duree_precise(max(0, z_fin - z_debut))} s)",
                         key=f"{cle}_ok", type="primary", use_container_width=True,
                         disabled=not assez):
                zones.ajouter(source, z_debut, z_fin)
                st.rerun()
        if not assez:
            st.caption(f"Écarte les poignées d'au moins {zones.MINI:.1f} s pour pouvoir valider.")

        if not posees:
            st.caption("Aucune zone validée : le montage peut couper partout dans cet extrait.")
            return
        st.markdown("###### Zones validées")
        st.caption("Décoche une zone pour l'ignorer au prochain export, sans la perdre.")

        def _bascule(zid: str, cle_case: str):
            zones.basculer(source, zid, st.session_state[cle_case])

        for z in posees:
            c1, c2 = st.columns([8, 1])
            cle_case = f"{cle}_on_{z['id']}"
            c1.checkbox(f"**{z['debut']:.2f} → {z['fin']:.2f} s** · "
                        f"{duree_precise(z['fin'] - z['debut'])} s sans coupe",
                        value=z["active"], key=cle_case,
                        on_change=_bascule, args=(z["id"], cle_case))
            if c2.button("✕", key=f"{cle}_del_{z['id']}", help="Supprimer cette zone"):
                zones.enlever(source, z["id"])
                st.rerun()
        if cochees:
            longue = max(z["fin"] - z["debut"] for z in cochees)
            protege = sum(b - a for a, b in zones.actives(posees))
            st.caption(f"⏱ La plus longue zone cochée tient un même plan "
                       f"**{duree_precise(longue)} s** — {duree_precise(protege)} s protégées sur "
                       f"{duree_precise(duree_a)} s d'extrait. Au-delà de quelques secondes, le "
                       "plan risque de traîner.")
        else:
            st.caption("Aucune zone cochée : le montage peut couper partout dans cet extrait.")
        if st.button("🗑 Tout effacer", key=f"zondel_{a['fichier']}", use_container_width=True):
            zones.oublier(source)
            st.rerun()


def bloc_paroles(prefixe: str, audio, duree_video: float | None = None) -> dict | None:
    """Poser sur la vidéo les paroles écrites dans l'onglet Audios.

    `audio` : un extrait, ou une liste d'extraits (série). Renvoie {lignes, position, par_source} :
    `lignes` sont celles du premier extrait, `par_source` celles de chaque extrait, par chemin source.
    """
    liste = [a for a in (audio if isinstance(audio, list) else [audio]) if a]
    if not liste:
        return None
    toutes = {}
    for a_x in liste:
        src_x = Path(a_x.get("source") or a_x.get("chemin") or "/nulle-part")
        if src_x.is_file():
            toutes[str(a_x.get("source") or src_x)] = (paroles.lire(src_x).get("lignes") or [], a_x)
    if not toutes:
        return None
    audio = liste[0]
    avec = [k for k, (l_x, _) in toutes.items() if l_x]
    lignes = toutes[avec[0]][0] if avec else []
    with st.container(border=True):
        titre_aide("📝 Paroles",
                   "Les paroles s'écrivent et se calent dans l'onglet 🎵 Audios, sous l'extrait. "
                   "Ici, on choisit seulement de les poser sur la vidéo et à quelle hauteur.")
        if not lignes:
            st.caption("Aucune parole pour cet extrait. Va les écrire dans l'onglet **🎵 Audios**, "
                       "sous l'extrait : transcription automatique, puis calage à la main.")
            if st.button("🎵 Aller aux Audios", key=f"par_go_{prefixe}", use_container_width=True,
                         on_click=aller, args=(P_AUDIOS,),
                         kwargs={"au_artiste": audio.get("artiste") or ""}):
                pass
            return None
        etiquette = (f"Écrire les paroles sur la vidéo ({len(lignes)} ligne(s))" if len(liste) == 1 else
                     f"Écrire les paroles sur la vidéo ({len(avec)} extrait(s) sur {len(liste)} en ont)")
        if not st.toggle(etiquette, key=f"par_on_{prefixe}", value=True):
            return None
        place = st.segmented_control(
            "Où s'écrivent les paroles", ["haut", "centre", "bas"], default="bas",
            key=f"par_pos_{prefixe}",
            format_func=lambda m: {"haut": "⬆️ En haut", "centre": "⏺ Au centre",
                                   "bas": "⬇️ En bas"}[m],
            help="La caption se range dans une bande restée libre : l'opposée, ou un bord quand les "
                 "paroles sont au centre. Si les deux blocs se touchent ou se frôlent — paroles "
                 "écrites en gros, caption longue — la caption est abandonnée et n'est pas "
                 "consommée.") or "bas"
        par_source = {}
        for k in avec:
            l_x, a_x = toutes[k]
            d_a, f_a = (a_x.get("coupe") or [0.0, 0.0])[:2]
            sorties_x = paroles.borner(paroles.decaler(l_x, d_a, f_a), duree_video or 0)
            if sorties_x:
                par_source[k] = sorties_x
        if not par_source:
            return None
        if len(liste) == 1:
            sorties = next(iter(par_source.values()))
            st.caption(f"{len(sorties)} ligne(s) dans l'extrait utilisé"
                       + (f", sur {len(lignes)} au total." if len(sorties) != len(lignes) else "."))
        else:
            sans = [a_x["nom"] for k, (_, a_x) in toutes.items() if k not in par_source]
            if sans:
                st.caption("Sans paroles : " + ", ".join(sans) + " — ces vidéos-là auront la caption "
                           "seule (ou rien).")
        premier = par_source.get(str(audio.get("source") or audio.get("chemin") or ""), [])
        if len(liste) == 1 and not premier:
            return None
        return {"lignes": premier or next(iter(par_source.values())), "position": place,
                "par_source": par_source}


# ════════════════════════════════════════════ RÉGLAGES ════════════════════════════════════════════

def lien_modifier_acces() -> str:
    """L'adresse GitHub où se modifie le fichier des accès, déduite de l'adresse de lecture."""
    u = acces.url(cfg)
    if "raw.githubusercontent.com" in u:
        bouts = u.split("raw.githubusercontent.com/")[-1].split("/")
        if len(bouts) >= 4:
            proprio, depot, branche = bouts[0], bouts[1], bouts[2]
            branche = "main" if branche in ("HEAD", "") else branche
            return f"https://github.com/{proprio}/{depot}/edit/{branche}/{'/'.join(bouts[3:])}"
    return u


def bloc_acces():
    """Qui a le droit d'ouvrir Monteur. Le panneau complet n'apparaît que pour le propriétaire."""
    titre_aide("Accès au logiciel")
    if not _acces.get("proprietaire"):
        qui = f" ({_acces['nom']})" if _acces.get("nom") else ""
        st.caption(f"Ton accès est ouvert{qui}." +
                   (f" Il prend fin le {_acces['fin']}." if _acces.get("fin") else ""))
        if st.button("Utiliser une autre clé", use_container_width=True):
            acces.oublier_cle()
            st.rerun()
        return

    gens, cache = acces.liste_distante()
    if cache.get("erreur"):
        st.warning(f"Liste des accès lue le {dt.datetime.fromtimestamp(cache.get('le') or 0):%d/%m à %H:%M} "
                   f"(dernière tentative en échec : {cache['erreur']}).", icon="☁️")
    for p in gens:
        if p["proprietaire"]:
            etiquette = "<span class='badge b-utilisee'>toi</span>"
        elif not p["actif"]:
            etiquette = "<span class='badge b-gris'>fermé</span>"
        elif p["expire"]:
            etiquette = "<span class='badge b-erreur'>terminé</span>"
        else:
            etiquette = "<span class='badge b-libre'>ouvert</span>"
        fin = f" — jusqu'au {p['fin']}" if p["fin"] else ""
        st.markdown(f"{etiquette} **{p['nom']}**{fin}", unsafe_allow_html=True)
    if not gens:
        st.caption("Aucun accès connu pour l'instant.")
    st.caption("Pour **fermer un accès** : ouvre le fichier des accès, passe `\"actif\": true` à `false` sur "
               "la ligne de la personne, et enregistre. Son Monteur se bloque au lancement suivant.")
    st.link_button("✏️ Ouvrir le fichier des accès", lien_modifier_acces(), use_container_width=True)
    if st.button("↻ Relire la liste des accès", use_container_width=True):
        r = acces.lire_distant(acces.url(cfg))
        st.error(f"Lecture impossible : {r['erreur']}") if r.get("erreur") else st.success("Liste à jour.")
        st.rerun()

    with st.expander("➕ Donner l'accès à quelqu'un"):
        n_a, n_b = st.columns([2, 1])
        nom_p = n_a.text_input("Son nom", key="acc_nom", placeholder="ex. Marie")
        avec_fin = n_b.toggle("Date de fin", key="acc_avec_fin",
                              help="L'accès se ferme tout seul ce jour-là. Tu peux aussi le fermer avant.")
        fin_p = ""
        if avec_fin:
            fin_p = str(st.date_input("Fin de la mission", dt.date.today() + dt.timedelta(days=90),
                                      key="acc_fin"))
        if st.button("Fabriquer la clé", type="primary", use_container_width=True, key="acc_creer"):
            if not (nom_p or "").strip():
                st.warning("Donne un nom, pour savoir à qui appartient la clé.")
            else:
                st.session_state.acc_nouvelle = {"cle": acces.fabriquer_cle(), "nom": nom_p.strip(),
                                                 "fin": fin_p}
        nouvelle = st.session_state.get("acc_nouvelle")
        if nouvelle:
            entier = acces.fichier_complet([nouvelle])
            if entier:
                st.markdown("**1.** Ouvre le fichier des accès, **sélectionne tout** (⌘A) et **remplace** "
                            "par ceci — tout le fichier, pas seulement la ligne du bas :")
                st.code(entier, language="json")
            else:
                st.warning("Monteur n'a pas encore lu la liste des accès : clique sur « ↻ Relire la liste » "
                           "au-dessus, sinon tu risques d'effacer les autres accès.", icon="⚠️")
                st.markdown("Ligne correspondant à cette clé, à insérer dans `\"cles\"` (virgule après la "
                            "ligne précédente, **aucune** après la dernière) :")
                st.code(acces.ligne_json(nouvelle["cle"], nouvelle["nom"], nouvelle["fin"]), language="json")
            st.markdown(f"**2.** Envoie cette clé à **{nouvelle['nom']}** — elle la saisira à la première "
                        "ouverture de Monteur :")
            st.code(nouvelle["cle"], language=None)
            st.caption("La clé elle-même n'est écrite nulle part dans le fichier public : si la personne la "
                       "perd, fabrique-lui-en une nouvelle.")


def page_reglages():
    g, d = st.columns(2, gap="large")
    with g:
        titre_aide("Téléchargement")
        dl = cfg["telechargement"]
        navs = ["", "chrome", "safari", "firefox", "brave", "edge"]
        dl["cookies_navigateur"] = st.selectbox(
            "Navigateur où tu es connecté à Instagram / TikTok", navs,
            index=navs.index(dl.get("cookies_navigateur", "")) if dl.get("cookies_navigateur", "") in navs else 0,
            format_func=lambda x: x or "aucun",
            help="Nécessaire pour Instagram dans la plupart des cas. macOS demande l'accès au trousseau une fois : "
                 "saisis ton mot de passe Mac et clique sur « Toujours autoriser ».")
        if st.button("🔑 Relire les cookies du navigateur", use_container_width=True,
                     help="À faire si les téléchargements échouent après t'être reconnecté à Instagram ou TikTok."):
            sauver()
            lignes = []
            p_ck = telechargement.fichier_cookies(dl["cookies_navigateur"], lignes.append, forcer=True)
            (st.success if p_ck else st.error)(lignes[-1] if lignes else "Aucun navigateur choisi.")
        titre_aide("Export")
        ex = cfg["export"]
        ex["qualite_crf"] = st.slider("Qualité (18 = haute, 26 = fichiers légers)", 16, 28, int(ex.get("qualite_crf", 20)))
        ex["fps_max"] = st.selectbox("Images / seconde", [24, 25, 30, 60],
                                     index=[24, 25, 30, 60].index(int(ex.get("fps_max", 30)))
                                     if int(ex.get("fps_max", 30)) in [24, 25, 30, 60] else 2)
        ex["duree_max_s"] = st.number_input("Couper les vidéos à N secondes (0 = non)", 0, 600,
                                            int(ex.get("duree_max_s", 0)))
        titre_aide("Partage à plusieurs")
        pa = cfg.setdefault("partage", {})
        candidats = partage.dossiers_cloud()
        if candidats:
            noms = ["(saisir à la main)"] + [str(c) for c in candidats]
            actuel = pa.get("dossier", "")
            choix = st.selectbox("Dossier synchronisé trouvé sur ce Mac", noms,
                                 index=noms.index(actuel) if actuel in noms else 0,
                                 help="Choisis le dossier que la personne qui pilote a partagé avec toi.")
            if choix != "(saisir à la main)" and choix != actuel:
                pa["dossier"] = choix
        pa["dossier"] = st.text_input(
            "Dossier commun (Google Drive, iCloud…)", pa.get("dossier", ""),
            placeholder="~/Library/CloudStorage/GoogleDrive-moi@gmail.com/Drive partagés/Monteur",
            help="Le même dossier partagé chez chaque personne. Monteur le remplit tout seul : bibliothèque "
                 "vidéo, centre de contrôle, captions, typos et marques « utilisée » deviennent communs. "
                 "Laisse vide pour tout garder sur cet ordinateur.")
        if partage.est_lien_web(pa.get("dossier", "")):
            st.error(partage.etat(cfg), icon="🔗")
        else:
            (st.caption if partage.actif(cfg) or not pa.get("dossier") else st.warning)(partage.etat(cfg))
        with st.expander("Comment trouver ce dossier ?"):
            st.markdown(
                "1. Installe **Google Drive pour ordinateur** (google.com/drive/download) et connecte-toi.\n"
                "2. Dans Drive sur le web, ouvre **Partagés avec moi**, clic droit sur le dossier → "
                "**Organiser → Ajouter un raccourci** → *Mon Drive*. Sans ça, il n'est pas synchronisé sur le Mac.\n"
                "3. Reviens ici : il apparaît dans la liste ci-dessus (pense à **↻ Chercher à nouveau**).\n"
                "4. Sinon, dans le Finder : clic droit sur le dossier, maintiens **⌥ alt**, "
                "*Copier … en tant que nom de chemin*, et colle-le dans le champ.")
        if st.button("↻ Chercher à nouveau les dossiers synchronisés", use_container_width=True):
            st.rerun()
        reste = partage.reste_en_local(cfg)
        if reste:
            st.warning(f"{reste} fichier(s) (vidéos, exports, audios) sont encore sur cet ordinateur et absents du "
                       "dossier commun : les autres ne les voient pas.", icon="📦")
            if st.button(f"📤 Copier ces {reste} fichier(s) dans le dossier commun", use_container_width=True,
                         type="primary"):
                barre = st.progress(0.0, "Copie…")
                n = partage.transferer(cfg, lambda p, nom: barre.progress(min(1.0, p), f"Copie de {nom[:40]}…"))
                barre.empty()
                st.success(f"{n} fichier(s) copié(s). Google Drive va maintenant les envoyer aux autres.")
                st.rerun()
        st.caption("Sont communs : vidéos, centre de contrôle, captions, typos ajoutées, audios et marques "
                   "« déjà utilisée ». Restent personnels : cookies du navigateur, files d'attente et réglages. "
                   "Évitez de monter la même vidéo au même moment : le dossier commun se synchronise fichier "
                   "par fichier.")
        titre_aide("Dossiers")
        dd = cfg["dossiers"]
        dd["bibliotheque"] = st.text_input("Bibliothèque vidéo (originaux, un dossier par thème)", dd["bibliotheque"])
        dd["centre_controle"] = st.text_input("Centre de contrôle (vidéos montées, un dossier par thème)",
                                              dd["centre_controle"],
                                              help="Ex. un dossier Google Drive partagé : "
                                                   "~/Library/CloudStorage/GoogleDrive-…/Mon Drive/Centre de contrôle")
        dd["polices"] = st.text_input("Polices supplémentaires", dd["polices"])
        dd["audios"] = st.text_input("Banque d'audios", dd.get("audios", "audios"),
                                     help="Les audios proposés dans Post montage. Dans le dossier commun "
                                          "quand il y en a un.")
        if st.button("💾 Enregistrer les réglages", type="primary"):
            sauver()
            B.synchroniser(cfg)
        b1, b2 = st.columns(2)
        if b1.button("📂 Ouvrir le centre de contrôle", use_container_width=True):
            ouvrir_finder(config.chemin(cfg, "centre_controle"))
        if b2.button("📂 Ouvrir la bibliothèque", use_container_width=True):
            ouvrir_finder(config.chemin(cfg, "bibliotheque"))
    with d:
        titre_aide("Extension Chrome")
        st.markdown(f"""
1. Dans Chrome, ouvre **chrome://extensions**
2. Active le **Mode développeur** (en haut à droite)
3. Clique sur **Charger l'extension non empaquetée** et choisis le dossier :
   `{config.RACINE / 'extension-chrome'}`
4. Épingle l'icône 🎬 dans la barre de Chrome.

Si tu mets Monteur à jour : sur chrome://extensions, clique sur ↻ sous l'extension, puis recharge les pages
déjà ouvertes. L'extension lit les images de tous les sites (pour les captions) : elle n'envoie rien ailleurs qu'à
Monteur, sur ton Mac.
""")
        if st.button("📂 Ouvrir le dossier de l'extension"):
            ouvrir_finder(config.RACINE / "extension-chrome")
        titre_aide("Lecture des captions")
        (st.caption if ocr.moteur() == "vision" else st.warning)(ocr.explication())
        titre_aide("Mettre à jour Monteur")
        st.caption(f"Version installée : **{maj.version_installee()}**. "
                   "Ferme la fenêtre Terminal, puis double-clique sur **Mettre-a-jour.command** dans le dossier "
                   "de Monteur : il télécharge la dernière version tout seul. Tes réglages, tes vidéos et tes "
                   "captions sont conservés.")
        mj = cfg.setdefault("maj", {})
        mj["url"] = st.text_input("Adresse de la version publiée (version.json)", mj.get("url", ""),
                                  help="Fournie avec Monteur. Laisse-la telle quelle si tu ne sais pas.")
        mj["auto"] = st.toggle("Prévenir quand une nouvelle version existe", bool(mj.get("auto", True)))
        if st.button("↻ Vérifier maintenant", use_container_width=True):
            sauver()
            r = maj.verifier(mj["url"])
            if not str(mj.get("url") or "").strip():
                st.warning("Aucune adresse renseignée : Monteur ne peut pas savoir s'il existe une nouvelle "
                           "version. Colle l'adresse fournie avec Monteur dans le champ ci-dessus.")
            elif r.get("erreur"):
                st.error(f"Vérification impossible : {r['erreur']}")
            elif maj.plus_recente(r.get("version", ""), maj.version_installee()):
                st.success(f"Version {r['version']} disponible — lance Mettre-a-jour.command.")
                st.session_state.maj_masquee = False
            else:
                st.success("Monteur est à jour.")
        if st.button("📂 Ouvrir le dossier de Monteur"):
            ouvrir_finder(config.RACINE)
        bloc_acces()
        titre_aide("Polices")
        up = st.file_uploader("Ajouter des polices (.ttf / .otf)", type=["ttf", "otf"], accept_multiple_files=True)
        if up:
            dp = dossier_polices()
            dp.mkdir(parents=True, exist_ok=True)
            for f in up:
                (dp / f.name).write_bytes(f.getbuffer())
            st.success(f"{len(up)} police(s) ajoutée(s).")
        st.caption(f"{len(polices_disponibles(cfg))} polices disponibles (projet + Mac).")
        titre_aide("Styles enregistrés")
        for nom_s in list(cfg["styles"].keys()):
            a, b = st.columns([4, 1])
            a.write(f"🔤 {nom_s} — {cfg['styles'][nom_s]['police']}, {cfg['styles'][nom_s]['taille']} px")
            if b.button("🗑", key=f"supstyle_{nom_s}", disabled=len(cfg["styles"]) <= 1):
                cfg["styles"].pop(nom_s)
                sauver("Style supprimé")
                st.rerun()


{
    P_BIBLIO: page_bibliotheque,
    P_CAPTIONS: page_captions,
    P_AUDIOS: page_audios,
    P_MONTAGE: page_postmontage,
    P_REGLAGES: page_reglages,
}[page]()
