"""Composants : éditeur d'aperçu (quote déplaçable, lecture, frise) et nuancier."""
from __future__ import annotations

from pathlib import Path

import streamlit.components.v1 as components

_editeur = components.declare_component("monteur_editeur", path=str(Path(__file__).parent))
_couleurs = components.declare_component("monteur_couleurs", path=str(Path(__file__).parent / "couleurs"))
_onde = components.declare_component("monteur_onde", path=str(Path(__file__).parent / "onde"))
_typos = components.declare_component("monteur_typos", path=str(Path(__file__).parent / "typos"))
_paroles = components.declare_component("monteur_paroles",
                                        path=str(Path(__file__).parent / "paroles"))


def editeur(video: str, fond: str, calque: str, frise: list[str], duree: float, x: float, y: float,
            debut: float, fin: float, t: float, cadrage: str, logo: dict | None,
            largeur: int, hauteur: int, decalage: float = 50.0, cadrable: bool = False,
            src_largeur: int = 0, src_hauteur: int = 0, son: str = "", son_volume: float = 1.0,
            son_garder: bool = False, bloc_l: float = 0.0, bloc_h: float = 0.0,
            zone: dict | None = None, key: str | None = None):
    """Aperçu interactif (avec l'extrait audio choisi). Renvoie {x, y, debut, fin, t, decalage, nonce}."""
    return _editeur(video=video, fond=fond, calque=calque, frise=frise, duree=duree, x=x, y=y,
                    debut=debut, fin=fin, t=t, cadrage=cadrage, logo=logo,
                    largeur=largeur, hauteur=hauteur, decalage=decalage, cadrable=cadrable,
                    src_largeur=src_largeur, src_hauteur=src_hauteur, son=son, son_volume=son_volume,
                    son_garder=son_garder, bloc_l=bloc_l, bloc_h=bloc_h, zone=zone,
                    key=key, default=None)


def nuancier(couleur: str, contour: str, bandeau: str, key: str | None = None):
    """Trois sélecteurs de couleur qui répondent en direct. Renvoie {couleur, contour, bandeau, nonce}."""
    return _couleurs(couleur=couleur, contour=contour, bandeau=bandeau, key=key, default=None)


def typos(polices: list[str], choisie: str, key: str | None = None):
    """Liste de typos : survol + flèches ↑ ↓ pour défiler, l'aperçu suit. Renvoie {nom, nonce}."""
    return _typos(polices=list(polices), choisie=str(choisie or ""), key=key, default=None)


def editeur_paroles(source: str, onde_img: str, duree: float, lignes: list[dict],
                    vue0: float = 0.0, vued: float = 0.0, key: str | None = None):
    """Forme d'onde + un repère déplaçable par ligne, et le texte de chaque ligne.

    `vue0` / `vued` : fenêtre dessinée dans l'image (le zoom).
    Renvoie {lignes: [{texte, debut, fin, fin_fixe}, …], vue0, vued, nonce}.
    """
    return _paroles(source=source, onde=onde_img, duree=float(duree), lignes=list(lignes),
                    vue0=float(vue0), vued=float(vued or duree), key=key, default=None)


def onde(source: str, onde_img: str, duree: float, debut: float, fin: float,
         vue0: float = 0.0, vued: float = 0.0, zones: list | None = None, key: str | None = None):
    """Forme d'onde avec poignées, écoute et zoom. Renvoie {debut, fin, vue0, vued, nonce}.

    `vue0` / `vued` : fenêtre dessinée dans l'image (zoom).
    `zones` : passages déjà validés, montrés en vert par-dessus l'onde (verts cochés, gris décochés).
    """
    return _onde(source=source, onde=onde_img, duree=duree, debut=debut, fin=fin,
                 vue0=vue0, vued=vued or duree,
                 zones=[{"debut": z["debut"], "fin": z["fin"], "active": z.get("active", True)}
                        for z in (zones or [])],
                 key=key, default=None)
