#!/bin/bash
# Ouvre Monteur dans le navigateur (laisse cette fenêtre ouverte pendant l'utilisation)
cd "$(dirname "$0")"
for b in /opt/homebrew/bin/brew /usr/local/bin/brew; do [ -x "$b" ] && eval "$($b shellenv)"; done
if ! command -v ffmpeg >/dev/null 2>&1; then echo "ffmpeg manquant : lance d'abord Installer.command"; read -n 1; exit 1; fi
if [ ! -x .venv/bin/python ]; then
  echo "→ Création de l'environnement Python…"
  PY="$(command -v python3.12 || command -v python3)"
  "$PY" -m venv .venv || { echo "❌ Impossible de créer l'environnement — lance Installer.command"; read -n 1; exit 1; }
fi
# ── mise à jour automatique : Monteur ne démarre jamais sur une version périmée ──
# Mettre-a-jour.command repose MONTEUR_SANS_MAJ=1 quand il relance Monteur : pas de boucle possible.
if [ -z "$MONTEUR_SANS_MAJ" ] && [ -f Mettre-a-jour.command ]; then
  NOUVELLE="$(.venv/bin/python - <<'FINPY' 2>/dev/null
import json, pathlib, urllib.request, yaml

def nombres(v):
    return tuple(int(x) for x in str(v or "0").replace("v", "").split(".") if x.isdigit())

url = ""
for c in ("config/config.yaml", "config/config.defaut.yaml"):
    f = pathlib.Path(c)
    if f.exists():
        url = ((yaml.safe_load(f.read_text(encoding="utf-8")) or {}).get("maj") or {}).get("url") or ""
        if url:
            break
try:
    req = urllib.request.Request(url, headers={"User-Agent": "Monteur", "Cache-Control": "no-cache"})
    with urllib.request.urlopen(req, timeout=8) as r:
        distante = str((json.loads(r.read(200_000).decode("utf-8")) or {}).get("version") or "")
    locale = pathlib.Path("VERSION").read_text(encoding="utf-8").strip()
    if nombres(distante) > nombres(locale):
        print(distante)
except Exception:
    pass
FINPY
)"
  if [ -n "$NOUVELLE" ]; then
    echo "→ Nouvelle version $NOUVELLE disponible : installation…"
    chmod +x Mettre-a-jour.command 2>/dev/null
    MONTEUR_AUTO=1 exec ./Mettre-a-jour.command
  fi
fi

# la liste des modules est déduite de requirements.txt : plus rien à oublier quand une dépendance est ajoutée
MODULES="$(sed 's/[>=<].*//' requirements.txt | tr -d ' \r' | grep -v '^$' \
  | sed 's/^yt-dlp$/yt_dlp/; s/^pillow$/PIL/; s/^pyyaml$/yaml/' | paste -sd, -)"
if ! .venv/bin/python -c "import $MODULES" 2>/dev/null; then
  echo "→ Installation des modules (1re fois : quelques minutes)…"
  .venv/bin/python -m pip install --upgrade pip
  if ! .venv/bin/python -m pip install -r requirements.txt; then
    echo "❌ Échec de l'installation — envoie une capture de cette fenêtre à Claude."; read -n 1; exit 1
  fi
fi
# lecture des quotes : reconnaissance de texte du Mac (Apple Vision) — facultative, Monteur marche sans
if ! .venv/bin/python -c "import Vision" 2>/dev/null; then
  echo "→ Installation de la lecture de texte du Mac (une seule fois)…"
  .venv/bin/python -m pip install -q pyobjc-framework-Vision \
    || echo "⚠ Lecture des quotes indisponible pour l'instant — le reste de Monteur fonctionne."
fi
# yt-dlp doit rester à jour : Instagram / TikTok changent souvent
.venv/bin/python -m pip install -q --upgrade yt-dlp >/dev/null 2>&1 &
echo "Monteur démarre… (ferme cette fenêtre pour l'arrêter)"
# l'extension de sélection n'existe que dans Chrome : on ouvre Monteur là, pas dans le navigateur par défaut
( sleep 4
  if [ -d "/Applications/Google Chrome.app" ]; then
    open -a "Google Chrome" "http://localhost:8501"
  else
    echo "⚠ Google Chrome introuvable — ouvre http://localhost:8501 toi-même."
    open "http://localhost:8501"
  fi ) &
# --logger.level=error : on garde les vraies erreurs, on tait les avertissements de version
PYTHONWARNINGS=ignore::DeprecationWarning \
.venv/bin/python -m streamlit run app.py --server.port 8501 --server.headless true \
  --server.enableStaticServing true --browser.gatherUsageStats false --server.maxUploadSize 2000 \
  --logger.level error 2>&1 | grep --line-buffered -v -e "use_container_width" -e "will be removed after" -e "Deprecated Feature" \
                                     -e "Please update to Python" -e "^For .use_container_width" -e "^$"
