# Publier une nouvelle version (pour Etienne)

Tout le monde utilise le même Monteur. Une version publiée à **un seul endroit** arrive chez les
autres toute seule : au lancement, `Lancer.command` regarde s'il existe plus récent et l'installe
avant d'ouvrir le logiciel. Fermer le Terminal et double-cliquer sur `Lancer.command` suffit.

## Depuis octobre 2026 : Claude publie tout seul

Tu n'as plus rien à faire. Claude construit le zip, le dépose, crée la Release et met
`version.json` à jour, puis retélécharge le zip publié pour vérifier qu'il est identique au sien.

Ce qui rend ça possible : un **jeton GitHub** posé dans `_a-publier/jeton.txt`, sur ton Mac.
C'est un jeton *fine-grained*, limité au seul dépôt `monteur`, avec la seule permission
*Contents : Read and write*. Il ne passe jamais par la conversation : le script le lit sur place.
Tu peux le révoquer à tout moment sur https://github.com/settings/personal-access-tokens — la
publication automatique s'arrête, rien d'autre ne casse.

Le script est `_a-publier/publier.py` :

    python3 publier.py 2.16.0 monteur.zip notes.md   # publier
    python3 publier.py --essai                        # répétition à blanc, ne publie rien

`--essai` refait tous les appels sur des cibles jetables puis efface : à lancer si un doute
s'installe, il ne touche à rien de visible.

### L'ordre des opérations

Il n'est pas négociable, et le script l'impose :

1. le **zip** est déposé dans le dépôt — le fichier existe ;
2. la **Release** est créée — la version est datée et commentée ;
3. **`version.json`** est mis à jour **en dernier** — c'est lui seul qui déclenche les mises à
   jour chez les autres.

L'inverse annoncerait une version dont le zip n'existe pas encore : chaque Monteur tenterait la
mise à jour et échouerait.

### Pourquoi le zip est dans le dépôt, et non attaché à la Release

`uploads.github.com`, l'adresse par laquelle GitHub reçoit les pièces jointes de Release, est
injoignable depuis ce Mac. Le zip est donc un fichier du dépôt, et `version.json` pointe sur
**le commit exact** (`raw.githubusercontent.com/.../<commit>/monteur.zip`) plutôt que sur `HEAD` :
aucun cache ne peut servir un zip périmé. Pour les autres, rien ne change.

## À la main, si le jeton a disparu

1. Récupère le `monteur.zip` et le numéro de version (il est dans le fichier `VERSION`).
2. **Releases → Draft a new release** → *Tag* : le numéro précédé d'un `v` → *Create new tag*
   → *Attach binaries* : dépose `monteur.zip` → **Publish release**.
3. **Ensuite seulement**, modifie `version.json` : le nouveau numéro dans `"version"`, l'adresse
   `https://github.com/Etiennepik/monteur/releases/latest/download/monteur.zip` dans `"zip"`,
   une phrase dans `"notes"` → *Commit*.

> ⚠️ `version.json` doit rester du JSON valide : **pas de virgule après la dernière valeur**.
> Une virgule en trop rend le fichier illisible et bloque tout le monde au lancement — c'est
> déjà arrivé.

## Vérifier que ça marche

Dans Monteur : ⚙️ Réglages → **↻ Vérifier maintenant**. Il doit afficher « Monteur est à jour »
ou le numéro de la nouvelle version.

## Numéros de version

Le fichier `VERSION` à la racine fait foi. Il doit **toujours** augmenter (2.15.0 → 2.15.1 →
2.16.0), sinon le bandeau ne s'affiche pas. Le script refuse de publier un numéro déjà sorti.
